package com.google.android.voiceime;

/* loaded from: classes.dex */
interface Trigger {
    void onStartInputView();

    void startVoiceRecognition(String str);
}
