package com.google.android.voiceime;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* loaded from: classes.dex */
class IntentApiTrigger implements Trigger {
    private static final String TAG = "VoiceIntentApiTrigger";
    private final Handler mHandler;
    private final InputMethodService mInputMethodService;
    private String mLastRecognitionResult;
    private IBinder mToken;
    private final ServiceBridge mServiceBridge = new ServiceBridge(new Callback() { // from class: com.google.android.voiceime.IntentApiTrigger.1
        @Override // com.google.android.voiceime.IntentApiTrigger.Callback
        public void onRecognitionResult(String recognitionResult) {
            IntentApiTrigger.this.postResult(recognitionResult);
        }
    });
    private Set<Character> mUpperCaseChars = new HashSet();

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public interface Callback {
        void onRecognitionResult(String str);
    }

    public IntentApiTrigger(InputMethodService inputMethodService) {
        this.mInputMethodService = inputMethodService;
        this.mUpperCaseChars.add('.');
        this.mUpperCaseChars.add('!');
        this.mUpperCaseChars.add('?');
        this.mUpperCaseChars.add('\n');
        this.mHandler = new Handler();
    }

    @Override // com.google.android.voiceime.Trigger
    public void startVoiceRecognition(String language) {
        this.mToken = this.mInputMethodService.getWindow().getWindow().getAttributes().token;
        this.mServiceBridge.startVoiceRecognition(this.mInputMethodService, language);
    }

    public static boolean isInstalled(InputMethodService inputMethodService) {
        PackageManager pm = inputMethodService.getPackageManager();
        List<ResolveInfo> activities = pm.queryIntentActivities(new Intent("android.speech.action.RECOGNIZE_SPEECH"), 0);
        return activities.size() > 0;
    }

    private InputMethodManager getInputMethodManager() {
        return (InputMethodManager) this.mInputMethodService.getSystemService("input_method");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void postResult(String recognitionResult) {
        this.mLastRecognitionResult = recognitionResult;
        getInputMethodManager().showSoftInputFromInputMethod(this.mToken, 1);
    }

    @Override // com.google.android.voiceime.Trigger
    public void onStartInputView() {
        Log.i(TAG, "#onStartInputView");
        if (this.mLastRecognitionResult != null) {
            scheduleCommit();
        }
    }

    private void scheduleCommit() {
        this.mHandler.post(new Runnable() { // from class: com.google.android.voiceime.IntentApiTrigger.2
            @Override // java.lang.Runnable
            public void run() {
                IntentApiTrigger.this.commitResult();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void commitResult() {
        if (this.mLastRecognitionResult != null) {
            String result = this.mLastRecognitionResult;
            InputConnection conn = this.mInputMethodService.getCurrentInputConnection();
            if (conn == null) {
                Log.i(TAG, "Unable to commit recognition result, as the current input connection is null. Did someone kill the IME?");
                return;
            }
            if (!conn.beginBatchEdit()) {
                Log.i(TAG, "Unable to commit recognition result, as a batch edit cannot start");
                return;
            }
            try {
                ExtractedTextRequest etr = new ExtractedTextRequest();
                etr.flags = 1;
                ExtractedText et = conn.getExtractedText(etr, 0);
                if (et == null) {
                    Log.i(TAG, "Unable to commit recognition result, as extracted text is null");
                } else {
                    if (et.text != null) {
                        if (et.selectionStart != et.selectionEnd) {
                            conn.deleteSurroundingText(et.selectionStart, et.selectionEnd);
                        }
                        result = format(et, result);
                    }
                    if (!conn.commitText(result, 0)) {
                        Log.i(TAG, "Unable to commit recognition result");
                    } else {
                        this.mLastRecognitionResult = null;
                    }
                }
            } finally {
                conn.endBatchEdit();
            }
        }
    }

    private String format(ExtractedText et, String result) {
        int pos = et.selectionStart - 1;
        while (pos > 0 && Character.isWhitespace(et.text.charAt(pos))) {
            pos--;
        }
        if (pos == -1 || this.mUpperCaseChars.contains(Character.valueOf(et.text.charAt(pos)))) {
            result = String.valueOf(Character.toUpperCase(result.charAt(0))) + result.substring(1);
        }
        if (et.selectionStart - 1 > 0 && !Character.isWhitespace(et.text.charAt(et.selectionStart - 1))) {
            result = " " + result;
        }
        if (et.selectionEnd < et.text.length() && !Character.isWhitespace(et.text.charAt(et.selectionEnd))) {
            return String.valueOf(result) + " ";
        }
        return result;
    }
}
