package com.google.android.voiceime;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

/* loaded from: classes.dex */
public class ServiceHelper extends Service {
    private static final String TAG = "ServiceHelper";
    private final IBinder mBinder = new ServiceHelperBinder();
    private Callback mCallback;

    /* loaded from: classes.dex */
    public interface Callback {
        void onResult(String str);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent arg0) {
        return this.mBinder;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "#onCreate");
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "#onDestroy");
    }

    public void startRecognition(String languageLocale, Callback callback) {
        Log.i(TAG, "#startRecognition");
        this.mCallback = callback;
        Intent intent = new Intent(this, (Class<?>) ActivityHelper.class);
        intent.addFlags(268435456);
        startActivity(intent);
    }

    public void notifyResult(String recognitionResult) {
        if (this.mCallback != null) {
            this.mCallback.onResult(recognitionResult);
        }
    }

    /* loaded from: classes.dex */
    public class ServiceHelperBinder extends Binder {
        public ServiceHelperBinder() {
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public ServiceHelper getService() {
            return ServiceHelper.this;
        }
    }
}
