package com.android.inputmethod.latin;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import com.android.inputmethod.voice.VoiceInput;
import inputmethod.latin.perfectkeyboard.R;

/* loaded from: classes.dex */
public class DialogSeekBarPreference4val extends DialogPreference implements SeekBar.OnSeekBarChangeListener {
    private static final String androidns = "http://schemas.android.com/apk/res/android";
    private static final int numberOfSeekBars = 5;
    private int[] mCurrentValue;
    private int[] mDefaultValue;
    private String[] mKey;
    private int[] mMax;
    private int[] mMin;
    private SeekBar[] mSeekBar;
    private int[] mStep;
    private String[] mSuffix;
    private String[] mTitle;
    private int[] mValue;
    private TextView[] mValueText;

    public DialogSeekBarPreference4val(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mSeekBar = new SeekBar[5];
        this.mValueText = new TextView[5];
        this.mSuffix = new String[5];
        this.mDefaultValue = new int[5];
        this.mCurrentValue = new int[5];
        this.mMax = new int[5];
        this.mStep = new int[5];
        this.mMin = new int[5];
        this.mValue = new int[5];
        this.mTitle = new String[5];
        this.mKey = new String[5];
        setPersistent(true);
        Integer index = 1;
        for (Integer i = 0; i.intValue() < 5; i = Integer.valueOf(i.intValue() + 1)) {
            this.mSuffix[i.intValue()] = attrs.getAttributeValue(androidns, "text");
            this.mMin[i.intValue()] = attrs.getAttributeIntValue(null, "min" + index.toString(), 0);
            this.mMax[i.intValue()] = attrs.getAttributeIntValue(null, "max" + index.toString(), 100);
            this.mStep[i.intValue()] = attrs.getAttributeIntValue(null, "step" + index.toString(), 1);
            this.mDefaultValue[i.intValue()] = attrs.getAttributeIntValue(null, "defaultValue" + index.toString(), 100);
            this.mTitle[i.intValue()] = context.getResources().getString(attrs.getAttributeResourceValue(null, "title" + index.toString(), 0));
            this.mKey[i.intValue()] = context.getResources().getString(attrs.getAttributeResourceValue(null, DatabaseHelper.KEY + index.toString(), 0));
            index = Integer.valueOf(index.intValue() + 1);
        }
        setDialogLayoutResource(R.layout.my_seekbar_preference_4_values);
    }

    @Override // android.preference.DialogPreference
    protected void onBindDialogView(View v) {
        super.onBindDialogView(v);
        TextView dialogMessage = (TextView) v.findViewById(R.id.sb_message);
        dialogMessage.setText(getDialogMessage());
        SharedPreferences sp = getSharedPreferences();
        this.mValueText[0] = (TextView) v.findViewById(R.id.sb_text0);
        this.mValueText[1] = (TextView) v.findViewById(R.id.sb_text1);
        this.mValueText[2] = (TextView) v.findViewById(R.id.sb_text2);
        this.mValueText[3] = (TextView) v.findViewById(R.id.sb_text3);
        this.mValueText[4] = (TextView) v.findViewById(R.id.sb_text4);
        this.mSeekBar[0] = (SeekBar) v.findViewById(R.id.sb_bar0);
        this.mSeekBar[1] = (SeekBar) v.findViewById(R.id.sb_bar1);
        this.mSeekBar[2] = (SeekBar) v.findViewById(R.id.sb_bar2);
        this.mSeekBar[3] = (SeekBar) v.findViewById(R.id.sb_bar3);
        this.mSeekBar[4] = (SeekBar) v.findViewById(R.id.sb_bar4);
        for (int i = 0; i < 5; i++) {
            this.mCurrentValue[i] = sp.getInt(this.mKey[i], this.mDefaultValue[i]);
            this.mSeekBar[i].setEnabled(true);
            this.mSeekBar[i].setClickable(true);
            this.mSeekBar[i].setOnSeekBarChangeListener(this);
            this.mSeekBar[i].setMax((this.mMax[i] - this.mMin[i]) / this.mStep[i]);
            Integer number = Integer.valueOf((this.mCurrentValue[i] - this.mMin[i]) / this.mStep[i]);
            this.mSeekBar[i].setProgress(number.intValue());
            this.mValueText[i].setText(String.valueOf(this.mTitle[i]) + " (" + number.toString() + ")");
            this.mSeekBar[i].requestLayout();
        }
    }

    @Override // android.preference.Preference
    protected Object onGetDefaultValue(TypedArray a, int index) {
        return Integer.valueOf(a.getInt(index, 0));
    }

    @Override // android.preference.Preference
    protected void onSetInitialValue(boolean restore, Object defaultValue) {
        for (Integer i = 1; i.intValue() < 5; i = Integer.valueOf(i.intValue() + 1)) {
            this.mValue[i.intValue()] = getPersistedInt(defaultValue == null ? 0 : ((Integer) defaultValue).intValue());
        }
    }

    @Override // android.preference.DialogPreference
    protected void onDialogClosed(boolean positiveResult) {
        super.onDialogClosed(positiveResult);
        if (positiveResult) {
            for (int i = 0; i < 5; i++) {
                int value = (this.mSeekBar[i].getProgress() * this.mStep[i]) + this.mMin[i];
                if (callChangeListener(Integer.valueOf(value))) {
                    setValue(i, value);
                }
            }
        }
    }

    public void setValue(int index, int value) {
        if (value > this.mMax[index]) {
            value = this.mMax[index];
        } else if (value < this.mMin[index]) {
            value = this.mMin[index];
        }
        this.mValue[index] = value;
        SharedPreferences sp = getSharedPreferences();
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(this.mKey[index], this.mValue[index]);
        editor.commit();
    }

    public void setMax(int index, int max) {
        this.mMax[index] = max;
        if (this.mValue[index] > this.mMax[index]) {
            setValue(index, this.mMax[index]);
        }
    }

    public void setMin(int index, int min) {
        if (min < this.mMax[index]) {
            this.mMin[index] = min;
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onProgressChanged(SeekBar seek, int value, boolean fromTouch) {
        Integer iValue = Integer.valueOf(value);
        for (int i = 0; i < 5; i++) {
            if (seek.equals(this.mSeekBar[i])) {
                this.mValueText[i].setText(String.valueOf(this.mTitle[i]) + " (" + iValue.intValue() + ")");
            }
        }
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStartTrackingTouch(SeekBar seek) {
    }

    @Override // android.widget.SeekBar.OnSeekBarChangeListener
    public void onStopTrackingTouch(SeekBar seek) {
    }
}
