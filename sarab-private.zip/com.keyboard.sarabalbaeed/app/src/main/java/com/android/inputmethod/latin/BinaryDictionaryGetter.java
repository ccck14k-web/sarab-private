package com.android.inputmethod.latin;

import DictionaryPackage.DicatinaryPackage;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.util.Log;
import inputmethod.latin.perfectkeyboard.R;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class BinaryDictionaryGetter {
    private static final String COMMON_PREFERENCES_NAME = "LatinImeDictPrefs";
    private static final String TAG = BinaryDictionaryGetter.class.getSimpleName();
    private static final File[] EMPTY_FILE_ARRAY = new File[0];

    private BinaryDictionaryGetter() {
    }

    private static boolean isFileNameCharacter(int codePoint) {
        if (codePoint >= 48 && codePoint <= 57) {
            return true;
        }
        if (codePoint < 65 || codePoint > 90) {
            return (codePoint >= 97 && codePoint <= 122) || codePoint == 95;
        }
        return true;
    }

    private static String replaceFileNameDangerousCharacters(String name) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < name.length(); i++) {
            int codePoint = name.codePointAt(i);
            if (isFileNameCharacter(codePoint)) {
                sb.appendCodePoint(codePoint);
            } else {
                sb.append(String.format((java.util.Locale) null, "%%%1$06x", Integer.valueOf(codePoint)));
            }
        }
        return sb.toString();
    }

    private static String getWordListIdFromFileName(String fname) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < fname.length()) {
            int codePoint = fname.codePointAt(i);
            if (37 != codePoint) {
                sb.appendCodePoint(codePoint);
            } else {
                int encodedCodePoint = Integer.parseInt(fname.substring(i + 1, i + 7), 16);
                i += 6;
                sb.appendCodePoint(encodedCodePoint);
            }
            i++;
        }
        return sb.toString();
    }

    private static String getWordListCacheDirectory(Context context) {
        return context.getFilesDir() + File.separator + "dicts";
    }

    private static String getCacheDirectoryForLocale(String locale, Context context) {
        String relativeDirectoryName = replaceFileNameDangerousCharacters(locale);
        String absoluteDirectoryName = String.valueOf(getWordListCacheDirectory(context)) + File.separator + relativeDirectoryName;
        File directory = new File(absoluteDirectoryName);
        if (!directory.exists() && !directory.mkdirs()) {
            Log.e(TAG, "Could not create the directory for locale" + locale);
        }
        return absoluteDirectoryName;
    }

    public static String getCacheFileName(String id, String locale, Context context) {
        String fileName = replaceFileNameDangerousCharacters(id);
        return String.valueOf(getCacheDirectoryForLocale(locale, context)) + File.separator + fileName;
    }

    private static AssetFileAddress loadFallbackResource(Context context, int fallbackResId, Locale locale) {
        Resources res = context.getResources();
        Locale savedLocale = LocaleUtils.setSystemLocale(res, locale);
        AssetFileDescriptor afd = Utils.openRawResourceFd(res, fallbackResId);
        LocaleUtils.setSystemLocale(res, savedLocale);
        if (afd == null) {
            Log.e(TAG, "Found the resource but cannot read it. Is it compressed? resId=" + fallbackResId);
            return null;
        }
        return AssetFileAddress.makeFromFileNameAndOffset(context.getApplicationInfo().sourceDir, afd.getStartOffset(), afd.getLength());
    }

    /* loaded from: classes.dex */
    private static class DictPackSettings {
        final SharedPreferences mDictPreferences;

        public DictPackSettings(Context context) {
            Context dictPackContext = null;
            try {
                String dictPackName = context.getString(R.string.dictionary_pack_package_name);
                dictPackContext = context.createPackageContext(dictPackName, 0);
            } catch (PackageManager.NameNotFoundException e) {
                Log.e(BinaryDictionaryGetter.TAG, "Could not find a dictionary pack");
            }
            this.mDictPreferences = dictPackContext == null ? null : dictPackContext.getSharedPreferences(BinaryDictionaryGetter.COMMON_PREFERENCES_NAME, 1);
        }

        public boolean isWordListActive(String dictId) {
            if (this.mDictPreferences == null) {
                return true;
            }
            return this.mDictPreferences.getBoolean(dictId, true);
        }
    }

    private static File[] getCachedDirectoryList(Context context) {
        return new File(getWordListCacheDirectory(context)).listFiles();
    }

    private static File[] getCachedWordLists(String locale, Context context) {
        File[] wordLists;
        File[] directoryList = getCachedDirectoryList(context);
        if (directoryList == null) {
            return EMPTY_FILE_ARRAY;
        }
        ArrayList<File> cacheFiles = new ArrayList<>();
        for (File directory : directoryList) {
            if (directory.isDirectory()) {
                String dirLocale = getWordListIdFromFileName(directory.getName());
                if (LocaleUtils.isMatch(LocaleUtils.getMatchLevel(dirLocale, locale)) && (wordLists = directory.listFiles()) != null) {
                    for (File wordList : wordLists) {
                        cacheFiles.add(wordList);
                    }
                }
            }
        }
        return cacheFiles.isEmpty() ? EMPTY_FILE_ARRAY : (File[]) cacheFiles.toArray(EMPTY_FILE_ARRAY);
    }

    private static String getMainDictId(Locale locale) {
        return locale.getLanguage().toString();
    }

    public static List<AssetFileAddress> getDictionaryFiles(Locale locale, Context context, int fallbackResId) {
        AssetFileAddress fallbackAsset;
        AssetFileAddress fallbackAsset2;
        BinaryDictionaryFileDumper.cacheWordListsFromContentProvider(locale, context);
        File[] cachedWordLists = getCachedWordLists(locale.toString(), context);
        String mainDictId = getMainDictId(locale);
        DictPackSettings dictPackSettings = new DictPackSettings(context);
        boolean foundMainDict = false;
        boolean foundAnySoftDict = false;
        ArrayList<AssetFileAddress> fileList = new ArrayList<>();
        for (File f : cachedWordLists) {
            String wordListId = getWordListIdFromFileName(f.getName());
            if (wordListId.equals(mainDictId)) {
                foundMainDict = true;
            }
            if (dictPackSettings.isWordListActive(wordListId)) {
                if (f.canRead()) {
                    fileList.add(AssetFileAddress.makeFromFileName(f.getPath()));
                } else {
                    Log.e(TAG, "Found a cached dictionary file but cannot read it");
                }
            }
        }
        ArrayList<DicatinaryPackage.DictionaryBuilder> DictionaryBuilderASK = DicatinaryPackage.getAllBuilders(context);
        int size = DictionaryBuilderASK.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                break;
            }
            String lang = locale.getLanguage();
            if (lang.equalsIgnoreCase("he")) {
                lang = "iw";
            }
            if (!DictionaryBuilderASK.get(i).getLanguage().equals(lang) || (fallbackAsset2 = loadAnySoftDictioarny(DictionaryBuilderASK.get(i).getPackageContext(), DictionaryBuilderASK.get(i).getDictionaryResourceId(), locale)) == null) {
                i++;
            } else {
                fileList.add(fallbackAsset2);
                foundAnySoftDict = true;
                break;
            }
        }
        if (!foundAnySoftDict && !foundMainDict && dictPackSettings.isWordListActive(mainDictId) && (fallbackAsset = loadFallbackResource(context, fallbackResId, locale)) != null) {
            fileList.add(fallbackAsset);
        }
        return fileList;
    }

    private static AssetFileAddress loadAnySoftDictioarny(Context context, int fallbackResId, Locale locale) {
        Resources res = context.getResources();
        AssetFileDescriptor afd = Utils.openRawResourceFd(res, fallbackResId);
        if (afd == null) {
            Log.e(TAG, "Found the resource but cannot read it. Is it compressed? resId=" + fallbackResId);
            return null;
        }
        return AssetFileAddress.makeFromFileNameAndOffset(context.getApplicationInfo().sourceDir, afd.getStartOffset(), afd.getLength());
    }
}
