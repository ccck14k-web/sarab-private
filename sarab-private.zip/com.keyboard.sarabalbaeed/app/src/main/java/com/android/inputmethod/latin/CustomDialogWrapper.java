package com.android.inputmethod.latin;

import android.view.View;
import android.widget.EditText;
import inputmethod.latin.perfectkeyboard.R;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: CustomDitctionaryEditor.java */
/* loaded from: classes.dex */
public class CustomDialogWrapper {
    View base;
    EditText localeField;
    EditText wordField;

    /* JADX INFO: Access modifiers changed from: package-private */
    public CustomDialogWrapper(View base) {
        this.wordField = null;
        this.localeField = null;
        this.base = null;
        this.base = base;
        this.wordField = (EditText) base.findViewById(R.id.theword);
        this.localeField = (EditText) base.findViewById(R.id.thelocale);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getWord() {
        return getwordField().getText().toString();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public String getLocale() {
        return getlocaleField().getText().toString();
    }

    private EditText getwordField() {
        if (this.wordField == null) {
            this.wordField = (EditText) this.base.findViewById(R.id.theword);
        }
        return this.wordField;
    }

    private EditText getlocaleField() {
        if (this.localeField == null) {
            this.localeField = (EditText) this.base.findViewById(R.id.thelocale);
        }
        return this.localeField;
    }
}
