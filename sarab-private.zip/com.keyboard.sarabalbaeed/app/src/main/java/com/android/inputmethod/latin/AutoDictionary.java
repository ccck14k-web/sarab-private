package com.android.inputmethod.latin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.AsyncTask;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public class AutoDictionary extends ExpandableDictionary {
    private static final String AUTODICT_TABLE_NAME = "words";
    private static final String COLUMN_FREQUENCY = "freq";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_LOCALE = "locale";
    private static final String COLUMN_WORD = "word";
    private static final String DATABASE_NAME = "auto_dict.db";
    private static final int DATABASE_VERSION = 1;
    public static final String DEFAULT_SORT_ORDER = "freq DESC";
    static final int FREQUENCY_FOR_AUTO_ADD = 250;
    static final int FREQUENCY_FOR_PICKED = 3;
    static final int FREQUENCY_FOR_TYPED = 1;
    private static final int PROMOTION_THRESHOLD = 12;
    private static final int VALIDITY_THRESHOLD = 6;
    private static HashMap<String, String> sDictProjectionMap = new HashMap<>();
    private static DatabaseHelper sOpenHelper;
    private DictionaryEditor mIme;
    private String mLocale;
    private HashMap<String, Integer> mPendingWrites;
    private final Object mPendingWritesLock;

    static {
        sDictProjectionMap.put(COLUMN_ID, COLUMN_ID);
        sDictProjectionMap.put(COLUMN_WORD, COLUMN_WORD);
        sDictProjectionMap.put(COLUMN_FREQUENCY, COLUMN_FREQUENCY);
        sDictProjectionMap.put("locale", "locale");
        sOpenHelper = null;
    }

    public AutoDictionary(Context context, DictionaryEditor ime, String locale, int dicTypeId) {
        super(context, dicTypeId);
        this.mPendingWrites = new HashMap<>();
        this.mPendingWritesLock = new Object();
        this.mIme = ime;
        this.mLocale = locale;
        if (sOpenHelper == null) {
            sOpenHelper = new DatabaseHelper(getContext());
        }
        if (this.mLocale != null && this.mLocale.length() > 1) {
            loadDictionary();
        }
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary, com.android.inputmethod.latin.Dictionary
    public boolean isValidWord(CharSequence word) {
        int frequency = getWordFrequency(word);
        return frequency >= 6;
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void close() {
        flushPendingWrites();
        super.close();
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary
    public void loadDictionaryAsync() {
        Cursor cursor = query("locale=?", new String[]{this.mLocale});
        try {
            if (cursor.moveToFirst()) {
                int wordIndex = cursor.getColumnIndex(COLUMN_WORD);
                int frequencyIndex = cursor.getColumnIndex(COLUMN_FREQUENCY);
                while (!cursor.isAfterLast()) {
                    String word = cursor.getString(wordIndex);
                    int frequency = cursor.getInt(frequencyIndex);
                    if (word.length() < getMaxWordLength()) {
                        super.addWord(word, frequency);
                    }
                    cursor.moveToNext();
                }
            }
        } finally {
            cursor.close();
        }
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary
    public void addWord(String word, int addFrequency) {
        int length = word.length();
        if (length >= 2 && length <= getMaxWordLength()) {
            if (this.mIme.getCurrentWord().isAutoCapitalized()) {
                word = String.valueOf(Character.toLowerCase(word.charAt(0))) + word.substring(1);
            }
            int freq = getWordFrequency(word);
            int freq2 = freq < 0 ? addFrequency : freq + addFrequency;
            super.addWord(word, freq2);
            if (freq2 >= 12) {
                this.mIme.promoteToUserDictionary(word, FREQUENCY_FOR_AUTO_ADD);
                freq2 = 0;
            }
            synchronized (this.mPendingWritesLock) {
                this.mPendingWrites.put(word, freq2 == 0 ? null : new Integer(freq2));
            }
        }
    }

    public void flushPendingWrites() {
        synchronized (this.mPendingWritesLock) {
            if (!this.mPendingWrites.isEmpty()) {
                new UpdateDbTask(getContext(), sOpenHelper, this.mPendingWrites, this.mLocale).execute(new Void[0]);
                this.mPendingWrites = new HashMap<>();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, AutoDictionary.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE words (_id INTEGER PRIMARY KEY,word TEXT,freq INTEGER,locale TEXT);");
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w("AutoDictionary", "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS words");
            onCreate(db);
        }
    }

    private Cursor query(String selection, String[] selectionArgs) {
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        qb.setTables(AUTODICT_TABLE_NAME);
        qb.setProjectionMap(sDictProjectionMap);
        SQLiteDatabase db = sOpenHelper.getReadableDatabase();
        Cursor c = qb.query(db, null, selection, selectionArgs, null, null, DEFAULT_SORT_ORDER);
        return c;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class UpdateDbTask extends AsyncTask<Void, Void, Void> {
        private final DatabaseHelper mDbHelper;
        private final String mLocale;
        private final HashMap<String, Integer> mMap;

        public UpdateDbTask(Context context, DatabaseHelper openHelper, HashMap<String, Integer> pendingWrites, String locale) {
            this.mMap = pendingWrites;
            this.mLocale = locale;
            this.mDbHelper = openHelper;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... v) {
            SQLiteDatabase db = this.mDbHelper.getWritableDatabase();
            Set<Map.Entry<String, Integer>> mEntries = this.mMap.entrySet();
            for (Map.Entry<String, Integer> entry : mEntries) {
                Integer freq = entry.getValue();
                db.delete(AutoDictionary.AUTODICT_TABLE_NAME, "word=? AND locale=?", new String[]{entry.getKey(), this.mLocale});
                if (freq != null) {
                    db.insert(AutoDictionary.AUTODICT_TABLE_NAME, null, getContentValues(entry.getKey(), freq.intValue(), this.mLocale));
                }
            }
            return null;
        }

        private ContentValues getContentValues(String word, int frequency, String locale) {
            ContentValues values = new ContentValues(4);
            values.put(AutoDictionary.COLUMN_WORD, word);
            values.put(AutoDictionary.COLUMN_FREQUENCY, Integer.valueOf(frequency));
            values.put("locale", locale);
            return values;
        }
    }
}
