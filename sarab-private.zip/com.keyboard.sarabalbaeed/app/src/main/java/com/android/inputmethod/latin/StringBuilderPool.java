package com.android.inputmethod.latin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class StringBuilderPool {
    private static final boolean DEBUG = false;
    private static final StringBuilderPool sInstance = new StringBuilderPool();
    private final List<StringBuilder> mPool = Collections.synchronizedList(new ArrayList());

    private StringBuilderPool() {
    }

    public static StringBuilder getStringBuilder(int initialSize) {
        int poolSize = sInstance.mPool.size();
        StringBuilder sb = poolSize > 0 ? sInstance.mPool.remove(poolSize - 1) : new StringBuilder(initialSize);
        sb.setLength(0);
        return sb;
    }

    public static void recycle(StringBuilder garbage) {
        sInstance.mPool.add(garbage);
    }

    public static void ensureCapacity(int capacity, int initialSize) {
        for (int i = sInstance.mPool.size(); i < capacity; i++) {
            StringBuilder sb = new StringBuilder(initialSize);
            sInstance.mPool.add(sb);
        }
    }

    public static int getSize() {
        return sInstance.mPool.size();
    }
}
