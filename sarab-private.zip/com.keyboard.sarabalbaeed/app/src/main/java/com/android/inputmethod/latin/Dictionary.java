package com.android.inputmethod.latin;

/* loaded from: classes.dex */
public abstract class Dictionary {
    protected static final int FULL_WORD_SCORE_MULTIPLIER = 2;
    protected static final boolean INCLUDE_TYPED_WORD_IF_VALID = false;

    /* loaded from: classes.dex */
    public enum DataType {
        UNIGRAM,
        BIGRAM;

        /* renamed from: values, reason: to resolve conflict with enum method */
        public static DataType[] valuesCustom() {
            DataType[] valuesCustom = values();
            int length = valuesCustom.length;
            DataType[] dataTypeArr = new DataType[length];
            System.arraycopy(valuesCustom, 0, dataTypeArr, 0, length);
            return dataTypeArr;
        }
    }

    /* loaded from: classes.dex */
    public interface WordCallback {
        boolean addWord(char[] cArr, int i, int i2, int i3, int i4, DataType dataType);
    }

    public abstract void getWords(WordComposer wordComposer, WordCallback wordCallback, ProximityInfo proximityInfo);

    public abstract boolean isValidWord(CharSequence charSequence);

    public void getBigrams(WordComposer composer, CharSequence previousWord, WordCallback callback) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean same(char[] word, int length, CharSequence typedWord) {
        if (typedWord.length() != length) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (word[i] != typedWord.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    public void close() {
    }
}
