package com.android.inputmethod.latin;

import java.util.Iterator;
import java.util.LinkedList;

/* loaded from: classes.dex */
public class KeyEventStateMachine {
    public static final int KEYCODE_FIRST_CHAR = -4097;
    private static final int MAX_NFA_DIVIDES = 30;
    private int resultChar;
    private int sequenceLength;
    private KeyEventState start = new KeyEventState();
    private RingBuffer walker = new RingBuffer();
    private RingBuffer walkerhelper;
    private RingBuffer walkerunused;

    /* loaded from: classes.dex */
    public enum State {
        RESET,
        REWIND,
        NOMATCH,
        PARTMATCH,
        FULLMATCH;

        /* renamed from: values, reason: to resolve conflict with enum method */
        public static State[] valuesCustom() {
            State[] valuesCustom = values();
            int length = valuesCustom.length;
            State[] stateArr = new State[length];
            System.arraycopy(valuesCustom, 0, stateArr, 0, length);
            return stateArr;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public final class KeyEventTransition {
        private int keyCode;
        private KeyEventState next;

        KeyEventTransition(int keyCode, KeyEventState next) {
            this.next = next;
            this.keyCode = keyCode;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public final class KeyEventState {
        private int result = 0;
        private LinkedList<KeyEventTransition> transitions;

        KeyEventState() {
        }

        public KeyEventState getNext(int keyCode) {
            if (this.transitions == null) {
                return null;
            }
            Iterator<KeyEventTransition> it = this.transitions.iterator();
            while (it.hasNext()) {
                KeyEventTransition transition = it.next();
                if (transition.keyCode == keyCode) {
                    return transition.next;
                }
            }
            return null;
        }

        public void addNextState(int keyCode, KeyEventState next) {
            if (this.transitions == null) {
                this.transitions = new LinkedList<>();
            }
            this.transitions.add(new KeyEventTransition(keyCode, next));
        }

        public void setCharacter(int result) {
            this.result = result;
        }

        public boolean hasNext() {
            return this.transitions != null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class NFAPart {
        int iSequenceLength;
        int iVisibleSequenceLength;
        private int resultChar;
        private int sequenceLength;
        KeyEventState state;
        private int visibleSequenceLength;

        NFAPart() {
            reset();
        }

        void reset() {
            this.state = KeyEventStateMachine.this.start;
            this.iSequenceLength = 0;
            this.iVisibleSequenceLength = 0;
        }

        void reset(NFAPart part) {
            this.state = part.state;
            this.iSequenceLength = part.iSequenceLength;
            this.iVisibleSequenceLength = part.iVisibleSequenceLength;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void returnToFirst(int keyCode) {
            this.state = KeyEventStateMachine.this.start;
            if (keyCode > 0) {
                this.iVisibleSequenceLength--;
            }
            this.iSequenceLength--;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public State addKeyCode(int keyCode) {
            this.state = this.state.getNext(keyCode);
            if (this.state == null) {
                reset();
                return State.RESET;
            }
            if (keyCode > 0) {
                this.iVisibleSequenceLength++;
            }
            this.iSequenceLength++;
            if (this.state.result != 0) {
                this.resultChar = this.state.result;
                this.sequenceLength = this.iSequenceLength;
                this.visibleSequenceLength = this.iVisibleSequenceLength;
                if (this.resultChar == -4097) {
                    return State.REWIND;
                }
                if (!this.state.hasNext()) {
                    reset();
                    return State.FULLMATCH;
                }
                return State.PARTMATCH;
            }
            return State.NOMATCH;
        }
    }

    /* loaded from: classes.dex */
    class RingBuffer {
        static final /* synthetic */ boolean $assertionsDisabled;
        private NFAPart[] buffer = new NFAPart[30];
        private int start = 0;
        private int end = 0;
        private int count = 0;

        static {
            $assertionsDisabled = !KeyEventStateMachine.class.desiredAssertionStatus();
        }

        RingBuffer() {
        }

        boolean hasItem() {
            return this.count > 0;
        }

        NFAPart getItem() {
            if (!$assertionsDisabled && this.count <= 0) {
                throw new AssertionError();
            }
            NFAPart result = this.buffer[this.start];
            this.buffer[this.start] = null;
            this.start = (this.start + 1) % 30;
            this.count--;
            return result;
        }

        void putItem(NFAPart item) {
            if (!$assertionsDisabled && this.count >= 30) {
                throw new AssertionError();
            }
            this.buffer[this.end] = item;
            this.end = (this.end + 1) % 30;
            this.count++;
        }

        int getCount() {
            return this.count;
        }
    }

    public KeyEventStateMachine() {
        this.walker.putItem(new NFAPart());
        this.walkerunused = new RingBuffer();
        for (int i = 1; i < 30; i++) {
            this.walkerunused.putItem(new NFAPart());
        }
        this.walkerhelper = new RingBuffer();
    }

    private KeyEventState addNextState(KeyEventState current, int keyCode) {
        KeyEventState next = current.getNext(keyCode);
        if (next != null) {
            return next;
        }
        KeyEventState next2 = new KeyEventState();
        current.addNextState(keyCode, next2);
        return next2;
    }

    private KeyEventState addSpecialKeyNextState(KeyEventState current, int keyCode, int specialKey) {
        KeyEventState next = addNextState(current, keyCode);
        KeyEventState spnext = addNextState(current, specialKey);
        spnext.addNextState(keyCode, next);
        return next;
    }

    public void addSequence(int[] sequence, int result) {
        KeyEventState c = this.start;
        for (int i : sequence) {
            c = addNextState(c, i);
        }
        c.setCharacter(result);
    }

    public void addSpecialKeySequence(int[] sequence, int specialKey, int result) {
        KeyEventState c = addNextState(this.start, specialKey);
        for (int i : sequence) {
            c = addSpecialKeyNextState(c, i, specialKey);
        }
        c.setCharacter(result);
    }

    public State addKeyCode(int keyCode) {
        this.sequenceLength = 0;
        this.resultChar = 0;
        NFAPart found = null;
        State resultstate = State.RESET;
        if (!this.walker.hasItem()) {
            NFAPart part = this.walkerunused.getItem();
            part.reset();
            this.walker.putItem(part);
        }
        while (true) {
            if (!this.walker.hasItem()) {
                break;
            }
            NFAPart cWalker = this.walker.getItem();
            State result = cWalker.addKeyCode(keyCode);
            if (result == State.REWIND) {
                if (this.walkerunused.hasItem()) {
                    NFAPart newwalker = this.walkerunused.getItem();
                    newwalker.reset(cWalker);
                    this.walkerhelper.putItem(newwalker);
                }
                cWalker.returnToFirst(keyCode);
                result = cWalker.addKeyCode(keyCode);
            }
            if (result == State.FULLMATCH && found == null) {
                this.walkerhelper.putItem(cWalker);
                resultstate = result;
                found = cWalker;
                break;
            }
            if (result == State.PARTMATCH || result == State.NOMATCH) {
                if (resultstate == State.RESET) {
                    resultstate = result;
                }
                this.walkerhelper.putItem(cWalker);
            } else {
                this.walkerunused.putItem(cWalker);
            }
            if (result == State.PARTMATCH && this.walkerunused.hasItem()) {
                NFAPart newwalker2 = this.walkerunused.getItem();
                newwalker2.reset();
                this.walkerhelper.putItem(newwalker2);
            }
            if (result == State.PARTMATCH && (found == null || found.sequenceLength < cWalker.sequenceLength)) {
                found = cWalker;
                resultstate = result;
            }
        }
        while (this.walker.hasItem()) {
            this.walkerunused.putItem(this.walker.getItem());
        }
        RingBuffer switchWalkerarrays = this.walkerhelper;
        this.walkerhelper = this.walker;
        this.walker = switchWalkerarrays;
        if (found != null) {
            this.sequenceLength = found.visibleSequenceLength;
            this.resultChar = found.resultChar;
            int i = 0;
            int count = this.walker.getCount();
            while (i < count) {
                NFAPart part2 = this.walker.getItem();
                this.walker.putItem(part2);
                i++;
                if (part2 == found && resultstate == State.FULLMATCH) {
                    break;
                }
                if (found.visibleSequenceLength > 1) {
                    part2.iVisibleSequenceLength -= found.visibleSequenceLength - 1;
                }
                if (part2 == found) {
                    break;
                }
            }
            while (true) {
                int i2 = i;
                i = i2 + 1;
                if (i2 >= count) {
                    break;
                }
                this.walker.putItem(this.walker.getItem());
            }
        }
        return resultstate;
    }

    public int getCharacter() {
        return this.resultChar;
    }

    public int getSequenceLength() {
        return this.sequenceLength;
    }

    public void reset() {
        while (this.walker.hasItem()) {
            this.walkerunused.putItem(this.walker.getItem());
        }
        NFAPart first = this.walkerunused.getItem();
        first.reset();
        this.walker.putItem(first);
    }
}
