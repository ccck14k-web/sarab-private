package com.android.inputmethod.latin;

import DictionaryPackage.DicatinaryPackage;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import com.android.common.speech.LoggingEvents;
import inputmethod.latin.perfectkeyboard.R;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Locale;

/* loaded from: classes.dex */
public class PerfectInputLanguageSelection extends PreferenceActivity {
    private Context mContext;
    private String mSelectedLanguages;
    private String mDefaultInputLayout = "qwerty";
    private ArrayList<Loc> mAvailableLanguages = new ArrayList<>();

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class Loc implements Comparable<Object> {
        static Collator sCollator = Collator.getInstance();
        String fullLabel;
        String label;
        String layout;
        Locale locale;

        public Loc(String label, String layout, String fullLable, Locale locale) {
            this.label = label;
            this.layout = layout;
            this.locale = locale;
            this.fullLabel = fullLable;
        }

        public String toString() {
            return this.label;
        }

        @Override // java.lang.Comparable
        public int compareTo(Object o) {
            return sCollator.compare(this.label, ((Loc) o).label);
        }
    }

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        this.mContext = this;
        addPreferencesFromResource(R.xml.language_prefs);
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        this.mSelectedLanguages = sp.getString(DictionaryEditor.PREF_SELECTED_LANGUAGES, "ar,en,ar_dvorak,en_dvorak,ar_azerty");
        String[] languageList = this.mSelectedLanguages.split(",");
        this.mAvailableLanguages = getUniqueLocales();
        PreferenceGroup parent = getPreferenceScreen();
        Preference getFromMarket = new Preference(this);
        getFromMarket.setTitle(R.string.download_dictionary);
        getFromMarket.setSummary(R.string.download_dictionary_summary);
        getFromMarket.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.PerfectInputLanguageSelection.1
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Intent goToMarket = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + PerfectInputLanguageSelection.this.getPackageName()));
                goToMarket.setFlags(268435456);
                try {
                    PerfectInputLanguageSelection.this.startActivity(goToMarket);
                    return true;
                } catch (ActivityNotFoundException e) {
                    return true;
                }
            }
        });
        parent.addPreference(getFromMarket);
        DicatinaryPackage.resetBuildersCache();
        for (int i = 0; i < this.mAvailableLanguages.size(); i++) {
            CheckBoxPreference pref = new CheckBoxPreference(this);
            Locale locale = this.mAvailableLanguages.get(i).locale;
            String title = LanguageSwitcher.toTitleCase(locale.getDisplayName(locale));
            String lang_layout = this.mAvailableLanguages.get(i).locale.getLanguage();
            if (!this.mAvailableLanguages.get(i).layout.equals("qwerty")) {
                lang_layout = String.valueOf(this.mAvailableLanguages.get(i).locale.getLanguage()) + "_" + this.mAvailableLanguages.get(i).layout;
                if (this.mAvailableLanguages.get(i).layout.equals("dvorak")) {
                    title = String.valueOf(title) + " (مزخرف)";
                } else if (this.mAvailableLanguages.get(i).layout.equals("swiss")) {
                    title = String.valueOf(title) + " (Swiss)";
                } else if (this.mAvailableLanguages.get(i).layout.equals("azerty")) {
                    title = String.valueOf(title) + " (مع التشكيل) ";
                } else if (this.mAvailableLanguages.get(i).layout.equals("qwerty2")) {
                    title = String.valueOf(title) + " (QWERTY)";
                } else if (this.mAvailableLanguages.get(i).layout.equals("colemax")) {
                    title = String.valueOf(title) + " (Colemax)";
                } else {
                    title = String.valueOf(title) + " (" + this.mAvailableLanguages.get(i).layout.toUpperCase(locale) + ")";
                }
            }
            pref.setTitle(title);
            boolean checked = isLocaleIn(lang_layout, languageList);
            pref.setChecked(checked);
            if (hasDictionary(locale)) {
                pref.setSummary(R.string.dictionary_installed);
            } else {
                pref.setSummary(R.string.dictionary_not_installed);
            }
            if (locale.getLanguage().equals(Locale.ENGLISH.getLanguage())) {
                pref.setSummary(R.string.has_dictionary);
            }
            parent.addPreference(pref);
        }
    }

    private boolean isLocaleIn(String locale, String[] list) {
        for (String str : list) {
            if (locale.equalsIgnoreCase(str)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasDictionary(Locale locale) {
        Resources res = getResources();
        Configuration conf = res.getConfiguration();
        Locale saveLocale = conf.locale;
        boolean haveDictionary = false;
        conf.locale = locale;
        res.updateConfiguration(conf, res.getDisplayMetrics());
        Dictionary bd = null;
        ArrayList<DicatinaryPackage.DictionaryBuilder> dictionaries = DictionaryEditor.getDictionary(this.mContext, res);
        if (dictionaries != null) {
            for (int i = 0; i < dictionaries.size(); i++) {
                String Lang = locale.getLanguage();
                if (Lang.equals("he")) {
                }
                bd = DictionaryFactory.createDictionaryFromManager(this.mContext, locale, Utils.getMainDictionaryResourceId(res));
            }
        }
        if (bd != null) {
            if (bd != null) {
                haveDictionary = true;
            }
            bd.close();
        }
        conf.locale = saveLocale;
        res.updateConfiguration(conf, res.getDisplayMetrics());
        return haveDictionary;
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        DicatinaryPackage.resetBuildersCache();
    }

    @Override // android.app.Activity
    protected void onPause() {
        super.onPause();
        String checkedLanguages = LoggingEvents.EXTRA_CALLING_APP_NAME;
        PreferenceGroup parent = getPreferenceScreen();
        int count = parent.getPreferenceCount();
        for (int i = 1; i < count; i++) {
            CheckBoxPreference pref = (CheckBoxPreference) parent.getPreference(i);
            if (pref.isChecked()) {
                Locale locale = this.mAvailableLanguages.get(i - 1).locale;
                if (this.mAvailableLanguages.get(i - 1).layout.equals(this.mDefaultInputLayout)) {
                    checkedLanguages = String.valueOf(checkedLanguages) + locale.getLanguage() + ",";
                } else {
                    checkedLanguages = String.valueOf(checkedLanguages) + locale.getLanguage() + "_" + this.mAvailableLanguages.get(i - 1).layout + ",";
                }
            }
        }
        if (checkedLanguages.length() < 1) {
            checkedLanguages = null;
        }
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(DictionaryEditor.PREF_SELECTED_LANGUAGES, checkedLanguages);
        SharedPreferencesCompat.apply(editor);
    }

    ArrayList<Loc> getUniqueLocales() {
        Locale l;
        String[] SplitedLanguageList = "ar,en,ar_dvorak,en_dvorak,ar_azerty,en_colemax,iw,bg,ca,ch,cs,cs_qwertz,de,de_umlaute,da,eo,es,fi,fr,fr_swiss,fr_qwerty2,fr_qwertz,it,ka,lt,la,lv,nl,pt,ru,pl,sk,sk_qwertz,sl,sv,uk,th,ir,gr,ro,no,nb,el,sr,hu,hu_qwertz,fa".split(",");
        ArrayList<Loc> uniqueLocales = new ArrayList<>();
        int LanguageCount = SplitedLanguageList.length;
        for (int i = 0; i < LanguageCount; i++) {
            String layout = "qwerty";
            if (SplitedLanguageList[i].contains("_")) {
                layout = SplitedLanguageList[i].substring(3, SplitedLanguageList[i].length());
                l = new Locale(SplitedLanguageList[i].substring(0, 2));
            } else {
                l = new Locale(SplitedLanguageList[i]);
            }
            String Lang = l.getDisplayName(l);
            Loc preprocess = new Loc(LanguageSwitcher.toTitleCase(Lang), layout, SplitedLanguageList[i], l);
            uniqueLocales.add(preprocess);
        }
        return uniqueLocales;
    }
}
