package com.android.inputmethod.latin;

import android.text.TextUtils;
import android.util.Log;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class CompatUtils {
    private static final String TAG = CompatUtils.class.getSimpleName();

    public static Class<?> getClass(String className) {
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    public static Method getMethod(Class<?> targetClass, String name, Class<?>... clsArr) {
        if (targetClass == null || TextUtils.isEmpty(name)) {
            return null;
        }
        try {
            return targetClass.getMethod(name, clsArr);
        } catch (NoSuchMethodException e) {
            return null;
        } catch (SecurityException e2) {
            return null;
        }
    }

    public static Field getField(Class<?> targetClass, String name) {
        if (targetClass == null || TextUtils.isEmpty(name)) {
            return null;
        }
        try {
            return targetClass.getField(name);
        } catch (NoSuchFieldException e) {
            return null;
        } catch (SecurityException e2) {
            return null;
        }
    }

    public static Constructor<?> getConstructor(Class<?> targetClass, Class<?>... clsArr) {
        if (targetClass == null || clsArr == null) {
            return null;
        }
        try {
            return targetClass.getConstructor(clsArr);
        } catch (NoSuchMethodException e) {
            return null;
        } catch (SecurityException e2) {
            return null;
        }
    }

    public static Object newInstance(Constructor<?> constructor, Object... args) {
        if (constructor == null) {
            return null;
        }
        try {
            return constructor.newInstance(args);
        } catch (Exception e) {
            Log.e(TAG, "Exception in newInstance: " + e.getClass().getSimpleName());
            return null;
        }
    }

    public static Object invoke(Object receiver, Object defaultValue, Method method, Object... args) {
        if (method != null) {
            try {
                return method.invoke(receiver, args);
            } catch (Exception e) {
                Log.e(TAG, "Exception in invoke: " + e.getClass().getSimpleName());
                return defaultValue;
            }
        }
        return defaultValue;
    }

    public static Object getFieldValue(Object receiver, Object defaultValue, Field field) {
        if (field != null) {
            try {
                return field.get(receiver);
            } catch (Exception e) {
                Log.e(TAG, "Exception in getFieldValue: " + e.getClass().getSimpleName());
                return defaultValue;
            }
        }
        return defaultValue;
    }

    public static void setFieldValue(Object receiver, Field field, Object value) {
        if (field != null) {
            try {
                field.set(receiver, value);
            } catch (Exception e) {
                Log.e(TAG, "Exception in setFieldValue: " + e.getClass().getSimpleName());
            }
        }
    }
}
