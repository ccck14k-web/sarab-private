package com.android.inputmethod.latin;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.UserDictionary;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Filterable;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import inputmethod.latin.perfectkeyboard.R;

/* loaded from: classes.dex */
public class AutoTextEditor extends ListActivity {
    private static final int ADD_ID = 2;
    private static final String DATABASE_NAME = "autotext.db";
    private static final int DELETE_ID = 4;
    public static boolean DataBaseChanged = false;
    private static final int EDIT_ID = 3;
    private DatabaseHelper db = null;
    private Cursor constantsCursor = null;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.db = new DatabaseHelper(this, DATABASE_NAME);
        this.constantsCursor = this.db.getReadableDatabase().rawQuery("SELECT _ID, key, value FROM autotext ORDER BY key", null);
        ListAdapter adapter = new AutoTextCursorAdapter(this, R.layout.row, this.constantsCursor, new String[]{DatabaseHelper.KEY, "value"}, new int[]{R.id.key, R.id.value});
        setContentView(R.layout.edit_list);
        setListAdapter(adapter);
        registerForContextMenu(getListView());
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.constantsCursor.deactivate();
        DataBaseChanged = true;
    }

    @Override // android.app.Activity
    protected void onResume() {
        this.constantsCursor.requery();
        super.onResume();
    }

    @Override // android.app.ListActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.constantsCursor.close();
        this.db.close();
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 2, 0, "اضافة").setIcon(android.R.drawable.ic_menu_add).setAlphabeticShortcut('a');
        return super.onCreateOptionsMenu(menu);
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 2:
                add();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override // android.app.Activity, android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        menu.add(0, 4, 0, "مسح").setAlphabeticShortcut('d');
        menu.add(0, 3, 0, "تحرير").setAlphabeticShortcut('e');
    }

    @Override // android.app.Activity
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 3:
                AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                edit(info.id);
                return true;
            case 4:
                AdapterView.AdapterContextMenuInfo info2 = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                delete(info2.id);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void add() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View addView = inflater.inflate(R.layout.add_edit, (ViewGroup) null);
        final DialogWrapper wrapper = new DialogWrapper(addView);
        new AlertDialog.Builder(this).setTitle(R.string.add_key).setView(addView).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.AutoTextEditor.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                AutoTextEditor.this.processAdd(wrapper);
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.AutoTextEditor.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).show();
    }

    private void edit(final long rowId) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View editView = inflater.inflate(R.layout.add_edit, (ViewGroup) null);
        int keyCol = this.constantsCursor.getColumnIndex(DatabaseHelper.KEY);
        int valueCol = this.constantsCursor.getColumnIndex("value");
        String key = this.constantsCursor.getString(keyCol);
        String value = this.constantsCursor.getString(valueCol);
        final DialogWrapper wrapper = new DialogWrapper(editView);
        new AlertDialog.Builder(this).setTitle(R.string.edit_key).setView(editView).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.AutoTextEditor.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                AutoTextEditor.this.processEdit(wrapper, rowId);
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.AutoTextEditor.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).show();
        wrapper.keyField.setText(key);
        wrapper.valueField.setText(value);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void processEdit(DialogWrapper wrapper, long rowId) {
        String[] args = {String.valueOf(rowId)};
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.KEY, wrapper.getKey());
        values.put("value", wrapper.getValue());
        this.db.getWritableDatabase().update("autotext", values, "_ID=?", args);
        this.constantsCursor.requery();
    }

    private void delete(long rowId) {
        if (rowId > 0) {
            processDelete(rowId);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void processAdd(DialogWrapper wrapper) {
        ContentValues values = new ContentValues(2);
        values.put(DatabaseHelper.KEY, wrapper.getKey());
        values.put("value", wrapper.getValue());
        this.db.getWritableDatabase().insert("autotext", DatabaseHelper.KEY, values);
        this.constantsCursor.requery();
    }

    private void processDelete(long rowId) {
        String[] args = {String.valueOf(rowId)};
        this.db.getWritableDatabase().delete("autotext", "_ID=?", args);
        this.constantsCursor.requery();
    }

    /* loaded from: classes.dex */
    public class AutoTextCursorAdapter extends SimpleCursorAdapter implements Filterable {
        private Context context;
        private int layout;

        public AutoTextCursorAdapter(Context context, int layout, Cursor c, String[] from, int[] to) {
            super(context, layout, c, from, to);
            this.context = context;
            this.layout = layout;
        }

        @Override // android.widget.ResourceCursorAdapter, android.widget.CursorAdapter
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            Cursor c = getCursor();
            LayoutInflater inflater = LayoutInflater.from(context);
            View v = inflater.inflate(this.layout, parent, false);
            int keyCol = c.getColumnIndex(DatabaseHelper.KEY);
            int valueCol = c.getColumnIndex("value");
            String string = String.valueOf(c.getString(keyCol)) + "->" + c.getString(valueCol);
            TextView name_text = (TextView) v.findViewById(R.id.key);
            if (name_text != null) {
                name_text.setText(string);
            }
            return v;
        }

        @Override // android.widget.SimpleCursorAdapter, android.widget.CursorAdapter
        public void bindView(View v, Context context, Cursor c) {
            int keyCol = c.getColumnIndex(DatabaseHelper.KEY);
            int valueCol = c.getColumnIndex("value");
            String string = String.valueOf(c.getString(keyCol)) + " => " + c.getString(valueCol);
            TextView name_text = (TextView) v.findViewById(R.id.key);
            if (name_text != null) {
                name_text.setText(string);
            }
        }

        @Override // android.widget.CursorAdapter
        public Cursor runQueryOnBackgroundThread(CharSequence constraint) {
            if (getFilterQueryProvider() != null) {
                return getFilterQueryProvider().runQuery(constraint);
            }
            StringBuilder buffer = null;
            String[] args = null;
            if (constraint != null) {
                buffer = new StringBuilder();
                buffer.append("UPPER(");
                buffer.append(DatabaseHelper.KEY);
                buffer.append(") GLOB ?");
                args = new String[]{String.valueOf(constraint.toString().toUpperCase()) + "*"};
            }
            return this.context.getContentResolver().query(UserDictionary.Words.CONTENT_URI, null, buffer == null ? null : buffer.toString(), args, "key ASC");
        }
    }
}
