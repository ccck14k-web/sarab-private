package com.android.inputmethod.latin;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Pure-Java reader and suggestion engine for the binary word-list format used by the
 * original keyboard (magic 0x78B1, "patricia trie" with variable length node addresses).
 *
 * It replaces the original 32-bit-only native library (libjni_latinime_pt2_new.so), which
 * cannot be loaded on 64-bit-only devices.
 *
 * <p>This class deliberately has no Android dependency so it can be unit-tested on a plain JVM.
 *
 * <h3>File format (as reverse engineered from the original dictionary)</h3>
 * <pre>
 *  header : 0x78 0xB1, version(1 byte), flags(2 bytes)            = 5 bytes
 *  node   : count (1 byte, or 2 bytes if bit7 set: ((b0&amp;0x7F)&lt;&lt;8)|b1), then `count` groups
 *  group  : flags(1) chars(...) [freq(1) if terminal] [children address] [bigram list]
 *     flags: 0xC0 address size (0=none, 0x40=1, 0x80=2, 0xC0=3 bytes), 0x20 = several chars
 *            (terminated by 0x1F), 0x10 = terminal (word ends here), 0x08 = shortcuts,
 *            0x04 = has bigrams
 *     char : one byte if &gt;= 0x20, otherwise 3 bytes (b0&lt;&lt;16|b1&lt;&lt;8|b2)
 *     address: unsigned, relative to the first byte of the address field
 * </pre>
 */
public final class DictionaryEngine {
    public static final int MAX_WORD_LENGTH = 48;
    public static final int MAX_WORDS = 18;
    public static final int MAX_PROXIMITY = 16;

    /** Flags understood by {@link #getSuggestions}. Same bit values as BinaryDictionary. */
    public static final int FLAG_T9_MODE = 8;
    public static final int FLAG_SUGGEST_MISSING_SPACE = 1 << 22;

    private static final int HEADER_SIZE = 5;
    private static final int TYPED_LETTER_MULTIPLIER = 2;
    private static final int FULL_WORD_MULTIPLIER = 2;

    private final byte[] mData;
    private final int mRoot;

    // ------------------------------------------------------------------ construction

    public DictionaryEngine(byte[] data) {
        if (data == null || data.length < HEADER_SIZE + 1
                || (data[0] & 0xFF) != 0x78 || (data[1] & 0xFF) != 0xB1) {
            throw new IllegalArgumentException("Not a valid dictionary (bad magic number)");
        }
        mData = data;
        mRoot = HEADER_SIZE;
    }

    public static DictionaryEngine open(String path, long offset, long length) throws IOException {
        RandomAccessFile f = new RandomAccessFile(path, "r");
        try {
            long len = length > 0 ? length : f.length() - offset;
            if (len <= 0 || len > 64L * 1024 * 1024) {
                throw new IOException("Bad dictionary length: " + len);
            }
            byte[] data = new byte[(int) len];
            f.seek(offset);
            f.readFully(data);
            return new DictionaryEngine(data);
        } finally {
            f.close();
        }
    }

    // ------------------------------------------------------------------ low level trie access

    private int readCount(int[] posRef) {
        int p = posRef[0];
        int c = mData[p] & 0xFF;
        if ((c & 0x80) != 0) {
            posRef[0] = p + 2;
            return ((c & 0x7F) << 8) | (mData[p + 1] & 0xFF);
        }
        posRef[0] = p + 1;
        return c;
    }

    /** One parsed group of a node. */
    private static final class Group {
        int[] chars = new int[4];
        int nChars;
        int freq = -1;      // -1 = not a terminal
        int child;          // absolute address of the child node, 0 if none
    }

    private final HashMap<Integer, Group[]> mNodeCache = new HashMap<Integer, Group[]>();
    private static final int NODE_CACHE_DEPTH = 3;
    private static final int NODE_CACHE_MAX = 6000;

    /** The first levels of the trie are visited by almost every query, so keep them parsed. */
    private Group[] parseNodeCached(int pos, int depth) {
        if (depth > NODE_CACHE_DEPTH) return parseNode(pos);
        Group[] g = mNodeCache.get(pos);
        if (g == null) {
            g = parseNode(pos);
            if (mNodeCache.size() < NODE_CACHE_MAX) mNodeCache.put(pos, g);
        }
        return g;
    }

    /** Parses every group of the node at {@code pos}. */
    private Group[] parseNode(int pos) {
        int[] ref = {pos};
        int count = readCount(ref);
        Group[] groups = new Group[count];
        int p = ref[0];
        final byte[] d = mData;
        for (int i = 0; i < count; i++) {
            Group g = new Group();
            int flags = d[p++] & 0xFF;
            int c;
            int b = d[p] & 0xFF;
            if (b >= 0x20) { c = b; p += 1; }
            else { c = (b << 16) | ((d[p + 1] & 0xFF) << 8) | (d[p + 2] & 0xFF); p += 3; }
            g.chars[g.nChars++] = c;
            if ((flags & 0x20) != 0) {
                while ((d[p] & 0xFF) != 0x1F) {
                    b = d[p] & 0xFF;
                    if (b >= 0x20) { c = b; p += 1; }
                    else { c = (b << 16) | ((d[p + 1] & 0xFF) << 8) | (d[p + 2] & 0xFF); p += 3; }
                    if (g.nChars == g.chars.length) g.chars = Arrays.copyOf(g.chars, g.nChars * 2);
                    g.chars[g.nChars++] = c;
                }
                p += 1; // terminator
            }
            if ((flags & 0x10) != 0) g.freq = d[p++] & 0xFF;
            int addrSize = (flags >> 6) & 3;
            if (addrSize != 0) {
                int fieldStart = p;
                int v = 0;
                for (int k = 0; k < addrSize; k++) v = (v << 8) | (d[p + k] & 0xFF);
                p += addrSize;
                g.child = fieldStart + v;
            }
            if ((flags & 0x08) != 0) { // shortcut targets: skip (size is stored in 2 bytes)
                int size = ((d[p] & 0xFF) << 8) | (d[p + 1] & 0xFF);
                p += Math.max(size, 2);
            }
            if ((flags & 0x04) != 0) { // bigram attributes: skip
                while (true) {
                    int a = d[p++] & 0xFF;
                    p += (a >> 4) & 3;
                    if ((a & 0x80) == 0) break;
                }
            }
            groups[i] = g;
        }
        return groups;
    }

    // ------------------------------------------------------------------ character folding

    private static final char[] LATIN_FOLD = new char[0x250];

    static {
        for (int c = 0; c < LATIN_FOLD.length; c++) {
            int r = c;
            if (c >= 'A' && c <= 'Z') {
                r = c + 32;
            } else if (c >= 0xC0) {
                String n = Normalizer.normalize(String.valueOf((char) c), Normalizer.Form.NFD);
                char base = n.charAt(0);
                r = Character.toLowerCase(base);
            }
            LATIN_FOLD[c] = (char) r;
        }
    }

    /**
     * Folds a character so that look-alike spellings match: case and accents for Latin
     * scripts, and the usual interchangeable letters for Arabic (the keyboard's main use).
     * Returns 0 for characters that must be ignored (Arabic diacritics, tatweel).
     */
    static int fold(int c) {
        if (c < 0x250) return LATIN_FOLD[c];
        if (c >= 0x0600 && c <= 0x06FF) {
            switch (c) {
                case 0x0622: case 0x0623: case 0x0625: case 0x0671: case 0x0672: case 0x0673:
                    return 0x0627;            // alef variants -> ا
                case 0x0649: case 0x06CC: case 0x0626:
                    return 0x064A;            // ى ی ئ -> ي
                case 0x0629:
                    return 0x0647;            // ة -> ه
                case 0x0624:
                    return 0x0648;            // ؤ -> و
                case 0x06A9: case 0x06AF:
                    return 0x0643;            // ک گ -> ك  (Iraqi "g")
                case 0x0686:
                    return 0x062C;            // چ -> ج  (Iraqi "ch")
                case 0x067E:
                    return 0x0628;            // پ -> ب
                case 0x06A4:
                    return 0x0641;            // ڤ -> ف
                case 0x0698:
                    return 0x0632;            // ژ -> ز
                case 0x0640:
                    return 0;                 // tatweel
                default:
                    if ((c >= 0x064B && c <= 0x065F) || c == 0x0670) return 0; // tashkeel
                    return c;
            }
        }
        return Character.toLowerCase(c);
    }

    // ------------------------------------------------------------------ isValidWord

    /**
     * A word is valid when it is stored as a terminal. A typed capital letter matches the
     * lowercase dictionary letter (so "Hello" is valid if "hello" is), but not the reverse.
     */
    public synchronized boolean isValidWord(char[] word, int length) {
        if (length <= 0 || length > MAX_WORD_LENGTH) return false;
        int[] w = new int[length];
        int n = 0;
        for (int i = 0; i < length; i++) {
            int f = fold(word[i]);
            if (f == 0 && word[i] != 0) continue; // ignore Arabic diacritics when typed
            w[n++] = word[i];
        }
        return n > 0 && validRec(mRoot, w, 0, n);
    }

    private static boolean charMatches(int dict, int typed) {
        if (dict == typed) return true;
        int f = fold(typed);
        // typed upper case may match a lower case dictionary char
        if (Character.toLowerCase(typed) == dict) return true;
        // Arabic: identical after folding (alef/hamza, ya/alef-maqsura, ...) counts as the same word
        return f != 0 && typed >= 0x0600 && typed <= 0x06FF && fold(dict) == f;
    }

    private boolean validRec(int nodePos, int[] w, int idx, int n) {
        Group[] groups = parseNode(nodePos);
        for (Group g : groups) {
            int k = 0;
            while (k < g.nChars && idx + k < n && charMatches(g.chars[k], w[idx + k])) k++;
            if (k != g.nChars) continue;
            int next = idx + g.nChars;
            if (next == n) {
                if (g.freq >= 0) return true;
            } else if (g.child != 0) {
                if (validRec(g.child, w, next, n)) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ suggestions

    // Search state (instance fields: the engine is used one query at a time).
    private int mN;                 // number of typed letters
    private int[] mPrimary;         // folded primary code of each typed letter
    private int[][] mAlternatives;  // folded proximity codes (excluding primary) per letter
    private boolean mT9;
    private int mMaxDepth;
    private int mMaxProximity;
    private int mMaxEdits;
    private final int[] mOut = new int[MAX_WORD_LENGTH + 1];
    private Map<String, Integer> mBest;

    /**
     * @param inputCodes  flat array, {@link #MAX_PROXIMITY} codes per typed letter (-1 padded);
     *                    the first code of each letter is the key that was actually hit
     * @param codesSize   number of typed letters
     * @param outChars    receives {@link #MAX_WORDS} * {@link #MAX_WORD_LENGTH} chars, 0 padded
     * @param outScores   receives {@link #MAX_WORDS} scores, best first
     * @return number of suggestions written
     */
    public synchronized int getSuggestions(int[] inputCodes, int codesSize, int flags,
                                           char[] outChars, int[] outScores) {
        Arrays.fill(outChars, (char) 0);
        Arrays.fill(outScores, 0);
        if (codesSize <= 0 || codesSize >= MAX_WORD_LENGTH) return 0;

        mT9 = (flags & FLAG_T9_MODE) != 0;
        prepareInput(inputCodes, codesSize);
        if (mN == 0) return 0;

        mMaxDepth = Math.min(MAX_WORD_LENGTH - 1, mN + Math.max(4, mN));
        mMaxProximity = mT9 ? 0 : Math.max(1, mN / 2 + 1);
        mMaxEdits = mT9 ? 0 : (mN < 4 ? 1 : 2);
        mBest = new HashMap<String, Integer>();

        search(mRoot, 0, 0, 0, 0, 0, 0, 0, 0, -1);

        if ((flags & FLAG_SUGGEST_MISSING_SPACE) != 0 && mN >= 2) {
            suggestSplits();
        }
        return collect(outChars, outScores);
    }

    private void prepareInput(int[] codes, int size) {
        int[] prim = new int[size];
        int[][] alts = new int[size][];
        int n = 0;
        for (int i = 0; i < size; i++) {
            int base = i * MAX_PROXIMITY;
            if (base >= codes.length) break;
            int p = fold(codes[base]);
            if (codes[base] <= 0) continue;
            if (p == 0) continue; // typed diacritic: ignore
            int[] tmp = new int[MAX_PROXIMITY];
            int tn = 0;
            for (int j = 1; j < MAX_PROXIMITY && base + j < codes.length; j++) {
                int c = codes[base + j];
                if (c <= 0) break;
                int f = fold(c);
                if (f == 0 || f == p) continue;
                boolean dup = false;
                for (int t = 0; t < tn; t++) if (tmp[t] == f) { dup = true; break; }
                if (!dup) tmp[tn++] = f;
            }
            prim[n] = p;
            alts[n] = Arrays.copyOf(tmp, tn);
            n++;
        }
        mN = n;
        mPrimary = prim;
        mAlternatives = alts;
    }

    /** 2 = the typed key itself, 1 = a neighbouring key, 0 = no match. */
    private int matchType(int dictFolded, int idx) {
        if (idx >= mN) return 0;
        if (mPrimary[idx] == dictFolded) return 2;
        int[] a = mAlternatives[idx];
        for (int i = 0; i < a.length; i++) {
            if (a[i] == dictFolded) return mT9 ? 2 : 1;
        }
        return 0;
    }

    // omit/extra/trans: how many times each edit kind was used so far.
    private void search(int nodePos, int outLen, int in, int exact, int prox,
                        int omit, int extra, int trans, int apos, int transWant) {
        Group[] groups = parseNodeCached(nodePos, outLen);
        for (Group g : groups) {
            walkGroup(g, 0, outLen, in, exact, prox, omit, extra, trans, apos, transWant);
        }
    }

    private void walkGroup(Group g, int ci, int outLen, int in, int exact, int prox,
                           int omit, int extra, int trans, int apos, int transWant) {
        if (ci == g.nChars) {
            // a pending transposition may continue into the child node, but a word may not end on it
            if (transWant < 0 && g.freq >= 0) emit(g.freq, outLen, in, exact, prox, omit, extra, trans, apos);
            boolean canGrow = in < mN || (prox == 0 && omit == 0 && extra == 0 && trans == 0);
            if (g.child != 0 && canGrow && (outLen < mMaxDepth || transWant >= 0)) {
                search(g.child, outLen, in, exact, prox, omit, extra, trans, apos, transWant);
            }
            return;
        }
        if (outLen >= MAX_WORD_LENGTH - 1) return;
        final int dictChar = g.chars[ci];
        final int f = fold(dictChar);
        if (f == 0) { // diacritic stored in the dictionary: never needs a typed key
            mOut[outLen] = dictChar;
            walkGroup(g, ci + 1, outLen + 1, in, exact, prox, omit, extra, trans, apos, transWant);
            return;
        }
        mOut[outLen] = dictChar;

        // pending transposition: this dictionary char must equal the first swapped typed char
        if (transWant >= 0) {
            if (f == transWant) {
                walkGroup(g, ci + 1, outLen + 1, in, exact + 1, prox, omit, extra, trans + 1, apos, -1);
            }
            return;
        }

        if (in >= mN) {
            // Everything typed has been matched: this is a completion of a longer word.
            // Only exact, edit-free prefixes are completed; otherwise the search explodes.
            if (outLen < mMaxDepth && prox == 0 && omit == 0 && extra == 0 && trans == 0) {
                walkGroup(g, ci + 1, outLen + 1, in, exact, prox, omit, extra, trans, apos, -1);
            }
            return;
        }

        // people rarely type the apostrophe: let it be skipped for free (dont -> don't, im -> I'm)
        if (dictChar == 39 && in > 0) {
            walkGroup(g, ci + 1, outLen + 1, in, exact, prox, omit, extra, trans, apos + 1, -1);
        }

        // 1) the dictionary char corresponds to the typed letter at `in`
        int m = matchType(f, in);
        if (m == 2) {
            walkGroup(g, ci + 1, outLen + 1, in + 1, exact + 1, prox, omit, extra, trans, apos, -1);
        } else if (m == 1 && prox < mMaxProximity) {
            walkGroup(g, ci + 1, outLen + 1, in + 1, exact, prox + 1, omit, extra, trans, apos, -1);
        }

        if (mMaxEdits == 0) return;
        int edits = omit + extra + trans;
        if (edits >= mMaxEdits) return;

        // 2) the user omitted this letter: consume the dictionary char only
        if (omit == 0 && in > 0) {
            walkGroup(g, ci + 1, outLen + 1, in, exact, prox, omit + 1, extra, trans, apos, -1);
        }
        // 3) the user typed an extra letter before this one: skip typed[in], match typed[in+1]
        if (extra == 0 && in + 1 < mN) {
            int m2 = matchType(f, in + 1);
            if (m2 == 2) {
                walkGroup(g, ci + 1, outLen + 1, in + 2, exact + 1, prox, omit, extra + 1, trans, apos, -1);
            } else if (m2 == 1 && prox < mMaxProximity) {
                walkGroup(g, ci + 1, outLen + 1, in + 2, exact, prox + 1, omit, extra + 1, trans, apos, -1);
            }
        }
        // 4) two neighbouring letters were swapped: dict "ab" typed as "ba"
        if (trans == 0 && in + 1 < mN && matchType(f, in + 1) == 2) {
            // consume typed[in+1] now; the next dictionary char must equal typed[in]
            walkGroupTrans(g, ci + 1, outLen + 1, in + 2, exact, prox, omit, extra, trans, apos, mPrimary[in]);
        }
    }

    private void walkGroupTrans(Group g, int ci, int outLen, int in, int exact, int prox,
                                int omit, int extra, int trans, int apos, int want) {
        walkGroup(g, ci, outLen, in, exact + 1, prox, omit, extra, trans, apos, want);
    }

    private void emit(int freq, int outLen, int in, int exact, int prox,
                      int omit, int extra, int trans, int apos) {
        if (outLen == 0) return;
        int remaining = mN - in;
        int extraUsed = extra;
        if (remaining == 1 && extraUsed == 0 && !mT9 && mMaxEdits > 0
                && (omit + extra + trans) < mMaxEdits) {
            extraUsed = 1;          // typed one letter too many at the very end
        } else if (remaining != 0) {
            return;
        }
        int edits = omit + extraUsed + trans;

        long score = freq == 0 ? 1 : freq;
        int bonus = Math.min(exact, 20);
        score <<= bonus;                          // each exactly-typed letter doubles the score
        // typo demotion: a forgotten letter is the most common slip, so it is demoted the least
        for (int i = 0; i < trans + extraUsed; i++) score = score * 3 / 5;
        for (int i = 0; i < omit; i++) score = score * 9 / 10;
        if (prox > 0) score = score * 4 / (4 + prox);
        int letters = outLen - apos;           // apostrophes the user did not type do not count
        boolean sameLength = letters == mN;
        if (sameLength && omit == 0 && extraUsed == 0) score *= FULL_WORD_MULTIPLIER;
        int extraLen = letters - mN;
        if (extraLen > 0 && in >= mN) score = score * 6 / (6 + extraLen); // completions rank lower
        if (score < 1) score = 1;
        if (score > Integer.MAX_VALUE / 2) score = Integer.MAX_VALUE / 2;

        String w = new String(mOut, 0, outLen);
        Integer old = mBest.get(w);
        if (old == null || old < score) mBest.put(w, (int) score);
    }

    /** "helloworld" -> "hello world": offered when the user forgot the space bar. */
    private void suggestSplits() {
        Map<String, Integer> saved = mBest;
        int savedN = mN;
        int[] savedPrim = mPrimary;
        int[][] savedAlt = mAlternatives;
        List<String[]> found = new ArrayList<String[]>();
        for (int split = 1; split < savedN; split++) {
            String a = bestExact(savedPrim, savedAlt, 0, split);
            String b = bestExact(savedPrim, savedAlt, split, savedN);
            if (a != null && b != null) found.add(new String[]{a, b});
        }
        mBest = saved; mN = savedN; mPrimary = savedPrim; mAlternatives = savedAlt;
        for (String[] ab : found) {
            String joined = ab[0] + " " + ab[1];
            if (joined.length() < MAX_WORD_LENGTH && !mBest.containsKey(joined)) {
                mBest.put(joined, 2); // always ranked below real single-word suggestions
            }
        }
    }

    private String bestExact(int[] prim, int[][] alt, int from, int to) {
        int len = to - from;
        if (len < 2) return null; // single letters are not worth splitting on
        mN = len;
        mPrimary = Arrays.copyOfRange(prim, from, to);
        mAlternatives = Arrays.copyOfRange(alt, from, to);
        mMaxDepth = len;
        mMaxProximity = 0;
        mMaxEdits = 0;
        mBest = new HashMap<String, Integer>();
        search(mRoot, 0, 0, 0, 0, 0, 0, 0, 0, -1);
        String best = null;
        int bestScore = -1;
        for (Map.Entry<String, Integer> e : mBest.entrySet()) {
            if (e.getKey().length() == len && e.getValue() > bestScore) {
                bestScore = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    private int collect(char[] outChars, int[] outScores) {
        List<Map.Entry<String, Integer>> list = new ArrayList<Map.Entry<String, Integer>>(mBest.entrySet());
        java.util.Collections.sort(list, new java.util.Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> a, Map.Entry<String, Integer> b) {
                int c = b.getValue().compareTo(a.getValue());
                if (c != 0) return c;
                c = Integer.compare(a.getKey().length(), b.getKey().length());
                return c != 0 ? c : a.getKey().compareTo(b.getKey());
            }
        });
        int count = Math.min(MAX_WORDS, list.size());
        for (int i = 0; i < count; i++) {
            String w = list.get(i).getKey();
            int len = Math.min(w.length(), MAX_WORD_LENGTH);
            w.getChars(0, len, outChars, i * MAX_WORD_LENGTH);
            outScores[i] = list.get(i).getValue();
        }
        return count;
    }

    // ------------------------------------------------------------------ bigrams

    /**
     * Next-word prediction. The bundled dictionaries carry no bigram data (verified on the
     * original word list), so this returns nothing; the user's own bigram history is handled
     * separately by UserBigramDictionary.
     */
    public synchronized int getBigrams(char[] previousWord, int previousLength, int[] inputCodes,
                                       int codesSize, char[] outChars, int[] outScores,
                                       int maxWordLength, int maxBigrams) {
        return 0;
    }
}
