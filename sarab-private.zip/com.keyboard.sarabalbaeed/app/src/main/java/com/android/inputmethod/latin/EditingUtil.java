package com.android.inputmethod.latin;

import android.text.TextUtils;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class EditingUtil {
    private static final int INVALID_CURSOR_POSITION = -1;
    private static final int LOOKBACK_CHARACTER_NUM = 97;
    private static Method sMethodGetSelectedText;
    private static Method sMethodSetComposingRegion;
    private static boolean sMethodsInitialized;
    private static final Pattern spaceRegex = Pattern.compile("\\s+");

    private EditingUtil() {
    }

    /* loaded from: classes.dex */
    public static class SelectedWord {
        public final int mEnd;
        public final int mStart;
        public final CharSequence mWord;

        public SelectedWord(int start, int end, CharSequence word) {
            this.mStart = start;
            this.mEnd = end;
            this.mWord = word;
        }
    }

    public static void appendText(InputConnection connection, String newText) {
        if (connection != null) {
            connection.finishComposingText();
            String text = newText;
            CharSequence charBeforeCursor = connection.getTextBeforeCursor(1, 0);
            if (charBeforeCursor != null && !charBeforeCursor.equals(" ") && charBeforeCursor.length() > 0) {
                text = " " + text;
            }
            connection.setComposingText(text, 1);
        }
    }

    private static int getCursorPosition(InputConnection connection) {
        ExtractedText extracted;
        if (connection == null || (extracted = connection.getExtractedText(new ExtractedTextRequest(), 0)) == null) {
            return -1;
        }
        return extracted.startOffset + extracted.selectionStart;
    }

    public static String getWordAtCursor(InputConnection connection, String separators) {
        Range r = getWordRangeAtCursor(connection, separators);
        if (r == null) {
            return null;
        }
        return r.mWord;
    }

    public static void deleteWordAtCursor(InputConnection connection, String separators) {
        Range range = getWordRangeAtCursor(connection, separators);
        if (range != null) {
            connection.finishComposingText();
            int newCursor = getCursorPosition(connection) - range.mCharsBefore;
            connection.setSelection(newCursor, newCursor);
            connection.deleteSurroundingText(0, range.mCharsBefore + range.mCharsAfter);
        }
    }

    /* loaded from: classes.dex */
    public static class Range {
        public final int mCharsAfter;
        public final int mCharsBefore;
        public final String mWord;

        public Range(int charsBefore, int charsAfter, String word) {
            if (charsBefore < 0 || charsAfter < 0) {
                throw new IndexOutOfBoundsException();
            }
            this.mCharsBefore = charsBefore;
            this.mCharsAfter = charsAfter;
            this.mWord = word;
        }
    }

    public static void deleteWordBeforeCursor(InputConnection connection, String separators) {
        Range range = getWordRangeBeforeCursor(connection, separators, null);
        if (range != null) {
            connection.finishComposingText();
            int newCursor = (getCursorPosition(connection) - range.mCharsAfter) + range.mCharsBefore;
            connection.setSelection(newCursor, newCursor);
            connection.deleteSurroundingText(0, range.mCharsAfter - range.mCharsBefore);
        }
    }

    private static Range getWordRangeBeforeCursor(InputConnection connection, String sep, Range range) {
        CharSequence before;
        if (connection == null || sep == null || (before = connection.getTextBeforeCursor(1000, 0)) == null) {
            return null;
        }
        int WordEnd = before.length();
        while (WordEnd > 0 && isWhitespace(before.charAt(WordEnd - 1), sep)) {
            WordEnd--;
        }
        int WordStart = WordEnd;
        while (WordStart > 0 && !isWhitespace(before.charAt(WordStart - 1), sep)) {
            WordStart--;
        }
        int WordEnd2 = before.length();
        if (WordStart < 0) {
            return null;
        }
        String word = before.toString().substring(WordStart, WordEnd2);
        return range != null ? range : new Range(WordStart, WordEnd2, word);
    }

    private static Range getWordRangeAtCursor(InputConnection connection, String sep) {
        if (connection == null || sep == null) {
            return null;
        }
        CharSequence before = connection.getTextBeforeCursor(1000, 0);
        CharSequence after = connection.getTextAfterCursor(1000, 0);
        if (before == null || after == null) {
            return null;
        }
        int start = before.length();
        while (start > 0 && !isWhitespace(before.charAt(start - 1), sep)) {
            start--;
        }
        int end = -1;
        do {
            end++;
            if (end >= after.length()) {
                break;
            }
        } while (!isWhitespace(after.charAt(end), sep));
        int cursor = getCursorPosition(connection);
        if (start < 0 || cursor + end > after.length() + before.length()) {
            return null;
        }
        String word = String.valueOf(before.toString().substring(start, before.length())) + after.toString().substring(0, end);
        return new Range(before.length() - start, end, word);
    }

    private static boolean isWhitespace(int code, String whitespace) {
        return whitespace.contains(String.valueOf((char) code));
    }

    public static CharSequence getPreviousWord(InputConnection connection, String sentenceSeperators) {
        if (connection == null) {
            return null;
        }
        CharSequence prev = connection.getTextBeforeCursor(LOOKBACK_CHARACTER_NUM, 0);
        return getPreviousWord(prev, sentenceSeperators);
    }

    public static CharSequence getPreviousWord(CharSequence prev, String sentenceSeperators) {
        if (prev == null) {
            return null;
        }
        String[] w = spaceRegex.split(prev);
        if (w.length < 2 || w[w.length - 2].length() <= 0) {
            return null;
        }
        char lastChar = w[w.length - 2].charAt(w[w.length - 2].length() - 1);
        if (sentenceSeperators.contains(String.valueOf(lastChar))) {
            return null;
        }
        return w[w.length - 2];
    }

    public static CharSequence getThisWord(InputConnection connection, String sentenceSeperators) {
        if (connection == null) {
            return null;
        }
        CharSequence prev = connection.getTextBeforeCursor(LOOKBACK_CHARACTER_NUM, 0);
        return getThisWord(prev, sentenceSeperators);
    }

    public static CharSequence getThisWord(CharSequence prev, String sentenceSeperators) {
        if (prev == null) {
            return null;
        }
        String[] w = spaceRegex.split(prev);
        if (w.length < 1 || w[w.length - 1].length() <= 0) {
            return null;
        }
        char lastChar = w[w.length - 1].charAt(w[w.length - 1].length() - 1);
        if (sentenceSeperators.contains(String.valueOf(lastChar))) {
            return null;
        }
        return w[w.length - 1];
    }

    private static boolean isWordBoundary(CharSequence singleChar, String wordSeparators) {
        return TextUtils.isEmpty(singleChar) || wordSeparators.contains(singleChar);
    }

    public static SelectedWord getWordAtCursorOrSelection(InputConnection ic, int selStart, int selEnd, String wordSeparators) {
        if (selStart == selEnd) {
            Range range = getWordRangeAtCursor(ic, wordSeparators);
            if (range == null || TextUtils.isEmpty(range.mWord)) {
                return null;
            }
            return new SelectedWord(selStart - range.mCharsBefore, range.mCharsAfter + selEnd, range.mWord);
        }
        if (ic == null) {
            return null;
        }
        CharSequence charsBefore = ic.getTextBeforeCursor(1, 0);
        if (!isWordBoundary(charsBefore, wordSeparators)) {
            return null;
        }
        CharSequence charsAfter = ic.getTextAfterCursor(1, 0);
        if (!isWordBoundary(charsAfter, wordSeparators)) {
            return null;
        }
        CharSequence touching = getSelectedText(ic, selStart, selEnd);
        if (TextUtils.isEmpty(touching)) {
            return null;
        }
        int length = touching.length();
        for (int i = 0; i < length; i++) {
            if (wordSeparators.contains(touching.subSequence(i, i + 1))) {
                return null;
            }
        }
        return new SelectedWord(selStart, selEnd, touching);
    }

    public static void underlineWord(InputConnection ic, SelectedWord word) {
        if (!sMethodsInitialized) {
            initializeMethodsForReflection();
        }
        if (sMethodSetComposingRegion != null) {
            try {
                sMethodSetComposingRegion.invoke(ic, Integer.valueOf(word.mStart), Integer.valueOf(word.mEnd));
            } catch (IllegalAccessException e) {
            } catch (IllegalArgumentException e2) {
            } catch (InvocationTargetException e3) {
            }
        }
    }

    private static void initializeMethodsForReflection() {
        try {
            sMethodGetSelectedText = InputConnection.class.getMethod("getSelectedText", Integer.TYPE);
            sMethodSetComposingRegion = InputConnection.class.getMethod("setComposingRegion", Integer.TYPE, Integer.TYPE);
        } catch (NoSuchMethodException e) {
        }
        sMethodsInitialized = true;
    }

    private static CharSequence getSelectedText(InputConnection ic, int selStart, int selEnd) {
        if (!sMethodsInitialized) {
            initializeMethodsForReflection();
        }
        if (sMethodGetSelectedText != null) {
            try {
                CharSequence result = (CharSequence) sMethodGetSelectedText.invoke(ic, 0);
                return result;
            } catch (IllegalAccessException e) {
            } catch (IllegalArgumentException e2) {
            } catch (InvocationTargetException e3) {
            }
        }
        ic.setSelection(selStart, selEnd);
        CharSequence result2 = ic.getTextAfterCursor(selEnd - selStart, 0);
        ic.setSelection(selStart, selEnd);
        return result2;
    }
}
