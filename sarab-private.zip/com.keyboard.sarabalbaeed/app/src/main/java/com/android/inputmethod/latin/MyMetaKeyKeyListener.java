package com.android.inputmethod.latin;

import android.text.Editable;
import android.text.NoCopySpan;
import android.text.Spannable;
import android.text.Spanned;
import android.view.KeyEvent;
import android.view.View;

/* loaded from: classes.dex */
public abstract class MyMetaKeyKeyListener {
    private static final int LOCKED = 67108881;
    private static final int LOCKED_SHIFT = 8;
    public static final int META_ALT_LOCKED = 512;
    private static final long META_ALT_MASK = 2207646745090L;
    public static final int META_ALT_ON = 2;
    private static final long META_ALT_PRESSED = 8589934592L;
    private static final long META_ALT_RELEASED = 2199023255552L;
    private static final long META_ALT_USED = 33554432;
    public static final int META_CAP_LOCKED = 256;
    private static final long META_CAP_PRESSED = 4294967296L;
    private static final long META_CAP_RELEASED = 1099511627776L;
    private static final long META_CAP_USED = 16777216;
    public static final int META_SELECTING = 65536;
    private static final long META_SHIFT_MASK = 1103823372545L;
    public static final int META_SHIFT_ON = 1;
    public static final int META_SYM_LOCKED = 1024;
    private static final long META_SYM_MASK = 4415293490180L;
    public static final int META_SYM_ON = 4;
    private static final long META_SYM_PRESSED = 17179869184L;
    private static final long META_SYM_RELEASED = 4398046511104L;
    private static final long META_SYM_USED = 67108864;
    private static final int PRESSED = 16777233;
    private static final int PRESSED_SHIFT = 32;
    private static final int RELEASED = 33554449;
    private static final int RELEASED_SHIFT = 40;
    private static final int USED = 50331665;
    private static final int USED_SHIFT = 24;
    private static final Object CAP = new NoCopySpan.Concrete();
    private static final Object ALT = new NoCopySpan.Concrete();
    private static final Object SYM = new NoCopySpan.Concrete();
    private static final Object SELECTING = new NoCopySpan.Concrete();

    public static void resetMetaState(Spannable text) {
        text.removeSpan(CAP);
        text.removeSpan(ALT);
        text.removeSpan(SYM);
        text.removeSpan(SELECTING);
    }

    public static final int getMetaState(CharSequence text) {
        return getActive(text, CAP, 1, META_CAP_LOCKED) | getActive(text, ALT, 2, META_ALT_LOCKED) | getActive(text, SYM, 4, META_SYM_LOCKED) | getActive(text, SELECTING, META_SELECTING, META_SELECTING);
    }

    public static final int getMetaState(CharSequence text, int meta) {
        switch (meta) {
            case 1:
                return getActive(text, CAP, 1, 2);
            case 2:
                return getActive(text, ALT, 1, 2);
            case 4:
                return getActive(text, SYM, 1, 2);
            case META_SELECTING /* 65536 */:
                return getActive(text, SELECTING, 1, 2);
            default:
                return 0;
        }
    }

    private static int getActive(CharSequence text, Object meta, int on, int lock) {
        if (!(text instanceof Spanned)) {
            return 0;
        }
        Spanned sp = (Spanned) text;
        int flag = sp.getSpanFlags(meta);
        if (flag != LOCKED) {
            if (flag != 0) {
                return on;
            }
            return 0;
        }
        return lock;
    }

    public static void adjustMetaAfterKeypress(Spannable content) {
        adjust(content, CAP);
        adjust(content, ALT);
        adjust(content, SYM);
    }

    public static boolean isMetaTracker(CharSequence text, Object what) {
        return what == CAP || what == ALT || what == SYM || what == SELECTING;
    }

    public static boolean isSelectingMetaTracker(CharSequence text, Object what) {
        return what == SELECTING;
    }

    private static void adjust(Spannable content, Object what) {
        int current = content.getSpanFlags(what);
        if (current == PRESSED) {
            content.setSpan(what, 0, 0, USED);
        } else if (current == RELEASED) {
            content.removeSpan(what);
        }
    }

    protected static void resetLockedMeta(Spannable content) {
        resetLock(content, CAP);
        resetLock(content, ALT);
        resetLock(content, SYM);
        resetLock(content, SELECTING);
    }

    private static void resetLock(Spannable content, Object what) {
        int current = content.getSpanFlags(what);
        if (current == LOCKED) {
            content.removeSpan(what);
        }
    }

    public boolean onKeyDown(View view, Editable content, int keyCode, KeyEvent event) {
        if (keyCode == 59 || keyCode == 60) {
            press(content, CAP);
            return true;
        }
        if (keyCode == 57 || keyCode == 58 || keyCode == 78) {
            press(content, ALT);
            return true;
        }
        if (keyCode == 63) {
            press(content, SYM);
            return true;
        }
        return false;
    }

    private void press(Editable content, Object what) {
        int state = content.getSpanFlags(what);
        if (state != PRESSED) {
            if (state == RELEASED) {
                content.setSpan(what, 0, 0, LOCKED);
            } else if (state != USED) {
                if (state == LOCKED) {
                    content.removeSpan(what);
                } else {
                    content.setSpan(what, 0, 0, PRESSED);
                }
            }
        }
    }

    public static void startSelecting(View view, Spannable content) {
        content.setSpan(SELECTING, 0, 0, PRESSED);
    }

    public static void stopSelecting(View view, Spannable content) {
        content.removeSpan(SELECTING);
    }

    public boolean onKeyUp(View view, Editable content, int keyCode, KeyEvent event) {
        if (keyCode == 59 || keyCode == 60) {
            release(content, CAP);
            return true;
        }
        if (keyCode == 57 || keyCode == 58 || keyCode == 78) {
            release(content, ALT);
            return true;
        }
        if (keyCode == 63) {
            release(content, SYM);
            return true;
        }
        return false;
    }

    private void release(Editable content, Object what) {
        int current = content.getSpanFlags(what);
        if (current == USED) {
            content.removeSpan(what);
        } else if (current == PRESSED) {
            content.setSpan(what, 0, 0, RELEASED);
        }
    }

    public void clearMetaKeyState(View view, Editable content, int states) {
        clearMetaKeyState(content, states);
    }

    public static void clearMetaKeyState(Editable content, int states) {
        if ((states & 1) != 0) {
            content.removeSpan(CAP);
        }
        if ((states & 2) != 0) {
            content.removeSpan(ALT);
        }
        if ((states & 4) != 0) {
            content.removeSpan(SYM);
        }
        if ((65536 & states) != 0) {
            content.removeSpan(SELECTING);
        }
    }

    public static long resetLockedMeta(long state) {
        return resetLock(resetLock(resetLock(state, 1, META_SHIFT_MASK), 2, META_ALT_MASK), 4, META_SYM_MASK);
    }

    private static long resetLock(long state, int what, long mask) {
        if (((what << 8) & state) != 0) {
            return state & ((-1) ^ mask);
        }
        return state;
    }

    public static final int getMetaState(long state) {
        return getActive(state, 1, 1, META_CAP_LOCKED) | getActive(state, 2, 2, META_ALT_LOCKED) | getActive(state, 4, 4, META_SYM_LOCKED);
    }

    public static final int getMetaState(long state, int meta) {
        switch (meta) {
            case 1:
                return getActive(state, meta, 1, 2);
            case 2:
                return getActive(state, meta, 1, 2);
            case 3:
            default:
                return 0;
            case 4:
                return getActive(state, meta, 1, 2);
        }
    }

    private static int getActive(long state, int meta, int on, int lock) {
        if (((meta << 8) & state) != 0) {
            return lock;
        }
        if ((meta & state) != 0) {
            return on;
        }
        return 0;
    }

    public static long adjustMetaAfterKeypress(long state) {
        return adjust(adjust(adjust(state, 1, META_SHIFT_MASK), 2, META_ALT_MASK), 4, META_SYM_MASK);
    }

    private static long adjust(long state, int what, long mask) {
        if (((what << 32) & state) != 0) {
            return ((mask ^ (-1)) & state) | what | (what << 24);
        }
        if (((what << 40) & state) != 0) {
            return state & (mask ^ (-1));
        }
        return state;
    }

    public static long handleKeyDown(long state, int keyCode, KeyEvent event) {
        if (keyCode == 59 || keyCode == 60) {
            return press(state, 1, META_SHIFT_MASK);
        }
        if (keyCode == 57 || keyCode == 58 || keyCode == 78) {
            return press(state, 2, META_ALT_MASK);
        }
        if (keyCode == 63) {
            return press(state, 4, META_SYM_MASK);
        }
        return state;
    }

    private static long press(long state, int what, long mask) {
        if (((what << 32) & state) != 0) {
            return state;
        }
        if (((what << 40) & state) != 0) {
            return ((mask ^ (-1)) & state) | what | (what << 8);
        }
        if (((what << 24) & state) != 0) {
            return state;
        }
        if (((what << 8) & state) != 0) {
            return state & (mask ^ (-1));
        }
        return (what | state | (what << 32)) & ((what << 40) ^ (-1));
    }

    public static long handleKeyUp(long state, int keyCode, KeyEvent event) {
        if (keyCode == 59 || keyCode == 60) {
            return release(state, 1, META_SHIFT_MASK);
        }
        if (keyCode == 57 || keyCode == 58 || keyCode == 78) {
            return release(state, 2, META_ALT_MASK);
        }
        if (keyCode == 63) {
            return release(state, 4, META_SYM_MASK);
        }
        return state;
    }

    private static long release(long state, int what, long mask) {
        if (((what << 24) & state) != 0) {
            return state & (mask ^ (-1));
        }
        if (((what << 32) & state) != 0) {
            return (what | state | (what << 40)) & ((what << 32) ^ (-1));
        }
        return state;
    }

    public long clearMetaKeyState(long state, int which) {
        if ((which & 1) != 0) {
            state = resetLock(state, 1, META_SHIFT_MASK);
        }
        if ((which & 2) != 0) {
            state = resetLock(state, 2, META_ALT_MASK);
        }
        if ((which & 4) != 0) {
            return resetLock(state, 4, META_SYM_MASK);
        }
        return state;
    }
}
