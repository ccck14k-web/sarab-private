package com.android.inputmethod.latin;

import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.PreferenceActivity;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import inputmethod.latin.perfectkeyboard.R;

/* loaded from: classes.dex */
public class DictionaryEditorDebugSettings extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final String DEBUG_MODE_KEY = "debug_mode";
    private static final String TAG = "DictionaryEditorDebugSettings";
    private CheckBoxPreference mDebugMode;

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        addPreferencesFromResource(R.xml.prefs_for_debug);
        SharedPreferences prefs = getPreferenceManager().getSharedPreferences();
        prefs.registerOnSharedPreferenceChangeListener(this);
        this.mDebugMode = (CheckBoxPreference) findPreference(DEBUG_MODE_KEY);
        updateDebugMode();
    }

    @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
    public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
        if (key.equals(DEBUG_MODE_KEY) && this.mDebugMode != null) {
            this.mDebugMode.setChecked(prefs.getBoolean(DEBUG_MODE_KEY, false));
            updateDebugMode();
        }
    }

    private void updateDebugMode() {
        if (this.mDebugMode != null) {
            boolean isDebugMode = this.mDebugMode.isChecked();
            String version = LoggingEvents.EXTRA_CALLING_APP_NAME;
            try {
                PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
                version = "Version " + info.versionName;
            } catch (PackageManager.NameNotFoundException e) {
                Log.e(TAG, "Could not find version info.");
            }
            if (!isDebugMode) {
                this.mDebugMode.setTitle(version);
                this.mDebugMode.setSummary(LoggingEvents.EXTRA_CALLING_APP_NAME);
            } else {
                this.mDebugMode.setTitle(getResources().getString(R.string.prefs_debug_mode));
                this.mDebugMode.setSummary(version);
            }
        }
    }
}
