package com.android.inputmethod.latin;

import android.view.MotionEvent;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class SwipeTracker {
    private static final int LONGEST_PAST_TIME = 200;
    private static final int NUM_PAST = 4;
    final EventRingBuffer mBuffer = new EventRingBuffer(4);
    private float mXVelocity;
    private float mYVelocity;

    public void addMovement(MotionEvent ev) {
        if (ev.getAction() == 0) {
            this.mBuffer.clear();
            return;
        }
        long time = ev.getEventTime();
        int count = ev.getHistorySize();
        for (int i = 0; i < count; i++) {
            addPoint(ev.getHistoricalX(i), ev.getHistoricalY(i), ev.getHistoricalEventTime(i));
        }
        addPoint(ev.getX(), ev.getY(), time);
    }

    private void addPoint(float x, float y, long time) {
        EventRingBuffer buffer = this.mBuffer;
        while (buffer.size() > 0) {
            long lastT = buffer.getTime(0);
            if (lastT >= time - 200) {
                break;
            } else {
                buffer.dropOldest();
            }
        }
        buffer.add(x, y, time);
    }

    public void computeCurrentVelocity(int units) {
        computeCurrentVelocity(units, Float.MAX_VALUE);
    }

    public void computeCurrentVelocity(int units, float maxVelocity) {
        EventRingBuffer buffer = this.mBuffer;
        float oldestX = buffer.getX(0);
        float oldestY = buffer.getY(0);
        long oldestTime = buffer.getTime(0);
        float accumX = 0.0f;
        float accumY = 0.0f;
        int count = buffer.size();
        for (int pos = 1; pos < count; pos++) {
            int dur = (int) (buffer.getTime(pos) - oldestTime);
            if (dur != 0) {
                float dist = buffer.getX(pos) - oldestX;
                float vel = (dist / dur) * units;
                accumX = accumX == 0.0f ? vel : (accumX + vel) * 0.5f;
                float dist2 = buffer.getY(pos) - oldestY;
                float vel2 = (dist2 / dur) * units;
                accumY = accumY == 0.0f ? vel2 : (accumY + vel2) * 0.5f;
            }
        }
        this.mXVelocity = accumX < 0.0f ? Math.max(accumX, -maxVelocity) : Math.min(accumX, maxVelocity);
        this.mYVelocity = accumY < 0.0f ? Math.max(accumY, -maxVelocity) : Math.min(accumY, maxVelocity);
    }

    public float getXVelocity() {
        return this.mXVelocity;
    }

    public float getYVelocity() {
        return this.mYVelocity;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class EventRingBuffer {
        private final int bufSize;
        private int count;
        private int end;
        private final long[] timeBuf;
        private int top;
        private final float[] xBuf;
        private final float[] yBuf;

        public EventRingBuffer(int max) {
            this.bufSize = max;
            this.xBuf = new float[max];
            this.yBuf = new float[max];
            this.timeBuf = new long[max];
            clear();
        }

        public void clear() {
            this.count = 0;
            this.end = 0;
            this.top = 0;
        }

        public int size() {
            return this.count;
        }

        private int index(int pos) {
            return (this.end + pos) % this.bufSize;
        }

        private int advance(int index) {
            return (index + 1) % this.bufSize;
        }

        public void add(float x, float y, long time) {
            this.xBuf[this.top] = x;
            this.yBuf[this.top] = y;
            this.timeBuf[this.top] = time;
            this.top = advance(this.top);
            if (this.count < this.bufSize) {
                this.count++;
            } else {
                this.end = advance(this.end);
            }
        }

        public float getX(int pos) {
            return this.xBuf[index(pos)];
        }

        public float getY(int pos) {
            return this.yBuf[index(pos)];
        }

        public long getTime(int pos) {
            return this.timeBuf[index(pos)];
        }

        public void dropOldest() {
            this.count--;
            this.end = advance(this.end);
        }
    }
}
