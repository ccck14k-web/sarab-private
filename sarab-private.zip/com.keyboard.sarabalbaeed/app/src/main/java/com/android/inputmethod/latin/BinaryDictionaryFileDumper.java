package com.android.inputmethod.latin;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/* loaded from: classes.dex */
public class BinaryDictionaryFileDumper {
    private static final boolean DEBUG = false;
    private static final int FILE_READ_BUFFER_SIZE = 1024;
    private static final String TAG = BinaryDictionaryFileDumper.class.getSimpleName();
    private static final byte[] MAGIC_NUMBER = {120, -79};
    private static final String[] DICTIONARY_PROJECTION = {"id"};

    private BinaryDictionaryFileDumper() {
    }

    private static Uri getProviderUri(String path) {
        return new Uri.Builder().scheme("content").authority(BinaryDictionary.DICTIONARY_PACK_AUTHORITY).appendPath(path).build();
    }

    private static List<WordListInfo> getWordListWordListInfos(Locale locale, Context context) {
        ContentResolver resolver = context.getContentResolver();
        Uri dictionaryPackUri = getProviderUri(locale.toString());
        Cursor c = resolver.query(dictionaryPackUri, DICTIONARY_PROJECTION, null, null, null);
        if (c == null) {
            return Collections.emptyList();
        }
        if (c.getCount() <= 0 || !c.moveToFirst()) {
            c.close();
            return Collections.emptyList();
        }
        try {
            List<WordListInfo> list = new ArrayList<>();
            do {
                String wordListId = c.getString(0);
                String wordListLocale = c.getString(1);
                if (!TextUtils.isEmpty(wordListId)) {
                    list.add(new WordListInfo(wordListId, wordListLocale));
                }
            } while (c.moveToNext());
            c.close();
            return list;
        } catch (Exception e) {
            Log.e(TAG, "Exception communicating with the dictionary pack : " + e);
            return Collections.emptyList();
        }
    }

    private static AssetFileDescriptor openAssetFileDescriptor(ContentResolver resolver, Uri uri) {
        try {
            return resolver.openAssetFileDescriptor(uri, "r");
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Could not find a word list from the dictionary provider.");
            return null;
        }
    }

    private static AssetFileAddress cacheWordList(String id, String locale, ContentResolver resolver, Context context) {
        Uri wordListUri = getProviderUri(id);
        String outputFileName = BinaryDictionaryGetter.getCacheFileName(id, locale, context);
        // The pack may be gzip-wrapped and/or encrypted; try every combination.
        for (int mode = 0; mode <= 5; mode++) {
            AssetFileDescriptor afd = null;
            FileOutputStream outputStream = null;
            File outputFile = null;
            try {
                afd = openAssetFileDescriptor(resolver, wordListUri);
                if (afd == null) {
                    return null;
                }
                InputStream originalSourceStream = afd.createInputStream();
                outputFile = new File(outputFileName);
                outputStream = new FileOutputStream(outputFile);
                InputStream inputStream;
                switch (mode) {
                    case 0:
                        inputStream = FileTransforms.getUncompressedStream(FileTransforms.getDecryptedStream(FileTransforms.getUncompressedStream(originalSourceStream)));
                        break;
                    case 1:
                        inputStream = FileTransforms.getUncompressedStream(FileTransforms.getDecryptedStream(originalSourceStream));
                        break;
                    case 2:
                        inputStream = FileTransforms.getDecryptedStream(FileTransforms.getUncompressedStream(originalSourceStream));
                        break;
                    case 3:
                        inputStream = FileTransforms.getUncompressedStream(originalSourceStream);
                        break;
                    case 4:
                        inputStream = FileTransforms.getDecryptedStream(originalSourceStream);
                        break;
                    default:
                        inputStream = originalSourceStream;
                        break;
                }
                checkMagicAndCopyFileTo(new BufferedInputStream(inputStream), outputStream);
                if (resolver.delete(wordListUri, null, null) <= 0) {
                    Log.e(TAG, "Could not have the dictionary pack delete a word list");
                }
                return AssetFileAddress.makeFromFileName(outputFileName);
            } catch (Exception e) {
                if (outputFile != null) {
                    outputFile.delete();
                }
            } finally {
                if (afd != null) {
                    try {
                        afd.close();
                    } catch (Exception e2) {
                        Log.e(TAG, "Exception while closing a cross-process file descriptor : " + e2);
                    }
                }
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (Exception e3) {
                        Log.e(TAG, "Exception while closing a file : " + e3);
                    }
                }
            }
        }
        Log.e(TAG, "Could not copy a word list. Will not be able to use it.");
        if (resolver.delete(wordListUri, null, null) <= 0) {
            Log.e(TAG, "In addition, we were unable to delete it.");
        }
        return null;
    }

    public static List<AssetFileAddress> cacheWordListsFromContentProvider(Locale locale, Context context) {
        ContentResolver resolver = context.getContentResolver();
        List<WordListInfo> idList = getWordListWordListInfos(locale, context);
        List<AssetFileAddress> fileAddressList = new ArrayList<>();
        for (WordListInfo id : idList) {
            AssetFileAddress afd = cacheWordList(id.mId, id.mLocale, resolver, context);
            if (afd != null) {
                fileAddressList.add(afd);
            }
        }
        return fileAddressList;
    }

    private static void checkMagicAndCopyFileTo(BufferedInputStream input, FileOutputStream output) throws FileNotFoundException, IOException {
        byte[] magicNumberBuffer = new byte[MAGIC_NUMBER.length];
        int readMagicNumberSize = input.read(magicNumberBuffer, 0, MAGIC_NUMBER.length);
        if (readMagicNumberSize < MAGIC_NUMBER.length) {
            throw new IOException("Less bytes to read than the magic number length");
        }
        if (!Arrays.equals(MAGIC_NUMBER, magicNumberBuffer)) {
            throw new IOException("Wrong magic number for downloaded file");
        }
        output.write(MAGIC_NUMBER);
        byte[] buffer = new byte[1024];
        int readBytes = input.read(buffer);
        while (readBytes >= 0) {
            output.write(buffer, 0, readBytes);
            readBytes = input.read(buffer);
        }
        input.close();
    }
}
