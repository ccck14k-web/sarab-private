package DictionaryPackage;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import com.android.inputmethod.latin.DictionaryEditor;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class DicatinaryPackage {
    private static final String TAG = "ASK ExtDictFctry";
    private static final String XML_ASSETS_ATTRIBUTE = "dictionaryAssertName";
    private static final String XML_DESCRIPTION_ATTRIBUTE = "description";
    private static final String XML_DICTIONARIES_TAG = "Dictionaries";
    private static final String XML_DICTIONARY_TAG = "Dictionary";
    private static final String XML_ID_ATTRIBUTE = "id";
    private static final String XML_LANGUAGE_ATTRIBUTE = "locale";
    private static final String XML_NAME_RES_ID_ATTRIBUTE = "nameResId";
    private static final String XML_RESOURCE_ATTRIBUTE = "dictionaryResourceId";
    private static ArrayList<DictionaryBuilder> ms_creators = null;

    /* loaded from: classes.dex */
    public interface DictionaryBuilder {
        public static final String RECEIVER_INTERFACE = "com.pk.android.icskeyboard.DICTIONARY";
        public static final String RECEIVER_META_DATA = "com.pk.android.icskeyboard.dictionaries";

        String getDescription();

        String getDictionaryName();

        int getDictionaryResourceId();

        String getId();

        String getLanguage();

        Context getPackageContext();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class BinaryDictionaryBuilderImpl implements DictionaryBuilder {
        private final String mAssetsFilename;
        private final String mDescription;
        private final int mDictionaryResourceId;
        private final String mId;
        private String mLanguage;
        private final int mNameId;
        private final Context mPackageContext;

        @Override // DictionaryPackage.DicatinaryPackage.DictionaryBuilder
        public int getDictionaryResourceId() {
            return this.mDictionaryResourceId;
        }

        public BinaryDictionaryBuilderImpl(Context context, String id, String language, int nameId, String assetsFilename, int dictionaryResourceId, String description) {
            this.mId = "dictionary_" + id;
            this.mLanguage = language;
            this.mNameId = nameId;
            this.mDescription = description;
            this.mAssetsFilename = assetsFilename;
            this.mPackageContext = context;
            this.mDictionaryResourceId = dictionaryResourceId;
            if (DictionaryEditor.DEBUG) {
                Log.d("ASK BinaryDictionaryBuilderImpl", "Creator for " + this.mLanguage + " with id " + this.mId + " assets:" + this.mAssetsFilename + " package:" + this.mPackageContext.getPackageName());
            }
        }

        @Override // DictionaryPackage.DicatinaryPackage.DictionaryBuilder
        public String getDictionaryName() {
            return this.mPackageContext.getString(this.mNameId);
        }

        @Override // DictionaryPackage.DicatinaryPackage.DictionaryBuilder
        public String getDescription() {
            return this.mDescription;
        }

        @Override // DictionaryPackage.DicatinaryPackage.DictionaryBuilder
        public Context getPackageContext() {
            return this.mPackageContext;
        }

        @Override // DictionaryPackage.DicatinaryPackage.DictionaryBuilder
        public String getId() {
            return this.mId;
        }

        @Override // DictionaryPackage.DicatinaryPackage.DictionaryBuilder
        public String getLanguage() {
            return this.mLanguage;
        }
    }

    private static ArrayList<DictionaryBuilder> getDictionaryBuildersFromResId(Context context, int keyboardsResId) {
        XmlPullParser allKeyboards = context.getResources().getXml(keyboardsResId);
        return parseDictionaryBuildersFromXml(context, allKeyboards);
    }

    private static ArrayList<DictionaryBuilder> getDictionaryBuildersFromActivityInfo(Context context, ActivityInfo ai) {
        XmlPullParser allDictionaries = ai.loadXmlMetaData(context.getPackageManager(), DictionaryBuilder.RECEIVER_META_DATA);
        return parseDictionaryBuildersFromXml(context, allDictionaries);
    }

    private static ArrayList<DictionaryBuilder> parseDictionaryBuildersFromXml(Context context, XmlPullParser xmlParser) {
        ArrayList<DictionaryBuilder> dictionaries = new ArrayList<>();
        boolean inDictionaries = false;
        while (true) {
            try {
                int event = xmlParser.next();
                if (event == 1) {
                    break;
                }
                String tag = xmlParser.getName();
                if (event == 2) {
                    if (XML_DICTIONARIES_TAG.equals(tag)) {
                        inDictionaries = true;
                    } else if (inDictionaries && XML_DICTIONARY_TAG.equals(tag)) {
                        AttributeSet attrs = Xml.asAttributeSet(xmlParser);
                        String id = attrs.getAttributeValue(null, XML_ID_ATTRIBUTE);
                        String language = attrs.getAttributeValue(null, "locale");
                        int nameId = attrs.getAttributeResourceValue(null, XML_NAME_RES_ID_ATTRIBUTE, -1);
                        String assets = attrs.getAttributeValue(null, XML_ASSETS_ATTRIBUTE);
                        String description = attrs.getAttributeValue(null, XML_DESCRIPTION_ATTRIBUTE);
                        int dictionaryResourceId = attrs.getAttributeResourceValue(null, XML_RESOURCE_ATTRIBUTE, -1);
                        if (id == null || id.length() == 0 || language == null || nameId == -1 || (assets == null && dictionaryResourceId == -1)) {
                            Log.e(TAG, "External dictionary does not include all mandatory details! Will not create dictionary.");
                        } else {
                            DictionaryBuilder creator = new BinaryDictionaryBuilderImpl(context, id, language, nameId, assets, dictionaryResourceId, description);
                            dictionaries.add(creator);
                        }
                    }
                } else if (event != 3) {
                    continue;
                } else {
                    if (XML_DICTIONARIES_TAG.equals(tag)) {
                        break;
                    }
                    if (inDictionaries) {
                        XML_DICTIONARY_TAG.equals(tag);
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "IO error:" + e);
                e.printStackTrace();
            } catch (NullPointerException e2) {
                Log.e(TAG, "Parse error:" + e2);
                e2.printStackTrace();
            } catch (XmlPullParserException e3) {
                Log.e(TAG, "Parse error:" + e3);
                e3.printStackTrace();
            }
        }
        return dictionaries;
    }

    private static ArrayList<DictionaryBuilder> getAllExternalDictionaryBuilders(Context context) {
        List<ResolveInfo> broadcastReceivers = context.getPackageManager().queryBroadcastReceivers(new Intent(DictionaryBuilder.RECEIVER_INTERFACE), 128);
        if (DictionaryEditor.DEBUG) {
            Log.d(TAG, "Number of potential external dictionary packages found: " + broadcastReceivers.size());
        }
        ArrayList<DictionaryBuilder> externalDictionaryBuilders = new ArrayList<>();
        for (ResolveInfo receiver : broadcastReceivers) {
            if (receiver.activityInfo == null) {
                Log.e(TAG, "BroadcastReceiver has null ActivityInfo. Receiver's label is " + ((Object) receiver.loadLabel(context.getPackageManager())));
            } else {
                try {
                    Context externalPackageContext = context.createPackageContext(receiver.activityInfo.packageName, 128);
                    ArrayList<DictionaryBuilder> packageKeyboardCreators = getDictionaryBuildersFromActivityInfo(externalPackageContext, receiver.activityInfo);
                    externalDictionaryBuilders.addAll(packageKeyboardCreators);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.e(TAG, "Did not find package: " + receiver.activityInfo.packageName);
                }
            }
        }
        if (DictionaryEditor.DEBUG) {
            Log.d(TAG, "Number of external dictionary builders successfully parsed: " + externalDictionaryBuilders.size());
        }
        return externalDictionaryBuilders;
    }

    public static synchronized void resetBuildersCache() {
        synchronized (DicatinaryPackage.class) {
            ms_creators = null;
        }
    }

    public static synchronized ArrayList<DictionaryBuilder> getAllBuilders(Context context) {
        ArrayList<DictionaryBuilder> arrayList;
        synchronized (DicatinaryPackage.class) {
            if (ms_creators == null) {
                ArrayList<DictionaryBuilder> dictionaries = new ArrayList<>();
                dictionaries.addAll(getAllExternalDictionaryBuilders(context));
                ms_creators = dictionaries;
            }
            arrayList = ms_creators;
        }
        return arrayList;
    }
}
