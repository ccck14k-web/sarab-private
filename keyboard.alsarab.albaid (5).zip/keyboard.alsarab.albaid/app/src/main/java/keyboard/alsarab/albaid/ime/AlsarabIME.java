package keyboard.alsarab.albaid.ime;

import keyboard.alsarab.albaid.dictionary.ExternalDictionaries;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.os.Vibrator;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.speech.SpeechRecognizer;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.PrintWriterPrinter;
import android.util.Printer;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.CompletionInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsoluteLayout;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import keyboard.alsarab.albaid.common.speech.LoggingEvents;
import keyboard.alsarab.albaid.ime.ImeUtils;
import keyboard.alsarab.albaid.ime.EditingUtil;
import keyboard.alsarab.albaid.ime.Hints;
import keyboard.alsarab.albaid.ime.LatinKeyboardBaseView;
import keyboard.alsarab.albaid.ime.TextEntryState;
import keyboard.alsarab.albaid.ime.WordInfo;
import keyboard.alsarab.albaid.ime.voice.FieldContext;
import keyboard.alsarab.albaid.ime.voice.SettingsUtil;
import keyboard.alsarab.albaid.ime.voice.VoiceInput;
import keyboard.alsarab.albaid.voiceime.VoiceRecognitionTrigger;
import keyboard.alsarab.albaid.R;
import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class AlsarabIME extends InputMethodService implements LatinKeyboardBaseView.OnKeyboardActionListener, VoiceInput.UiListener, SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int CPS_BUFFER_SIZE = 16;
    public static final String DEFAULT_VOICE_INPUT_SUPPORTED_LOCALES = "en en_US en_GB en_AU en_CA en_IE en_IN en_NZ en_SG en_ZA ";
    private static final int DELETE_ACCELERATE_AT = 20;
    public static final int ENABLE_CURSORS_ALWAYS = 2;
    public static final int ENABLE_CURSORS_NEVER = 0;
    public static final int ENABLE_CURSORS_ON_SWIPE = 1;
    static final boolean ENABLE_VOICE_BUTTON = true;
    private static final String IME_OPTION_NO_MICROPHONE = "nm";
    static final int KEYCODE_ENTER = 10;
    static final int KEYCODE_PERIOD = 46;
    static final int KEYCODE_SPACE = 32;
    private static final int MSG_START_TUTORIAL = 1;
    private static final int MSG_UPDATE_OLD_SUGGESTIONS = 4;
    private static final int MSG_UPDATE_SHIFT_STATE = 2;
    private static final int MSG_UPDATE_SUGGESTIONS = 0;
    private static final int MSG_VOICE_RESULTS = 3;
    private static final int POS_METHOD = 0;
    private static final int POS_SETTINGS = 1;
    private static final String PREF_ALWAYS_SUGGEST = "always_suggest";
    private static final String PREF_AUTO_CAP = "auto_cap";
    private static final String PREF_AUTO_COMPLETE = "auto_complete";
    private static final String PREF_AUTO_SELECT_BEST_VOICE_CHOICE = "voice_input_best_choice";
    private static final String PREF_AUTO_SPACE = "auto_space";
    private static final String PREF_AUTO_SWITCH_BACK_TO_ALPHA = "auto_swithch_to_qwerty";
    private static final String PREF_BACKGROUND_CUSTOM_KEY = "background_custom_key";
    private static final String PREF_BIGRAM_SUGGESTIONS = "bigram_suggestion";
    private static final String PREF_BUTTON_COLOR = "button_color";
    private static final String PREF_DEBUG_ON = "debug_pref";
    private static final String PREF_DOUBLE_SPACE_TO_PERIOD = "double_space_to_period";
    private static final String PREF_ENABLE_CURSORS = "enable_cursors";
    private static final String PREF_EXTERNAL_SKIN = "external_skin";
    private static final String PREF_FULL_SCREEN_LANDSCAPE = "full_screen_landscape";
    private static final String PREF_FULL_SCREEN_PORTRAIT = "full_screen_portrait";
    private static final String PREF_GESTURE_SENSITIVITY = "gesture_sensitivity1";
    private static final String PREF_HAS_USED_VOICE_INPUT = "has_used_voice_input";
    private static final String PREF_HAS_USED_VOICE_INPUT_UNSUPPORTED_LOCALE = "has_used_voice_input_unsupported_locale";
    public static final String PREF_INPUT_LANGUAGE = "input_language";
    private static final String PREF_KB_HINT_FONT_COLOR = "keyboard_hint_font_color_color";
    private static final String PREF_KB_SOUND_STYLE = "tap_sound_style_pref";
    private static final String PREF_KEYBOARD_BACKGROUND_COLOR = "keyboard_background_color";
    private static final String PREF_LANDSCAPE_LAYOUT = "pref_landscape_layout";
    private static final String PREF_LONG_PRESS_ON_123_TO_SETTINGS = "long_press_on_123_to_settings";
    private static final String PREF_NO_POPUP_ON_SPACE = "no_popup_on_space";
    private static final String PREF_POPUP_ON = "popup_on";
    private static final String PREF_PORTRAIT_LAYOUT = "pref_portrait_layout";
    private static final String PREF_PUNCTUATION_EDITOR = "punctuation_editor";
    private static final String PREF_QUICK_FIXES = "quick_fixes";
    private static final String PREF_RECORRECTION_ENABLED = "recorrection_enabled";
    public static final String PREF_RTL_SUPPORTED = "enable_rtl";
    public static final String PREF_SELECTED_LANGUAGES = "selected_languages";
    private static final String PREF_SHOW_SUGGESTIONS = "show_suggestions";
    private static final String PREF_SHOW_TOUCH_POINTS = "show_touch_points";
    private static final String PREF_SOUND_ON = "sound_on";
    private static final String PREF_SOUND_VOLUME = "sound_volume";
    private static final String PREF_SUGGESTIONS_FONT_COLOR = "suggestion_font_color";
    private static final String PREF_SUGGESTION_BAR_COLOR = "suggestion_bar_color";
    private static final String PREF_SUGGESTION_BAR_SIZE = "suggestion_bar_size";
    private static final String PREF_SUGGESTION_CUSTOM_KEY = "background_suggestion_key";
    private static final String PREF_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER = "suggest_words_with_missing_space_character";
    private static final String PREF_SWIPE_DOWN = "swipe_down";
    private static final String PREF_SWIPE_LEFT = "swipe_left";
    private static final String PREF_SWIPE_RIGHT = "swipe_right";
    private static final String PREF_SWIPE_UP = "swipe_up";
    private static final String PREF_USE_CONTACT_DICTIONARY = "use_contact_dictionary";
    private static final String PREF_VIBRATE_LENGTH = "vibration_length";
    private static final String PREF_VIBRATE_ON = "vibrate_on";
    private static final String PREF_VOICE_MODE = "voice_mode";
    private static final String PREF_VOLUME_KEY_FOR_LEFT_RIGHT_SUPPORT = "volume_key_for_left_right_support";
    public static String PackageName = null;
    private static final int QUICK_PRESS = 200;
    private static final int RECOGNITIONVIEW_HEIGHT_THRESHOLD_RATIO = 6;
    private static final int RECOGNITIONVIEW_MINIMUM_HEIGHT_DIP = 244;
    public static final String TAG = "perfectkeboard";
    static final boolean VOICE_INSTALLED = true;
    static Context context;
    public static boolean mAutoBackToAlpha;
    public static int mEnableCursorsMode;
    private static boolean mHasDictionary;
    public static String mInputLocale;
    public static boolean mLongPressOn123ToSettings;
    public static boolean mNoPopupOnSpace;
    public static boolean mRTLEnabled;
    public static List<CharSequence> mSuggestPuncList;
    public static boolean mSuggestWordsMissingSpace;
    public static boolean mUseCustomBackgrounColors;
    public static boolean mUseCustomSuggestionColors;
    public static WordInfo.SkinData skinData;
    public static boolean suggestionSizeBig;
    AlertDialog Al;
    AlertDialog Al2;
    AlertDialog Al3;
    AlertDialog Al4;
    ArrayAdapter<String> adapter;
    int av;
    int cl;
    android.text.ClipboardManager cm;
    android.content.ClipboardManager cm2;
    int co;
    int cs;
    SQLiteDatabase db;
    int ec;
    String[] emj;
    private boolean mAfterVoiceInput;
    private boolean mAlwaysSuggest;
    private AudioManager mAudioManager;
    private boolean mAutoCap;
    private boolean mAutoCorrectEnabled;
    private boolean mAutoCorrectOn;
    private AutoDictionary mAutoDictionary;
    private boolean mAutoSpace;
    private AutoTextDictionary mAutoTextDictionary;
    private boolean mBestVoiceCohice;
    private CharSequence mBestWord;
    private boolean mBigramSuggestionEnabled;
    private CandidateView mCandidateView;
    public LinearLayout mCandidateViewContainer;
    private boolean mCapsLock;
    private int mCommittedLength;
    private boolean mCompletionOn;
    private CompletionInfo[] mCompletions;
    private boolean mConfigurationChanging;
    private ContactsDictionary mContactsDictionary;
    private int mCorrectionMode;
    private int mCpsIndex;
    private int mDeleteCount;
    private boolean mDoubleSpaceToPeriod;
    private boolean mEnableVoiceButton;
    private CharSequence mEnteredText;
    private String mExternalSkin;
    private boolean mFieldUrlOrWeb;
    private boolean mFullScreenPortrait;
    private int mGestureDown;
    private int mGestureLeft;
    private int mGestureRight;
    private int mGestureUp;
    private boolean mHasUsedVoiceInput;
    private boolean mHasUsedVoiceInputUnsupportedLocale;
    private Hints mHints;
    private boolean mImmediatelyAfterVoiceInput;
    private boolean mInputTypeNoAutoCorrect;
    private boolean mIsShowingHint;
    private boolean mJustAccepted;
    private boolean mJustAddedAutoSpace;
    private CharSequence mJustRevertedSeparator;
    private LanguageSwitcher mLanguageSwitcher;
    private long mLastCpsTime;
    private long mLastKeyTime;
    private int mLastSelectionEnd;
    private int mLastSelectionStart;
    private boolean mLocaleSupportedForVoiceInput;
    private int mLongPressDelay;
    private int mMinimumVoiceRecognitionViewHeightPixel;
    private boolean mNoFullScreenLandscape;
    private AlertDialog mOptionsDialog;
    private int mOrientation;
    private boolean mPasswordText;
    private boolean mPopupOn;
    private boolean mPredicting;
    private boolean mPredictionOn;
    private boolean mQuickFixes;
    private boolean mReCorrectionEnabled;
    private boolean mRecognizing;
    private boolean mRefreshKeyboardRequired;
    private Resources mResources;
    private String mSentenceSeparators;
    private boolean mShowSuggestions;
    private boolean mShowingVoiceSuggestions;
    private boolean mSilentMode;
    private int mSoundID;
    private boolean mSoundOn;
    private float mSoundVolume;
    private Suggest mSuggest;
    private String mSuggestPuncs;
    private String mSystemLocale;
    private Tutorial mTutorial;
    SoundPool mTypePlay;
    private boolean mUseVolumeKeyForLeftRight;
    private UserBigramDictionary mUserBigramDictionary;
    private UserDictionary mUserDictionary;
    private int mVibrateLength;
    private boolean mVibrateOn;
    private VoiceInput mVoiceInput;
    private boolean mVoiceInputHighlighted;
    private boolean mVoiceOnPrimary;
    private VoiceRecognitionTrigger mVoiceRecognitionTrigger;
    private AlertDialog mVoiceWarningDialog;
    String mWordSeparators;
    int[] ms;
    TimerTask my;
    private String path;
    ClipboardManager.OnPrimaryClipChangedListener rm;
    String t1;
    private static boolean PERF_DEBUG = true;
    public static boolean DEBUG = false;
    static boolean TRACE = false;
    private static int mSuggestionFontClor = 0;
    private static int mButtonColor = 0;
    public static boolean mUseExternalSkin = false;
    private static int mKeyboardBackgroundColor = -16777216;
    private static int mSuggestionBarColor = -16777216;
    private static boolean T9Mode = true;
    private static final HashSet<Integer> SPACE_SWAP_CHARACTERS = new HashSet<>(6);
    private static final HashSet<Integer> PUNCTUATION_CHARACTERS = new HashSet<>(16);
    List<String> list = new ArrayList();
    List<String> listf = new ArrayList();
    List<String> pinned = new ArrayList();
    private static final int CLIP_HISTORY_MAX = 500;
    private static final int CLIP_PREVIEW_CHARS = 120;
    boolean mClipMenuOpen = false;
    int ss = 0;
    private final int timeBetweenNotifications = 604800000;
    private boolean mShowTouchPoints = false;
    private long[] mCpsIntervals = new long[16];
    private int mGestureSensitivity = 0;
    private final int GESTURE_DO_NOTHING = 0;
    private final int GESTURE_DELETE_WORD = 1;
    private final int GESTURE_GO_SETTINGS = 2;
    private final int GESTURE_CLOSE_KEYBOARD = 3;
    private final int GESTURE_PASTE_CLIPBOARD = 4;
    private final int GESTURE_PICKUP_SUGGESTION = 5;
    private final int GESTURE_NEXT_LANG = 6;
    private final int GESTURE_PREV_LANG = 7;
    private final int GESTURE_KEY_RIGHT = 8;
    private final int GESTURE_KEY_LEFT = 9;
    private final int GESTURE_KEY_UP = 10;
    private final int GESTURE_KEY_DOWN = 11;
    private final int GESTURE_TOGGLE_T9 = 12;
    private final int GESTURE_TOGGLE_COMPACT = 13;
    private final int GESTURE_TOGGLE_T9COMPACT = 14;
    private final int GESTURE_TOGGLE_SYMBOLS = 15;
    private final int GESTURE_LAUNCH_USER_DIC = 16;
    private final int GESTURE_START_VOICE = 17;
    private final int GESTURE_TOGGLE_NORMAL_SPLITED = 18;
    private final int GESTURE_TOOGLE_CAPS_LOCK = 19;
    Calibration mCalibration = null;
    private boolean mUseContactDictionary = false;
    private StringBuilder mComposing = new StringBuilder();
    private WordComposer mWord = new WordComposer();
    private boolean mAutoSpaceAfterPunc = true;
    private Vibrator mVibrator = null;
    private boolean mEnableVoice = true;
    private ModifierKeyState mShiftKeyState = new ModifierKeyState();
    private ModifierKeyState mSymbolKeyState = new ModifierKeyState();
    private VoiceResults mVoiceResults = new VoiceResults(this, null);
    private Map<String, List<CharSequence>> mWordToSuggestions = new HashMap();
    private ArrayList<WordAlternatives> mWordHistory = new ArrayList<>();
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    AlsarabIME.this.updateSuggestions();
                    return;
                case 1:
                    if (AlsarabIME.this.mTutorial == null) {
                        if (AlsarabIME.this.mCalibration.getInputView().isShown()) {
                            AlsarabIME.this.mTutorial = new Tutorial(AlsarabIME.this, AlsarabIME.this.mCalibration.getInputView());
                            AlsarabIME.this.mTutorial.start();
                            return;
                        }
                        sendMessageDelayed(obtainMessage(1), 100L);
                        return;
                    }
                    return;
                case 2:
                    AlsarabIME.this.updateShiftKeyState(AlsarabIME.this.getCurrentInputEditorInfo());
                    return;
                case 3:
                    AlsarabIME.this.handleVoiceResults();
                    return;
                case 4:
                    AlsarabIME.this.setOldSuggestions();
                    return;
                default:
                    return;
            }
        }
    };
    private boolean scrolled = false;
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context2, Intent intent) {
            AlsarabIME.this.updateRingerMode();
        }
    };

    public interface HardKeyboardAction {
        int getKeyCode();

        boolean isAltActive();

        boolean isShiftActive();

        void setNewKeyCode(int i);
    }

    public interface HardKeyboardTranslator {
        void translatePhysicalCharacter(HardKeyboardAction hardKeyboardAction, AlsarabIME dictionaryEditor);
    }

    void cut() {
        InputConnection ic = getCurrentInputConnection();
        CharSequence cu = ic.getSelectedText(0);
        this.cm.setText(cu);
        ic.commitText(LoggingEvents.EXTRA_CALLING_APP_NAME, 1);
    }


    void copy() {
        InputConnection ic = getCurrentInputConnection();
        CharSequence cu = ic.getSelectedText(0);
        this.cm.setText(cu);
    }

    void paste() {
        try {
            String t = this.cm.getText().toString();
            InputConnection ic = getCurrentInputConnection();
            ic.commitText(t, 0);
        } catch (Exception e) {
        }
    }

    static {
        for (int i = 0; i < ".\n!?,:;@<>()[]{}".length(); i++) {
            PUNCTUATION_CHARACTERS.add(Integer.valueOf(".\n!?,:;@<>()[]{}".charAt(i)));
        }
        for (int i2 = 0; i2 < ".!?,:;@".length(); i2++) {
            SPACE_SWAP_CHARACTERS.add(Integer.valueOf(".!?,:;@".charAt(i2)));
        }
    }

    void listfp() {
        ArrayList<String> out = new ArrayList<>(this.pinned);
        for (int i = this.list.size() - 1; i >= 0; i--) {
            out.add(this.list.get(i));
        }
        this.listf = out;
    }

    @TargetApi(11)
    void tmron() {
        if (this.co != 1) {
            if (this.av == 11) {
                try {
                    this.cm2.addPrimaryClipChangedListener(this.rm);
                    this.co = 1;
                } catch (Exception e) {
                }
            } else {
                new Timer().schedule(this.my, 0L, 5000L);
                this.co = 1;
            }
        }
    }

    void po1() {
        dismissClipChoice();
        LinearLayout my = (LinearLayout) getLayoutInflater().inflate(R.layout.layout1, (ViewGroup) null);
        AlertDialog.Builder Builder = new AlertDialog.Builder(this);
        this.Al = Builder.create();
        this.Al.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                AlsarabIME.this.dismissClipChoice();
            }
        });
        WindowManager.LayoutParams lp = this.Al.getWindow().getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1000;
        keepEditorFocus(this.Al);
        android.graphics.drawable.GradientDrawable frame = new android.graphics.drawable.GradientDrawable();
        frame.setColor(0xff2b2b2b);
        frame.setCornerRadius(18.0f * getResources().getDisplayMetrics().density);
        this.Al.getWindow().setBackgroundDrawable(frame);
        this.Al.setView(my);
        View creditView = my.findViewById(R.id.credit_text);
        if (creditView != null) {
            creditView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlsarabIME.this.showCreditDialog();
                }
            });
        }
        GridView grid = (GridView) my.findViewById(R.id.gridview);
        final android.graphics.drawable.Drawable pinIcon = getDrawable(R.drawable.ic_clip_pin);
        this.adapter = new ArrayAdapter<String>(this, R.layout.layout2, new ArrayList<String>(this.listf)) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                android.widget.TextView tv;
                if (convertView instanceof android.widget.TextView) {
                    tv = (android.widget.TextView) convertView;
                } else {
                    tv = (android.widget.TextView) android.view.LayoutInflater.from(getContext()).inflate(R.layout.layout2, parent, false);
                    tv.setMaxLines(3);
                    tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
                }
                String item = getItem(position);
                // only a short preview is laid out; the full text is still what gets pasted
                int end = item.length();
                if (end > CLIP_PREVIEW_CHARS) {
                    end = CLIP_PREVIEW_CHARS;
                    if (Character.isHighSurrogate(item.charAt(end - 1))) {
                        end--;
                    }
                }
                tv.setText(end == item.length() ? item : item.substring(0, end));
                boolean isPinned = position < AlsarabIME.this.pinned.size();
                Object last = tv.getTag();
                if (last == null || ((Boolean) last).booleanValue() != isPinned) {
                    tv.setCompoundDrawablesWithIntrinsicBounds(null, isPinned ? pinIcon : null, null, null);
                    tv.setTag(Boolean.valueOf(isPinned));
                }
                return tv;
            }
        };
        grid.setAdapter((ListAdapter) this.adapter);
        grid.setFastScrollEnabled(true);
        grid.setSelection(this.ss);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                AlsarabIME.this.ss = position;
                AlsarabIME.this.showClipChoice(parent, v, parent.getItemAtPosition(position).toString());
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View v, int position, long id) {
                try {
                    AlsarabIME.this.showClipMenu(parent.getItemAtPosition(position).toString(), position);
                } catch (Exception e) {
                }
                return true;
            }
        });
        this.Al.show();
    }

    /** Keeps the text field focused while a keyboard popup is open, so the keyboard stays up in chat apps / browsers. */
    void keepEditorFocus(final AlertDialog d) {
        try {
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);
            d.setCanceledOnTouchOutside(true);
            d.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    try {
                        d.getWindow().getDecorView().setOnTouchListener(new View.OnTouchListener() {
                            @Override
                            public boolean onTouch(View v, android.view.MotionEvent e) {
                                if (e.getAction() == android.view.MotionEvent.ACTION_OUTSIDE) {
                                    if (d == AlsarabIME.this.Al && AlsarabIME.this.mClipMenuOpen) {
                                        return true;
                                    }
                                    d.cancel();
                                    return true;
                                }
                                return false;
                            }
                        });
                    } catch (Exception ex) {
                    }
                }
            });
        } catch (Exception e) {
        }
    }

    void showCreditDialog() {
        try {
            float dp = getResources().getDisplayMetrics().density;
            final AlertDialog[] holder = new AlertDialog[1];
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (12 * dp);
            box.setPadding(pad, (int) (4 * dp), pad, 0);
            android.widget.TextView close = new android.widget.TextView(this);
            close.setText("\u2715");
            close.setTextSize(20);
            close.setTextColor(0xffff5f87);
            close.setGravity(17);
            close.setPadding((int) (10 * dp), (int) (6 * dp), (int) (10 * dp), (int) (6 * dp));
            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        holder[0].dismiss();
                    } catch (Exception e) {
                    }
                }
            });
            box.addView(close, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            android.widget.TextView msg = new android.widget.TextView(this);
            msg.setText("تم إعادة كيبورد السراب البعيد للحياة بواسطة المطور أحمد باسم");
            msg.setTextSize(16);
            msg.setGravity(17);
            msg.setPadding(0, (int) (6 * dp), 0, (int) (14 * dp));
            box.addView(msg, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setView(box);
            b.setPositiveButton("زيارة موقعنا", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    try {
                        Intent i = new Intent("android.intent.action.VIEW", Uri.parse("https://ap9ap.com"));
                        i.setFlags(268435456);
                        AlsarabIME.this.startActivity(i);
                    } catch (Exception e) {
                    }
                }
            });
            AlertDialog d = b.create();
            holder[0] = d;
            WindowManager.LayoutParams lp = d.getWindow().getAttributes();
            lp.token = this.mCalibration.getInputView().getWindowToken();
            lp.type = 1000;
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
            d.show();
        } catch (Exception e) {
        }
    }

    @TargetApi(11)
    void clst() {
        this.cm = (android.text.ClipboardManager) getSystemService("clipboard");
        int c = Build.VERSION.SDK_INT;
        if (c >= 11) {
            this.av = 11;
        } else {
            this.av = 10;
        }
        if (c == 18) {
            this.av = 10;
        }
        if (this.av == 11) {
            this.cm2 = (android.content.ClipboardManager) getSystemService("clipboard");
            this.rm = new ClipboardManager.OnPrimaryClipChangedListener() {
                @Override
                public void onPrimaryClipChanged() {
                    try {
                        String t = AlsarabIME.this.cm.getText().toString();
                        if (t.trim().length() == 0) {
                            return;
                        }
                        long now = System.currentTimeMillis();
                        if (t.equals(AlsarabIME.this.mLastClipText) && now - AlsarabIME.this.mLastClipTime < 1500) {
                            return;
                        }
                        AlsarabIME.this.mLastClipText = t;
                        AlsarabIME.this.mLastClipTime = now;
                        AlsarabIME.this.addClip(t);
                    } catch (Exception e) {
                    }
                }
            };
        } else {
            if (!this.cm.hasText()) {
                this.cm.setText(" ");
            }
            this.my = new TimerTask() {
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    try {
                        String t = AlsarabIME.this.cm.getText().toString();
                        if (!t.equals(AlsarabIME.this.t1)) {
                            String t2 = t.replace("'", " ");
                            if (AlsarabIME.this.list.contains(t2)) {
                                AlsarabIME.this.dbdelete(t2);
                                AlsarabIME.this.list.remove(t2);
                            }
                            if (AlsarabIME.this.dbadd(t2)) {
                                AlsarabIME.this.list.add(t2);
                                AlsarabIME.this.listfp();
                                AlsarabIME.this.t1 = t;
                            }
                        }
                    } catch (Exception e) {
                    }
                }
            };
        }
        dbcreate();
        dbload();
        SharedPreferences se = getSharedPreferences("SK", 0);
        this.co = se.getInt("co", 0);
        this.cl = se.getInt("cl", 0);
        this.cs = se.getInt("cs", 0);
        if (this.co == 1) {
            this.co = 0;
            tmron();
        }
    }

    @TargetApi(11)
    void tmroff() {
        if (this.av == 11) {
            try {
                this.cm2.removePrimaryClipChangedListener(this.rm);
                this.co = 0;
            } catch (Exception e) {
            }
        } else {
            try {
                this.my.cancel();
                this.co = 0;
            } catch (Exception e2) {
            }
        }
    }

    void nl() {
        InputConnection ic = getCurrentInputConnection();
        ic.commitText(" \n", 0);
    }

    void dbload() {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            this.list.clear();
            this.pinned.clear();
            Cursor c = d.rawQuery("SELECT note FROM notes", null);
            while (c.moveToNext()) {
                this.list.add(c.getString(0));
            }
            c.close();
            Cursor p = d.rawQuery("SELECT note FROM pinned ORDER BY rowid DESC", null);
            while (p.moveToNext()) {
                this.pinned.add(p.getString(0));
            }
            p.close();
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
        listfp();
    }

    void dbcreate() {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("CREATE TABLE IF NOT EXISTS notes (note VARCHAR);");
            d.execSQL("CREATE TABLE IF NOT EXISTS pinned (note VARCHAR);");
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
    }

    void clall() {
        InputConnection ic = getCurrentInputConnection();
        ic.deleteSurroundingText(1000, 1000);
    }

    void sall() {
        InputConnection ic = getCurrentInputConnection();
        ic.performContextMenuAction(android.R.id.selectAll);
    }

    void dbdelete(String s) {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("DELETE FROM notes WHERE note = ?", new Object[]{s});
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
    }

    void dbpin(String s, boolean pin) {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("DELETE FROM pinned WHERE note = ?", new Object[]{s});
            if (pin) {
                d.execSQL("INSERT INTO pinned (note) VALUES (?)", new Object[]{s});
            }
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
    }

    void deletetableall() {
        SQLiteDatabase d = null;
        try {
            this.list.clear();
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("DELETE FROM notes");
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
        listfp();
    }

    void po3() {
        LinearLayout my = (LinearLayout) getLayoutInflater().inflate(R.layout.layout4, (ViewGroup) null);
        AlertDialog.Builder Builder = new AlertDialog.Builder(this);
        this.Al3 = Builder.create();
        WindowManager.LayoutParams lp = this.Al3.getWindow().getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1000;
        keepEditorFocus(this.Al3);
        this.Al3.setView(my);
        ic();
        GridView grid = (GridView) my.findViewById(R.id.gridview2);
        final ImageAdapter adapter2 = new ImageAdapter(this);
        grid.setAdapter((ListAdapter) adapter2);
        final InputConnection lo = getCurrentInputConnection();
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                if (position == 0) {
                    if (AlsarabIME.this.ec == 0) {
                        AlsarabIME.this.ec = 1;
                    } else {
                        AlsarabIME.this.ec = 0;
                    }
                    AlsarabIME.this.ic();
                    adapter2.notifyDataSetChanged();
                    return;
                }
                lo.commitText(AlsarabIME.this.emj[position], 0);
            }
        });
        this.Al3.show();
    }

    void dd() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setNegativeButton("لا", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        builder.setPositiveButton("نعم", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                AlsarabIME.this.deletetableall();
                AlsarabIME.this.dbcreate();
            }
        });
        AlertDialog Al3 = builder.create();
        Al3.setMessage("هل انت متاكد من مسح الحافظة؟");
        Window window = Al3.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1003;
        Al3.show();
    }

    void po4() {
        final String[] sh = LatinKeyboardBaseView.CustomSmileys;
        LinearLayout my = (LinearLayout) getLayoutInflater().inflate(R.layout.layout5, (ViewGroup) null);
        AlertDialog.Builder Builder = new AlertDialog.Builder(this);
        this.Al4 = Builder.create();
        WindowManager.LayoutParams lp = this.Al4.getWindow().getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1000;
        keepEditorFocus(this.Al4);
        this.Al4.setView(my);
        GridView grid = (GridView) my.findViewById(R.id.gridview3);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<>(this, R.layout.layout6, sh);
        grid.setAdapter((ListAdapter) adapter4);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                InputConnection lo = AlsarabIME.this.getCurrentInputConnection();
                lo.commitText(sh[position], 0);
                AlsarabIME.this.Al4.dismiss();
            }
        });
        this.Al4.show();
    }

    void po2() {
        AbsoluteLayout my = (AbsoluteLayout) getLayoutInflater().inflate(R.layout.layout3, (ViewGroup) null);
        final CheckBox ck1 = (CheckBox) my.findViewById(R.id.checkBox1);
        final CheckBox ck2 = (CheckBox) my.findViewById(R.id.checkBox2);
        final CheckBox ck3 = (CheckBox) my.findViewById(R.id.checkBox3);
        Button bt3 = (Button) my.findViewById(R.id.button1);
        if (this.cl == 0) {
            ck1.setChecked(true);
        }
        if (this.cs == 1) {
            ck2.setChecked(true);
        }
        if (this.co == 1) {
            ck3.setChecked(true);
        }
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlsarabIME.this.dd();
            }
        });
        AlertDialog.Builder Builder = new AlertDialog.Builder(this);
        this.Al2 = Builder.create();
        WindowManager.LayoutParams lp = this.Al2.getWindow().getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1000;
        keepEditorFocus(this.Al2);
        this.Al2.setView(my);
        this.Al2.show();
        this.Al2.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                if (ck1.isChecked()) {
                    AlsarabIME.this.cl = 0;
                } else {
                    AlsarabIME.this.cl = 1;
                }
                if (ck2.isChecked()) {
                    AlsarabIME.this.cs = 1;
                } else {
                    AlsarabIME.this.cs = 0;
                }
                if (ck3.isChecked()) {
                    AlsarabIME.this.tmron();
                } else {
                    AlsarabIME.this.tmroff();
                }
                SharedPreferences settings = AlsarabIME.this.getSharedPreferences("SK", 0);
                SharedPreferences.Editor ed = settings.edit();
                ed.putInt("co", AlsarabIME.this.co);
                ed.putInt("cl", AlsarabIME.this.cl);
                ed.putInt("cs", AlsarabIME.this.cs);
                ed.commit();
            }
        });
    }

    public class VoiceResults {
        Map<String, List<CharSequence>> alternatives;
        List<String> candidates;

        private VoiceResults() {
        }

        VoiceResults(AlsarabIME dictionaryEditor, VoiceResults voiceResults) {
            this();
        }
    }

    public static abstract class WordAlternatives {
        protected CharSequence mChosenWord;

        public abstract List<CharSequence> getAlternatives();

        public abstract CharSequence getOriginalWord();

        public WordAlternatives() {
        }

        public WordAlternatives(CharSequence chosenWord) {
            this.mChosenWord = chosenWord;
        }

        public int hashCode() {
            return this.mChosenWord.hashCode();
        }

        public CharSequence getChosenWord() {
            return this.mChosenWord;
        }
    }

    public class TypedWordAlternatives extends WordAlternatives {
        private WordComposer word;

        public TypedWordAlternatives() {
        }

        public TypedWordAlternatives(CharSequence chosenWord, WordComposer wordComposer) {
            super(chosenWord);
            this.word = wordComposer;
        }

        @Override
        public CharSequence getOriginalWord() {
            return this.word.getTypedWord();
        }

        @Override
        public List<CharSequence> getAlternatives() {
            return AlsarabIME.this.getTypedSuggestions(this.word);
        }
    }

    private String mStartupError;
    String mLastClipText;
    long mLastClipTime;

    @Override // android.inputmethodservice.InputMethodService, android.app.Service
    public void onCreate() {
        super.onCreate();
        try {
            onCreateInner();
        } catch (Throwable t) {
            mStartupError = "onCreate failed:\n" + Log.getStackTraceString(t);
        }
    }

    private void onCreateInner() {
        clst();
        LatinImeLogger.init(this);
        Calibration.init(this);
        PackageName = getApplicationInfo().packageName;
        context = this;
        this.mResources = getResources();
        Configuration conf = this.mResources.getConfiguration();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        this.mLanguageSwitcher = new LanguageSwitcher(this);
        this.mLanguageSwitcher.loadLocales(prefs);
        this.mCalibration = Calibration.getInstance();
        this.mCalibration.setLanguageSwitcher(this.mLanguageSwitcher);
        this.mSystemLocale = conf.locale.toString();
        this.mLanguageSwitcher.setSystemLocale(conf.locale);
        this.mVoiceRecognitionTrigger = new VoiceRecognitionTrigger(this);
        String inputLanguage = this.mLanguageSwitcher.getInputLanguage();
        if (inputLanguage == null) {
            inputLanguage = conf.locale.toString();
        }
        this.mReCorrectionEnabled = prefs.getBoolean(PREF_RECORRECTION_ENABLED, getResources().getBoolean(R.bool.default_recorrection_enabled));
        this.mAlwaysSuggest = prefs.getBoolean(PREF_ALWAYS_SUGGEST, this.mResources.getBoolean(R.bool.always_suggest));
        this.mFullScreenPortrait = prefs.getBoolean(PREF_FULL_SCREEN_PORTRAIT, false);
        this.mNoFullScreenLandscape = prefs.getBoolean(PREF_FULL_SCREEN_LANDSCAPE, false);
        mUseCustomBackgrounColors = prefs.getBoolean(PREF_BACKGROUND_CUSTOM_KEY, this.mResources.getBoolean(R.bool.pref_background_custom));
        mUseCustomSuggestionColors = prefs.getBoolean(PREF_SUGGESTION_CUSTOM_KEY, this.mResources.getBoolean(R.bool.pref_suggestion_custom));
        this.mExternalSkin = prefs.getString(PREF_EXTERNAL_SKIN, LoggingEvents.EXTRA_CALLING_APP_NAME);
        if (!this.mExternalSkin.equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
            WordInfo.resetBuildersCache();
            WordInfo.getAllBuilders(context);
            skinData = WordInfo.getSkinDataByName(this.mExternalSkin);
        }
        if (skinData != null) {
            mUseExternalSkin = true;
        } else {
            mUseExternalSkin = false;
        }
        ImeUtils.GCUtils.getInstance().reset();
        boolean tryGC = true;
        for (int i = 0; i < 5 && tryGC; i++) {
            try {
                initSuggest(inputLanguage);
                tryGC = false;
            } catch (OutOfMemoryError e) {
                tryGC = ImeUtils.GCUtils.getInstance().tryGCOrWait(inputLanguage, e);
            } catch (RuntimeException e2) {
                // never let a dictionary problem stop the keyboard from starting
                tryGC = false;
            }
        }
        this.mOrientation = conf.orientation;
        initSuggestPuncList(prefs);
        IntentFilter filter = new IntentFilter("android.media.RINGER_MODE_CHANGED");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(this.mReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(this.mReceiver, filter);
        }
        this.mVoiceInput = new VoiceInput(this, this);
        this.mHints = new Hints(this, new Hints.Display() {
            @Override
            public void showHint(int viewResource) {
                LayoutInflater inflater = (LayoutInflater) AlsarabIME.this.getSystemService("layout_inflater");
                View view = inflater.inflate(viewResource, (ViewGroup) null);
                AlsarabIME.this.setCandidatesView(view);
                AlsarabIME.this.setCandidatesViewShown(true);
                AlsarabIME.this.mIsShowingHint = true;
            }
        });
        prefs.registerOnSharedPreferenceChangeListener(this);
        this.mMinimumVoiceRecognitionViewHeightPixel = Utils.dipToPixel(Utils.getDipScale(this), RECOGNITIONVIEW_MINIMUM_HEIGHT_DIP);
    }

    boolean dbadd(String s) {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("INSERT INTO notes (note) VALUES (?)", new Object[]{s});
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            if (d != null) {
                d.close();
            }
        }
    }

    /** Adds a copied text to the clipboard history (newest first, no duplicates, pinned items are not repeated). */
    void addClip(String t) {
        if (t == null || t.trim().length() == 0) {
            return;
        }
        if (dbadd(t)) {
            this.list.add(t);
            while (this.list.size() > CLIP_HISTORY_MAX) {
                this.list.remove(0);
                dbDeleteNoteAt(0);
            }
            listfp();
        }
    }

    /** Removes the history row at the given position (oldest first) from the database. */
    void dbDeleteNoteAt(int index) {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("DELETE FROM notes WHERE rowid = (SELECT rowid FROM notes ORDER BY rowid LIMIT 1 OFFSET ?)", new Object[]{Integer.valueOf(index)});
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
    }

    /** Removes the pinned row at the given position (newest first) from the database. */
    void dbDeletePinnedAt(int index) {
        SQLiteDatabase d = null;
        try {
            d = openOrCreateDatabase("Clipboard1.db", 0, null);
            d.execSQL("DELETE FROM pinned WHERE rowid = (SELECT rowid FROM pinned ORDER BY rowid DESC LIMIT 1 OFFSET ?)", new Object[]{Integer.valueOf(index)});
        } catch (Exception e) {
        } finally {
            if (d != null) {
                d.close();
            }
        }
    }

    private static final int AUTO_TYPE_DELAY_MS = 6;
    private final android.os.Handler mAutoTypeHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable mAutoTypeTask;

    /** Types a clipboard entry character by character, very fast, instead of pasting it at once. */
    void autoTypeClip(String text) {
        dismissClipChoice();
        cancelAutoType();
        if (this.cl == 0 && this.Al != null) {
            this.Al.dismiss();
        }
        final int[] codePoints = text.codePoints().toArray();
        final int[] next = {0};
        this.mAutoTypeTask = new Runnable() {
            @Override
            public void run() {
                InputConnection ic = AlsarabIME.this.getCurrentInputConnection();
                if (ic == null) {
                    AlsarabIME.this.mAutoTypeTask = null;
                    return;
                }
                if (next[0] >= codePoints.length) {
                    AlsarabIME.this.mAutoTypeTask = null;
                    if (AlsarabIME.this.cs == 1) {
                        AlsarabIME.this.sendKeyChar('\n');
                    }
                    return;
                }
                ic.commitText(new String(codePoints, next[0], 1), 1);
                next[0]++;
                AlsarabIME.this.mAutoTypeHandler.postDelayed(this, AUTO_TYPE_DELAY_MS);
            }
        };
        this.mAutoTypeHandler.post(this.mAutoTypeTask);
    }

    void cancelAutoType() {
        if (this.mAutoTypeTask != null) {
            this.mAutoTypeHandler.removeCallbacks(this.mAutoTypeTask);
            this.mAutoTypeTask = null;
        }
    }

    /** Pastes a clipboard entry into the current text field. */
    void pasteClip(String text) {
        dismissClipChoice();
        InputConnection lo = getCurrentInputConnection();
        if (lo != null) {
            lo.commitText(text, 0);
        }
        if (this.cs == 1) {
            sendKeyChar('\n');
        }
        if (this.cl == 0 && this.Al != null) {
            this.Al.dismiss();
        }
    }

    void pinClipAt(int position) {
        if (position < this.pinned.size()) {
            return;
        }
        int h = this.list.size() - 1 - (position - this.pinned.size());
        if (h < 0 || h >= this.list.size()) {
            return;
        }
        String text = this.list.remove(h);
        dbDeleteNoteAt(h);
        if (!this.pinned.contains(text)) {
            this.pinned.add(0, text);
            dbpin(text, true);
        }
        listfp();
        refreshClipAdapter();
    }

    void unpinClipAt(int position) {
        if (position >= this.pinned.size()) {
            return;
        }
        String text = this.pinned.remove(position);
        dbDeletePinnedAt(position);
        if (dbadd(text)) {
            this.list.add(text);
        }
        listfp();
        refreshClipAdapter();
    }

    void deleteClipAt(int position) {
        if (position < this.pinned.size()) {
            this.pinned.remove(position);
            dbDeletePinnedAt(position);
        } else {
            int h = this.list.size() - 1 - (position - this.pinned.size());
            if (h >= 0 && h < this.list.size()) {
                this.list.remove(h);
                dbDeleteNoteAt(h);
            }
        }
        listfp();
        refreshClipAdapter();
    }

    void refreshClipAdapter() {
        if (this.adapter != null) {
            ArrayList<String> copy = new ArrayList<>(this.listf);
            this.adapter.clear();
            this.adapter.addAll(copy);
            this.adapter.notifyDataSetChanged();
        }
    }

    private android.widget.PopupWindow mClipChoice;

    void dismissClipChoice() {
        if (this.mClipChoice != null) {
            try {
                this.mClipChoice.dismiss();
            } catch (Exception e) {
            }
            this.mClipChoice = null;
        }
    }

    private android.widget.TextView clipChoiceButton(int labelRes, View.OnClickListener listener) {
        android.widget.TextView button = new android.widget.TextView(this);
        button.setText(labelRes);
        button.setTextColor(0xffffffff);
        button.setTextSize(15);
        button.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        button.setSingleLine(true);
        button.setEllipsize(android.text.TextUtils.TruncateAt.END);
        button.setGravity(android.view.Gravity.CENTER);
        button.setClickable(true);
        button.setOnClickListener(listener);
        return button;
    }

    /** Tap on a clipboard entry: a small bar with Paste / Auto-type appears right above it. */
    void showClipChoice(View gridView, View cell, final String text) {
        dismissClipChoice();
        try {
            float dp = getResources().getDisplayMetrics().density;
            int barWidth = cell.getWidth();
            int barHeight = Math.max(cell.getHeight(), (int) (56 * dp));
            LinearLayout bar = new LinearLayout(this);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            android.graphics.drawable.GradientDrawable background = new android.graphics.drawable.GradientDrawable();
            background.setColor(0xff4a4a4a);
            background.setCornerRadius(14.0f * dp);
            bar.setBackground(background);
            bar.addView(clipChoiceButton(R.string.clip_autotype, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlsarabIME.this.dismissClipChoice();
                    AlsarabIME.this.autoTypeClip(text);
                }
            }), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f));
            View divider = new View(this);
            divider.setBackgroundColor(0xff333333);
            bar.addView(divider, new LinearLayout.LayoutParams((int) Math.max(1, dp), ViewGroup.LayoutParams.MATCH_PARENT));
            bar.addView(clipChoiceButton(R.string.clip_paste, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlsarabIME.this.dismissClipChoice();
                    AlsarabIME.this.pasteClip(text);
                }
            }), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f));

            View keyboardView = this.mCalibration.getInputView();
            if (keyboardView == null) {
                return;
            }
            int[] cellPos = new int[2];
            int[] gridPos = new int[2];
            int[] rootPos = new int[2];
            cell.getLocationOnScreen(cellPos);
            gridView.getLocationOnScreen(gridPos);
            keyboardView.getRootView().getLocationOnScreen(rootPos);
            int x = Math.max(gridPos[0], Math.min(cellPos[0], gridPos[0] + gridView.getWidth() - barWidth));
            int y = Math.max(gridPos[1], Math.min(cellPos[1], gridPos[1] + gridView.getHeight() - barHeight));
            android.widget.PopupWindow popup = new android.widget.PopupWindow(bar, barWidth, barHeight, false);
            popup.setElevation(8 * dp);
            popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            popup.setOutsideTouchable(true);
            this.mClipChoice = popup;
            popup.showAtLocation(keyboardView, android.view.Gravity.TOP | android.view.Gravity.LEFT, x - rootPos[0], y - rootPos[1]);
        } catch (Exception e) {
            this.mClipChoice = null;
        }
    }

    private View clipMenuRow(int iconRes, int labelRes, View.OnClickListener listener) {
        float dp = getResources().getDisplayMetrics().density;
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding((int) (16 * dp), (int) (13 * dp), (int) (24 * dp), (int) (13 * dp));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(0xff111111);
        row.addView(icon, new LinearLayout.LayoutParams((int) (24 * dp), (int) (24 * dp)));
        android.widget.TextView label = new android.widget.TextView(this);
        label.setText(labelRes);
        label.setTextColor(0xff111111);
        label.setTextSize(17);
        label.setPadding((int) (16 * dp), 0, (int) (8 * dp), 0);
        row.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.setClickable(true);
        row.setOnClickListener(listener);
        return row;
    }

    /** Long-press menu for a clipboard entry: paste / pin (unpin) / delete. */
    void showClipMenu(final String text, final int position) {
        dismissClipChoice();
        try {
            float dp = getResources().getDisplayMetrics().density;
            final boolean isPinned = position < this.pinned.size();
            final AlertDialog[] holder = new AlertDialog[1];
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            int pad = (int) (8 * dp);
            box.setPadding(pad, pad, pad, pad);
            android.widget.TextView preview = new android.widget.TextView(this);
            preview.setText(text);
            preview.setMaxLines(2);
            preview.setEllipsize(android.text.TextUtils.TruncateAt.END);
            preview.setTextColor(0xff666666);
            preview.setTextSize(13);
            preview.setPadding((int) (16 * dp), (int) (6 * dp), (int) (16 * dp), (int) (8 * dp));
            box.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            box.addView(clipMenuRow(R.drawable.ic_clip_pin, isPinned ? R.string.clip_unpin : R.string.clip_pin, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    holder[0].dismiss();
                    if (isPinned) {
                        AlsarabIME.this.unpinClipAt(position);
                    } else {
                        AlsarabIME.this.pinClipAt(position);
                    }
                }
            }));
            box.addView(clipMenuRow(R.drawable.ic_clip_delete, R.string.clip_delete, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    holder[0].dismiss();
                    AlsarabIME.this.deleteClipAt(position);
                }
            }));
            AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setView(box);
            AlertDialog d = b.create();
            holder[0] = d;
            WindowManager.LayoutParams lp = d.getWindow().getAttributes();
            lp.token = this.mCalibration.getInputView().getWindowToken();
            lp.type = 1000;
            keepEditorFocus(d);
            android.graphics.drawable.GradientDrawable card = new android.graphics.drawable.GradientDrawable();
            card.setColor(0xfff5f5f5);
            card.setCornerRadius(18.0f * dp);
            box.setBackground(card);
            d.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    AlsarabIME.this.mClipMenuOpen = false;
                }
            });
            this.mClipMenuOpen = true;
            d.show();
        } catch (Exception e) {
            this.mClipMenuOpen = false;
        }
    }

    public static ArrayList<ExternalDictionaries.DictionaryBuilder> getDictionary(Context localContext, Resources res) {
        ArrayList<ExternalDictionaries.DictionaryBuilder> dictionaries = ExternalDictionaries.getAllBuilders(localContext);
        ArrayList<ExternalDictionaries.DictionaryBuilder> local_dictionaries = new ArrayList<>();
        int dictionaries_size = dictionaries.size();
        int i = 0;
        while (true) {
            if (i >= dictionaries_size) {
                break;
            }
            String local_language = res.getConfiguration().locale.getLanguage();
            if (local_language.equals("he")) {
                local_language = "iw";
            }
            if (!local_language.equals(dictionaries.get(i).getLanguage())) {
                i++;
            } else {
                local_dictionaries.add(dictionaries.get(i));
                break;
            }
        }
        return local_dictionaries;
    }

    private void initSuggest(String locale) {
        mInputLocale = locale;
        String supportedLocalesString = SettingsUtil.getSettingsString(getContentResolver(), SettingsUtil.LATIN_IME_VOICE_INPUT_SUPPORTED_LOCALES, DEFAULT_VOICE_INPUT_SUPPORTED_LOCALES);
        ArrayList<String> voiceInputSupportedLocales = newArrayList(supportedLocalesString.split("\\s+"));
        this.mLocaleSupportedForVoiceInput = voiceInputSupportedLocales.contains(mInputLocale);
        Resources orig = getResources();
        Configuration conf = orig.getConfiguration();
        Locale saveLocale = conf.locale;
        conf.locale = new Locale(locale);
        orig.updateConfiguration(conf, orig.getDisplayMetrics());
        if (this.mSuggest != null) {
            this.mSuggest.close();
        }
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        this.mQuickFixes = sp.getBoolean(PREF_QUICK_FIXES, true);
        this.mUseContactDictionary = sp.getBoolean(PREF_USE_CONTACT_DICTIONARY, true);
        ArrayList<ExternalDictionaries.DictionaryBuilder> dictionaries = getDictionary(context, getResources());
        this.mSuggest = new Suggest(this, dictionaries, conf.locale, orig);
        updateAutoTextEnabled(saveLocale);
        if (this.mUserDictionary != null) {
            this.mUserDictionary.close();
        }
        this.mUserDictionary = new UserDictionary(this, mInputLocale);
        if (!this.mUseContactDictionary) {
            this.mContactsDictionary = null;
        }
        if (this.mContactsDictionary == null && this.mUseContactDictionary) {
            this.mContactsDictionary = new ContactsDictionary(this, 4);
        }
        if (this.mAutoTextDictionary == null) {
            this.mAutoTextDictionary = new AutoTextDictionary(this, this);
        }
        if (this.mAutoDictionary != null) {
            this.mAutoDictionary.close();
        }
        this.mAutoDictionary = new AutoDictionary(this, this, mInputLocale, 3);
        if (this.mUserBigramDictionary != null) {
            this.mUserBigramDictionary.close();
        }
        this.mUserBigramDictionary = new UserBigramDictionary(this, this, mInputLocale, 2);
        this.mSuggest.setUserBigramDictionary(this.mUserBigramDictionary);
        this.mSuggest.setUserDictionary(this.mUserDictionary);
        this.mSuggest.setContactsDictionary(this.mContactsDictionary);
        this.mSuggest.setAutoDictionary(this.mAutoDictionary);
        this.mSuggest.setAutoTextDictionary(this.mAutoTextDictionary);
        updateCorrectionMode();
        this.mWordSeparators = this.mResources.getString(R.string.word_separators);
        this.mSentenceSeparators = this.mResources.getString(R.string.sentence_separators);
        conf.locale = saveLocale;
        orig.updateConfiguration(conf, orig.getDisplayMetrics());
        mSuggestionFontClor = sp.getInt(PREF_SUGGESTIONS_FONT_COLOR, this.mResources.getColor(R.color.candidate_recommended));
        CandidateView.setColor(mSuggestionFontClor);
        mKeyboardBackgroundColor = sp.getInt(PREF_KEYBOARD_BACKGROUND_COLOR, -16777216);
        mSuggestionBarColor = sp.getInt("suggestion_bar_color", -16777216);
        String suggestBarSize = sp.getString(PREF_SUGGESTION_BAR_SIZE, "1");
        suggestionSizeBig = false;
        if (suggestBarSize.equals("2")) {
            suggestionSizeBig = true;
        }
        mButtonColor = sp.getInt(PREF_BUTTON_COLOR, this.mResources.getColor(R.color.button_color));
        LatinKeyboardBaseView.setColor(mButtonColor);
        mRTLEnabled = sp.getBoolean(PREF_RTL_SUPPORTED, false);
        CandidateView.setRTL(mRTLEnabled);
        PERF_DEBUG = sp.getBoolean(PREF_DEBUG_ON, false);
        if (PERF_DEBUG) {
            DEBUG = true;
        }
        this.mShowTouchPoints = sp.getBoolean(PREF_SHOW_TOUCH_POINTS, false);
        LatinKeyboardBaseView.setShowTouchPoints(this.mShowTouchPoints);
    }

    @Override // android.inputmethodservice.InputMethodService, android.inputmethodservice.AbstractInputMethodService, android.app.Service
    public void onDestroy() {
        tmroff();
        if (this.mUserDictionary != null) {
            this.mUserDictionary.close();
        }
        if (this.mAutoTextDictionary != null) {
            this.mAutoTextDictionary.close();
        }
        if (this.mContactsDictionary != null) {
            this.mContactsDictionary.close();
        }
        unregisterReceiver(this.mReceiver);
        if (this.mVoiceInput != null) {
            this.mVoiceInput.destroy();
        }
        LatinImeLogger.commit();
        LatinImeLogger.onDestroy();
        this.mVoiceRecognitionTrigger.unregister(this);
        super.onDestroy();
    }

    @Override // android.inputmethodservice.InputMethodService, android.inputmethodservice.AbstractInputMethodService, android.app.Service, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration conf) {
        String systemLocale = conf.locale.toString();
        if (!TextUtils.equals(systemLocale, this.mSystemLocale)) {
            this.mSystemLocale = systemLocale;
            if (this.mLanguageSwitcher != null) {
                this.mLanguageSwitcher.loadLocales(PreferenceManager.getDefaultSharedPreferences(this));
                this.mLanguageSwitcher.setSystemLocale(conf.locale);
                toggleLanguage(true, true);
            } else {
                reloadKeyboards();
            }
        }
        this.mCalibration.updateKeyboardConfiguration();
        if (conf.orientation != this.mOrientation) {
            if (isT9Mode() && this.mBestWord != null && this.mPredicting) {
                pickSuggestion(this.mBestWord, true);
            }
            InputConnection ic = getCurrentInputConnection();
            commitTyped(ic);
            if (ic != null) {
                ic.finishComposingText();
            }
            this.mOrientation = conf.orientation;
            reloadKeyboards();
        }
        this.mConfigurationChanging = true;
        super.onConfigurationChanged(conf);
        if (this.mRecognizing) {
            switchToRecognitionStatusView(conf);
        }
        this.mConfigurationChanging = false;
    }

    @Override
    public View onCreateInputView() {
        if (mStartupError != null) {
            return new View(this);
        }
        try {
            this.mCalibration.recreateInputView();
            this.mCalibration.makeKeyboards(true, this.mLanguageSwitcher.getInputLayout());
            this.mCalibration.setKeyboardMode(1, 0, shouldShowVoiceButton(makeFieldContext(), getCurrentInputEditorInfo()));
            View view = this.mCalibration.getInputView();
            if (view == null) {
                throw new IllegalStateException("keyboard view could not be created");
            }
            if (this.mCalibration.getInputView().getKeyboard() == null) {
                throw new IllegalStateException("keyboard layout could not be loaded");
            }
            return view;
        } catch (Throwable t) {
            Log.e("AlsarabKeyboard", "input view failed", t);
            return new View(this);
        }
    }

    @Override
    public void setInputView(View view) {
        if (Build.VERSION.SDK_INT >= 21 && view != null && !(view instanceof NavPadLayout)) {
            try {
                ViewParent oldParent = view.getParent();
                if (oldParent instanceof ViewGroup) {
                    ((ViewGroup) oldParent).removeView(view);
                }
                NavPadLayout wrapper = new NavPadLayout(this);
                android.graphics.drawable.Drawable bg = view.getBackground();
                if (bg != null && bg.getConstantState() != null) {
                    wrapper.setBackgroundDrawable(bg.getConstantState().newDrawable().mutate());
                } else {
                    wrapper.setBackgroundColor(0xff1c1c1c);
                }
                wrapper.addView(view, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                this.mInputWrapper = wrapper;
                if (this.mCandidateViewContainer == null) {
                    buildCandidateContainer();
                }
                attachCandidateStrip();
                view = wrapper;
            } catch (Throwable ignored) {
            }
        }
        super.setInputView(view);
    }

    @Override
    public View onCreateCandidatesView() {
        this.mCalibration.makeKeyboards(true, this.mLanguageSwitcher.getInputLayout());
        buildCandidateContainer();
        if (Build.VERSION.SDK_INT >= 21) {
            // الشريط صار جزء من لوحة المفاتيح نفسها (إطار الاقتراحات القديم ما يظهر على أندرويد الجديد)
            attachCandidateStrip();
            return new View(this);
        }
        setCandidatesViewShown(true);
        return this.mCandidateViewContainer;
    }

    private NavPadLayout mInputWrapper = null;

    private void buildCandidateContainer() {
        if (this.mCandidateViewContainer != null && this.mCandidateViewContainer.getParent() instanceof ViewGroup) {
            ((ViewGroup) this.mCandidateViewContainer.getParent()).removeView(this.mCandidateViewContainer);
        }
        this.mCandidateViewContainer = (LinearLayout) getLayoutInflater().inflate(R.layout.candidates, (ViewGroup) null);
        this.mCandidateView = (CandidateView) this.mCandidateViewContainer.findViewById(R.id.candidates);
        this.mCandidateView.setService(this);
        if (suggestionSizeBig) {
            this.mCandidateView.getLayoutParams().height = (this.mCandidateView.getLayoutParams().height * 18) / 10;
        }
        if (!mUseCustomSuggestionColors && mUseExternalSkin && skinData.candidate_background != null) {
            this.mCandidateViewContainer.setBackgroundDrawable(skinData.candidate_background);
            this.mCandidateViewContainer.getBackground().clearColorFilter();
        } else if (mUseCustomSuggestionColors) {
            this.mCandidateViewContainer.getBackground().setColorFilter(getSuggestionBarColor(), PorterDuff.Mode.MULTIPLY);
        } else {
            // خلفية غامقة صريحة (الفلتر القديم على الصورة يطلع أبيض على أندرويد الجديد، والكلمات بيضاء فتختفي)
            this.mCandidateViewContainer.setBackgroundColor(0xff3a3a3a);
        }
    }

    private void attachCandidateStrip() {
        if (this.mInputWrapper == null || this.mCandidateViewContainer == null) {
            return;
        }
        if (this.mCandidateViewContainer.getParent() != this.mInputWrapper) {
            if (this.mCandidateViewContainer.getParent() instanceof ViewGroup) {
                ((ViewGroup) this.mCandidateViewContainer.getParent()).removeView(this.mCandidateViewContainer);
            }
            this.mInputWrapper.addView(this.mCandidateViewContainer, 0, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        this.mCandidateViewContainer.setVisibility((isCandidateStripVisible() || this.mCompletionOn) ? View.VISIBLE : View.GONE);
    }

    @Override
    public void setCandidatesView(View view) {
        if (Build.VERSION.SDK_INT >= 21) {
            if (view == this.mCandidateViewContainer) {
                attachCandidateStrip();
            }
            return;
        }
        super.setCandidatesView(view);
    }

    @Override
    public void onStartInputView(EditorInfo attribute, boolean restarting) {
        cancelAutoType();
        boolean z = true;
        this.mComposing.setLength(0);
        this.mPredicting = false;
        this.mDeleteCount = 0;
        this.mJustAddedAutoSpace = false;
        LatinKeyboardView inputView = this.mCalibration.getInputView();
        this.mFieldUrlOrWeb = false;
        if (this.mVoiceRecognitionTrigger != null) {
            this.mVoiceRecognitionTrigger.onStartInputView();
        }
        if (inputView != null) {
            if (this.mRefreshKeyboardRequired) {
                this.mRefreshKeyboardRequired = false;
                toggleLanguage(true, true);
            }
            this.mCalibration.makeKeyboards(false, this.mLanguageSwitcher.getInputLayout());
            TextEntryState.newSession(this);
            this.mPasswordText = false;
            int variation = attribute.inputType & 4080;
            if (variation == 128 || variation == 144 || variation == 224) {
                this.mPasswordText = true;
            }
            this.mEnableVoiceButton = shouldShowVoiceButton(makeFieldContext(), attribute);
            boolean enableVoiceButton = this.mEnableVoiceButton && this.mEnableVoice;
            this.mAfterVoiceInput = false;
            this.mImmediatelyAfterVoiceInput = false;
            this.mShowingVoiceSuggestions = false;
            this.mVoiceInputHighlighted = false;
            this.mInputTypeNoAutoCorrect = false;
            this.mPredictionOn = this.mAlwaysSuggest && !isFullscreenMode();
            if (attribute.packageName.equals("com.android.email")) {
                this.mPredictionOn = this.mAlwaysSuggest;
            }
            this.mCompletionOn = false;
            this.mCompletions = null;
            this.mCapsLock = false;
            this.mEnteredText = null;
            Integer a = 0;
            switch (attribute.inputType & 15) {
                case 1:
                    this.mCalibration.setKeyboardMode(1, attribute.imeOptions, enableVoiceButton);
                    this.mPredictionOn = true;
                    if (variation == 128 || variation == 144 || variation == 224) {
                        this.mPredictionOn = false;
                        a = Integer.valueOf(a.intValue() | 296);
                    }
                    if (variation == 32 || variation == 96 || variation == 208) {
                        this.mAutoSpace = this.mAlwaysSuggest && !isFullscreenMode();
                        a = Integer.valueOf(a.intValue() | 1);
                    } else {
                        this.mAutoSpace = true;
                    }
                    if (variation == 32) {
                        this.mPredictionOn = this.mAlwaysSuggest && !isFullscreenMode();
                        this.mCalibration.setKeyboardMode(5, attribute.imeOptions, enableVoiceButton);
                        this.mFieldUrlOrWeb = true;
                        a = Integer.valueOf(a.intValue() | 2);
                    } else if (variation == 16) {
                        this.mPredictionOn = this.mAlwaysSuggest && !isFullscreenMode();
                        this.mCalibration.setKeyboardMode(4, attribute.imeOptions, enableVoiceButton);
                        this.mFieldUrlOrWeb = true;
                        a = Integer.valueOf(a.intValue() | 4);
                    } else if (variation == 64) {
                        this.mCalibration.setKeyboardMode(1, attribute.imeOptions, enableVoiceButton);
                    } else if (variation == 176) {
                        this.mPredictionOn = this.mAlwaysSuggest && !isFullscreenMode();
                        a = Integer.valueOf(a.intValue() | 8);
                    } else if (variation == 160) {
                        this.mCalibration.setKeyboardMode(7, attribute.imeOptions, enableVoiceButton);
                        if ((attribute.inputType & 32768) == 0) {
                            this.mInputTypeNoAutoCorrect = true;
                        }
                    }
                    if ((attribute.inputType & 524288) != 0) {
                        this.mPredictionOn = this.mAlwaysSuggest && !isFullscreenMode();
                        this.mInputTypeNoAutoCorrect = true;
                        a = Integer.valueOf(a.intValue() | 22);
                    }
                    if ((attribute.inputType & 32768) == 0 && (attribute.inputType & 131072) == 0) {
                        this.mInputTypeNoAutoCorrect = !this.mAlwaysSuggest || isFullscreenMode();
                        a = Integer.valueOf(a.intValue() | 50);
                    }
                    if ((attribute.inputType & MyMetaKeyKeyListener.META_SELECTING) != 0) {
                        this.mPredictionOn = this.mAlwaysSuggest && !isFullscreenMode();
                        this.mCompletionOn = isFullscreenMode();
                        a = Integer.valueOf(a.intValue() | 100);
                        break;
                    }
                    break;
                case 2:
                case 3:
                case 4:
                case 16:
                    this.mPredictionOn = false;
                    this.mCalibration.setKeyboardMode(3, attribute.imeOptions, enableVoiceButton);
                    break;
                default:
                    this.mCalibration.setKeyboardMode(1, attribute.imeOptions, enableVoiceButton);
                    break;
            }
            if (DEBUG) {
                Log.i(TAG, "*****************************a=" + a.toString() + attribute.packageName + String.valueOf(attribute.inputType));
            }
            if (this.mPasswordText) {
                this.mPredictionOn = false;
            }
            inputView.closing();
            loadSettings();
            updateShiftKeyState(attribute);
            setCandidatesViewShownInternal(isCandidateStripVisible() || this.mCompletionOn, false);
            updateSuggestions();
            mHasDictionary = this.mSuggest.hasMainDictionary();
            updateCorrectionMode();
            inputView.setPreviewEnabled(this.mPopupOn);
            inputView.setLongPressDelay(this.mLongPressDelay);
            inputView.setProximityCorrectionEnabled(true);
            if (!this.mPredictionOn || (this.mCorrectionMode <= 0 && !this.mShowSuggestions)) {
                z = false;
            }
            this.mPredictionOn = z;
            checkReCorrectionOnStart();
            checkTutorial(attribute.privateImeOptions);
            if (TRACE) {
                Debug.startMethodTracing("/data/trace/latinime");
            }
        }
    }

    void ic() {
        if (this.ec == 0) {
            this.ms = new int[]{R.drawable.sh, R.drawable.e001, R.drawable.e002, R.drawable.e003, R.drawable.e004, R.drawable.e005, R.drawable.e006, R.drawable.e007, R.drawable.e008, R.drawable.e009, R.drawable.e010, R.drawable.e011, R.drawable.e012, R.drawable.e013, R.drawable.e014, R.drawable.e015, R.drawable.e016, R.drawable.e017, R.drawable.e018, R.drawable.e019, R.drawable.e020, R.drawable.e021, R.drawable.e022, R.drawable.e023, R.drawable.e024, R.drawable.e025, R.drawable.e026, R.drawable.e027, R.drawable.e028, R.drawable.e029, R.drawable.e030, R.drawable.e031, R.drawable.e032, R.drawable.e033, R.drawable.e034, R.drawable.e035, R.drawable.e036, R.drawable.e037, R.drawable.e038, R.drawable.e039, R.drawable.e040, R.drawable.e041, R.drawable.e042, R.drawable.e043, R.drawable.e044, R.drawable.e045, R.drawable.e046, R.drawable.e047, R.drawable.e048, R.drawable.e049, R.drawable.e050, R.drawable.e051, R.drawable.e052, R.drawable.e053, R.drawable.e054, R.drawable.e055, R.drawable.e056, R.drawable.e057, R.drawable.e058, R.drawable.e059, R.drawable.e060, R.drawable.e061, R.drawable.e062, R.drawable.e063, R.drawable.e064, R.drawable.e065, R.drawable.e066, R.drawable.e067, R.drawable.e068, R.drawable.e069, R.drawable.e070, R.drawable.e071, R.drawable.e072, R.drawable.e073, R.drawable.e074, R.drawable.e075, R.drawable.e076, R.drawable.e077, R.drawable.e078, R.drawable.e079, R.drawable.e080, R.drawable.e081, R.drawable.e082, R.drawable.e083, R.drawable.e084, R.drawable.e085, R.drawable.e086, R.drawable.e087, R.drawable.e088, R.drawable.e089, R.drawable.e090, R.drawable.e091, R.drawable.e092, R.drawable.e093, R.drawable.e094, R.drawable.e095, R.drawable.e096, R.drawable.e097, R.drawable.e098, R.drawable.e099, R.drawable.e100, R.drawable.e101, R.drawable.e102, R.drawable.e103, R.drawable.e104, R.drawable.e105, R.drawable.e106, R.drawable.e107, R.drawable.e108, R.drawable.e109, R.drawable.e110, R.drawable.e111, R.drawable.e112, R.drawable.e113, R.drawable.e114, R.drawable.e115, R.drawable.e116, R.drawable.e117, R.drawable.e118, R.drawable.e119, R.drawable.e120, R.drawable.e121, R.drawable.e122, R.drawable.e123, R.drawable.e124, R.drawable.e125, R.drawable.e126, R.drawable.e127, R.drawable.e128, R.drawable.e129, R.drawable.e130, R.drawable.e131, R.drawable.e132, R.drawable.e133, R.drawable.e134, R.drawable.e135, R.drawable.e136, R.drawable.e137, R.drawable.e138, R.drawable.e139, R.drawable.e140, R.drawable.e141, R.drawable.e142, R.drawable.e143, R.drawable.e144, R.drawable.e145, R.drawable.e146, R.drawable.e147, R.drawable.e148, R.drawable.e149, R.drawable.e150, R.drawable.e151, R.drawable.e152, R.drawable.e153, R.drawable.e154, R.drawable.e155, R.drawable.e156, R.drawable.e157, R.drawable.e158, R.drawable.e159, R.drawable.e160, R.drawable.e161, R.drawable.e162, R.drawable.e163, R.drawable.e164, R.drawable.e165, R.drawable.e166, R.drawable.e167, R.drawable.e168, R.drawable.e169, R.drawable.e170, R.drawable.e171, R.drawable.e172, R.drawable.e173, R.drawable.e174, R.drawable.e175, R.drawable.e176, R.drawable.e177, R.drawable.e178, R.drawable.e179, R.drawable.e180, R.drawable.e181, R.drawable.e182, R.drawable.e183, R.drawable.e184, R.drawable.e185, R.drawable.e186, R.drawable.e187, R.drawable.e188, R.drawable.e189, R.drawable.e190, R.drawable.e191, R.drawable.e192, R.drawable.e193, R.drawable.e194, R.drawable.e195, R.drawable.e196, R.drawable.e197, R.drawable.e198, R.drawable.e199, R.drawable.e200, R.drawable.e201, R.drawable.e202, R.drawable.e203, R.drawable.e204, R.drawable.e205, R.drawable.e206, R.drawable.e207, R.drawable.e208, R.drawable.e209, R.drawable.e210, R.drawable.e211, R.drawable.e212, R.drawable.e213, R.drawable.e214, R.drawable.e215, R.drawable.e216, R.drawable.e217, R.drawable.e218, R.drawable.e219, R.drawable.e220, R.drawable.e221, R.drawable.e222, R.drawable.e223, R.drawable.e224, R.drawable.e225, R.drawable.e226, R.drawable.e227, R.drawable.e228, R.drawable.e229, R.drawable.e230, R.drawable.e231, R.drawable.e232, R.drawable.e233, R.drawable.e234, R.drawable.e235, R.drawable.e236, R.drawable.e237, R.drawable.e238, R.drawable.e239, R.drawable.e240, R.drawable.e241, R.drawable.e242, R.drawable.e243, R.drawable.e244, R.drawable.e245, R.drawable.e246, R.drawable.e247, R.drawable.e248, R.drawable.e249, R.drawable.e250, R.drawable.e251, R.drawable.e252, R.drawable.e253, R.drawable.e254, R.drawable.e255, R.drawable.e256, R.drawable.e257, R.drawable.e258, R.drawable.e259, R.drawable.e260, R.drawable.e261, R.drawable.e262, R.drawable.e263, R.drawable.e264, R.drawable.e265, R.drawable.e266, R.drawable.e267, R.drawable.e268, R.drawable.e269, R.drawable.e270, R.drawable.e271, R.drawable.e272, R.drawable.e273, R.drawable.e274, R.drawable.e275, R.drawable.e276, R.drawable.e277, R.drawable.e278, R.drawable.e279, R.drawable.e280, R.drawable.e281, R.drawable.e282, R.drawable.e283, R.drawable.e284, R.drawable.e285, R.drawable.e286, R.drawable.e287, R.drawable.e288, R.drawable.e289, R.drawable.e290, R.drawable.e291, R.drawable.e292, R.drawable.e293, R.drawable.e294, R.drawable.e295, R.drawable.e296, R.drawable.e297, R.drawable.e298};
            this.emj = new String[]{LoggingEvents.EXTRA_CALLING_APP_NAME, "\ue415", "\ue057", "😀", "\ue056", "\ue414", "\ue405", "\ue106", "\ue418", "\ue417", "😙", "😗", "\ue105", "\ue409", "😛", "\ue40d", "\ue404", "\ue403", "\ue40a", "\ue40e", "\ue058", "\ue406", "\ue413", "\ue412", "\ue411", "\ue408", "\ue401", "\ue40f", "😅", "\ue108", "😩", "😫", "\ue40b", "\ue107", "\ue059", "\ue416", "😤", "\ue407", "😆", "😋", "\ue40c", "😎", "😴", "😵", "\ue410", "😟", "😦", "😧", "😈", "\ue11a", "😮", "😬", "😐", "😕", "😯", "😶", "😇", "\ue402", "😑", "😺", "😸", "😻", "😽", "😼", "🙀", "😿", "😹", "😾", "👹", "👺", "🙈", "🙉", "🙊", "\ue11b", "\ue11c", "\ue10c", "\ue41a", "\ue41b", "\ue419", "👅", "\ue41c", "\ue00d", "\ue00e", "\ue421", "\ue22e", "\ue22f", "\ue231", "\ue230", "\ue41f", "\ue422", "\ue011", "\ue14c", "\ue115", "\ue004", "\ue001", "\ue002", "👬", "👭", "\ue31d", "\ue10e", "\ue318", "\ue007", "\ue31a", "\ue13e", "👞", "\ue006", "👚", "\ue319", "👖", "\ue11e", "\ue323", "👛", "👓", "\ue314", "\ue31c", "\ue022", "\ue023", "\ue329", "\ue034", "\ue035", "\ue536", "🐣", "🐥", "\ue52d", "🐢", "\ue525", "🐝", "🐜", "🐞", "🐌", "\ue441", "\ue019", "\ue054", "🐄", "🐏", "🐀", "🐅", "🐇", "\ue134", "🐐", "🐓", "🐕", "🐂", "\ue530", "🐈", "\ue528", "\ue306", "\ue030", "\ue304", "\ue032", "\ue305", "\ue303", "\ue118", "🍄", "\ue307", "🌳", "🌿", "🌼", "🌞", "🌝", "🌛", "\ue04c", "🌍", "\ue04a", "⛅", "\ue43c", "\ue11d", "\ue32f", "\ue112", "\ue312", "\ue008", "📹", "\ue03c", "\ue009", "\ue142", "\ue127", "\ue00c", "\ue12a", "\ue128", "🔈", "🔇", "🕞", "⏰", "⌚", "⌛", "🔋", "\ue145", "\ue144", "\ue03f", "🔎", "\ue10f", "🔦", "🔌", "🚪", "🚿", "🔧", "🔩", "🔗", "\ue116", "\ue311", "\ue113", "🔪", "\ue313", "\ue30f", "\ue13b", "\ue12f", "💵", "💳", "✉", "📬", "📦", "✏", "✒", "\ue301", "📄", "📃", "📜", "📋", "📅", "📌", "📎", "📏", "📐", "📘", "📚", "\ue148", "🔬", "🔭", "📰", "\ue502", "🎮", "\ue131", "\ue018", "\ue132", "🏇", "🍼", "\ue338", "\ue045", "🍹", "\ue043", "🍕", "\ue120", "\ue33b", "🍗", "\ue33f", "\ue33e", "\ue340", "\ue34d", "\ue33c", "\ue147", "\ue339", "🍩", "🍮", "\ue33a", "\ue43f", "\ue34b", "\ue046", "🍪", "🍫", "🍬", "🍭", "🍯", "\ue345", "\ue346", "🍋", "🍒", "🍇", "\ue348", "🍌", "🍐", "🍍", "\ue347", "\ue34a", "\ue349", "🌽", "🏡", "\ue158", "\ue157", "🇸🇦", "💧", "\ue11f", "\ue01c", "\ue136", "\ue01d", "🚁", "\ue10d", "\ue435", "🚍", "🚘", "🚖", "\ue42f", "🚔", "\ue430", "\ue431", "🚦", "\ue03a", "⛔", "🚫", "\ue123"};
        } else {
            this.ms = new int[]{R.drawable.sh, R.drawable.u001, R.drawable.u002, R.drawable.u003, R.drawable.u004, R.drawable.u005, R.drawable.u006, R.drawable.u007, R.drawable.u008, R.drawable.u009, R.drawable.u010, R.drawable.u011, R.drawable.u012, R.drawable.u013, R.drawable.u014, R.drawable.u015, R.drawable.u016, R.drawable.u017, R.drawable.u018, R.drawable.u019, R.drawable.u020, R.drawable.u021, R.drawable.u022, R.drawable.u023, R.drawable.u024, R.drawable.u025, R.drawable.u026, R.drawable.u027, R.drawable.u028, R.drawable.u029, R.drawable.u030, R.drawable.u031, R.drawable.u032, R.drawable.u033, R.drawable.u034, R.drawable.u035, R.drawable.u036, R.drawable.u037, R.drawable.u038, R.drawable.u039, R.drawable.u040, R.drawable.u041, R.drawable.u042, R.drawable.u043, R.drawable.u044, R.drawable.u045, R.drawable.u046, R.drawable.u047, R.drawable.u048, R.drawable.u049, R.drawable.u050, R.drawable.u051, R.drawable.u052, R.drawable.u053, R.drawable.u054, R.drawable.u055, R.drawable.u056, R.drawable.u057, R.drawable.u058, R.drawable.u059, R.drawable.u060, R.drawable.u061, R.drawable.u062, R.drawable.u063, R.drawable.u064, R.drawable.u065, R.drawable.u066, R.drawable.u067, R.drawable.u068, R.drawable.u069, R.drawable.u070, R.drawable.u071, R.drawable.u072, R.drawable.u073, R.drawable.u074, R.drawable.u075, R.drawable.u076, R.drawable.u077, R.drawable.u078, R.drawable.u079, R.drawable.u080, R.drawable.u081, R.drawable.u082, R.drawable.u083, R.drawable.u084, R.drawable.u085, R.drawable.u086, R.drawable.u087, R.drawable.u088, R.drawable.u089, R.drawable.u090, R.drawable.u091, R.drawable.u092, R.drawable.u093, R.drawable.u094, R.drawable.u095, R.drawable.u096, R.drawable.u097, R.drawable.u098, R.drawable.u099, R.drawable.u100, R.drawable.u101, R.drawable.u102, R.drawable.u103, R.drawable.u104, R.drawable.u105, R.drawable.u106, R.drawable.u107, R.drawable.u108, R.drawable.u109, R.drawable.u110, R.drawable.u111, R.drawable.u112, R.drawable.u113, R.drawable.u114, R.drawable.u115, R.drawable.u116, R.drawable.u117, R.drawable.u118, R.drawable.u119, R.drawable.u120, R.drawable.u121, R.drawable.u122, R.drawable.u123, R.drawable.u124, R.drawable.u125, R.drawable.u126, R.drawable.u127, R.drawable.u128, R.drawable.u129, R.drawable.u130, R.drawable.u131, R.drawable.u132, R.drawable.u133, R.drawable.u134, R.drawable.u135, R.drawable.u136, R.drawable.u137, R.drawable.u138, R.drawable.u139, R.drawable.u140, R.drawable.u141, R.drawable.u142, R.drawable.u143, R.drawable.u144, R.drawable.u145, R.drawable.u146, R.drawable.u147, R.drawable.u148, R.drawable.u149, R.drawable.u150, R.drawable.u151, R.drawable.u152, R.drawable.u153, R.drawable.u154, R.drawable.u155, R.drawable.u156, R.drawable.u157, R.drawable.u158, R.drawable.u159, R.drawable.u160, R.drawable.u161, R.drawable.u162, R.drawable.u163, R.drawable.u164, R.drawable.u165, R.drawable.u166, R.drawable.u167, R.drawable.u168, R.drawable.u169, R.drawable.u170, R.drawable.u171, R.drawable.u172, R.drawable.u173, R.drawable.u174, R.drawable.u175, R.drawable.u176, R.drawable.u177, R.drawable.u178, R.drawable.u179, R.drawable.u180, R.drawable.u181, R.drawable.u182, R.drawable.u183, R.drawable.u184, R.drawable.u185, R.drawable.u186, R.drawable.u187, R.drawable.u188, R.drawable.u189, R.drawable.u190, R.drawable.u191, R.drawable.u192, R.drawable.u193, R.drawable.u194, R.drawable.u195, R.drawable.u196, R.drawable.u197, R.drawable.u198, R.drawable.u199, R.drawable.u200, R.drawable.u201, R.drawable.u202, R.drawable.u203, R.drawable.u204, R.drawable.u205, R.drawable.u206, R.drawable.u207, R.drawable.u208, R.drawable.u209, R.drawable.u210, R.drawable.u211, R.drawable.u212, R.drawable.u213, R.drawable.u214, R.drawable.u215, R.drawable.u216, R.drawable.u217, R.drawable.u218, R.drawable.u219, R.drawable.u220, R.drawable.u221, R.drawable.u222, R.drawable.u223, R.drawable.u224, R.drawable.u225, R.drawable.u226, R.drawable.u227, R.drawable.u228, R.drawable.u229, R.drawable.u230, R.drawable.u231, R.drawable.u232, R.drawable.u233, R.drawable.u234, R.drawable.u235, R.drawable.u236, R.drawable.u237, R.drawable.u238, R.drawable.u239, R.drawable.u240, R.drawable.u241, R.drawable.u242, R.drawable.u243, R.drawable.u244, R.drawable.u245, R.drawable.u246, R.drawable.u247, R.drawable.u248, R.drawable.u249, R.drawable.u250, R.drawable.u251, R.drawable.u252, R.drawable.u253, R.drawable.u254, R.drawable.u255, R.drawable.u256, R.drawable.u257, R.drawable.u258, R.drawable.u259, R.drawable.u260, R.drawable.u261, R.drawable.u262, R.drawable.u263, R.drawable.u264, R.drawable.u265, R.drawable.u266, R.drawable.u267, R.drawable.u268, R.drawable.u269, R.drawable.u270, R.drawable.u271, R.drawable.u272, R.drawable.u273, R.drawable.u274, R.drawable.u275, R.drawable.u276, R.drawable.u277, R.drawable.u278, R.drawable.u279, R.drawable.u280, R.drawable.u281, R.drawable.u282, R.drawable.u283, R.drawable.u284, R.drawable.u285, R.drawable.u286};
            this.emj = new String[]{LoggingEvents.EXTRA_CALLING_APP_NAME, "😄", "😃", "😀", "😊", "😉", "😍", "😘", "😚", "😙", "😗", "😜", "😝", "😛", "😳", "😁", "😔", "😌", "😒", "😞", "😣", "😢", "😂", "😭", "😪", "😥", "😰", "😅", "😓", "😩", "😫", "😨", "😱", "😠", "😡", "😤", "😖", "😆", "😋", "😷", "😎", "😴", "😲", "😵", "😟", "😦", "😧", "😈", "👿", "😮", "😬", "😐", "😕", "😯", "😶", "😇", "😏", "😑", "😺", "😸", "😻", "😽", "😼", "🙀", "😿", "😹", "😾", "👹", "👺", "🙈", "🙉", "🙊", "👻", "💀", "👽", "👾", "👃", "👂", "👀", "👅", "👄", "👊", "👍", "👎", "👆", "👇", "👉", "👈", "👏", "👐", "💪", "🏃", "👨", "👧", "👸", "💆", "💇", "👬", "👭", "💅", "👑", "👒", "👟", "👡", "👠", "👞", "👕", "👗", "👖", "💼", "👜", "👓", "🎀", "💄", "💖", "💔", "💘", "💍", "💎", "👣", "🐥", "🐍", "🐢", "🐛", "🐝", "🐜", "🐞", "🐌", "🐚", "🐟", "🐳", "🐄", "🐏", "🐀", "🐆", "🐇", "🐎", "🐐", "🐓", "🐕", "🐂", "🐫", "🐈", "🐒", "💐", "🌸", "🌷", "🌹", "🌻", "🌺", "🍁", "🍄", "🌴", "🌳", "🌿", "🌼", "🌞", "🌝", "🌛", "🌙", "🌍", "☀", "⛅", "🌂", "🔥", "🌟", "🎁", "🎉", "📷", "📹", "🎤", "📞", "🎧", "📣", "📀", "💻", "📺", "📻", "🔈", "🔇", "🕞", "🔋", "🔓", "🔒", "🔑", "🔎", "💡", "🔦", "🔌", "🚪", "🚿", "🔧", "🔩", "🔗", "🔨", "💣", "🔫", "🔪", "💊", "💉", "💰", "💵", "💳", "📨", "📬", "📦", "📝", "📄", "📃", "📋", "📅", "📌", "📎", "📏", "📐", "📘", "📚", "📖", "🔬", "🔭", "📰", "🎨", "🎮", "🏆", "⚽", "🏁", "🏇", "🍼", "🍵", "🍹", "🍴", "🍕", "🍔", "🍟", "🍗", "🍝", "🍛", "🍚", "🍜", "🍲", "🍡", "🍳", "🍞", "🍩", "🍮", "🍦", "🍧", "🎂", "🍰", "🍪", "🍫", "🍬", "🍭", "🍯", "🍎", "🍊", "🍋", "🍒", "🍇", "🍉", "🍌", "🍐", "🍍", "🍓", "🍆", "🍅", "🌽", "🏡", "🏨", "🏫", "🏭", "⛲", "💧", "💺", "⛵", "🚀", "🚁", "🚄", "🚍", "🚘", "🚚", "🚔", "🚒", "🚑", "🚦", "⛽", "🚫"};
        }
    }

    void dism() {
        try {
            this.Al.dismiss();
        } catch (Exception e) {
        }
        try {
            this.Al2.dismiss();
        } catch (Exception e2) {
        }
        try {
            this.Al3.dismiss();
        } catch (Exception e3) {
        }
        try {
            this.Al4.dismiss();
        } catch (Exception e4) {
        }
    }

    public class ImageAdapter extends BaseAdapter {
        private Context mContext;

        @Override
        public int getCount() {
            return AlsarabIME.this.ms.length;
        }

        @Override
        public Object getItem(int position) {
            return Integer.valueOf(AlsarabIME.this.ms[position]);
        }

        @Override
        public long getItemId(int position) {
            return 0L;
        }

        public ImageAdapter(Context c) {
            this.mContext = c;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView = new ImageView(this.mContext);
            imageView.setImageResource(AlsarabIME.this.ms[position]);
            return imageView;
        }
    }

    private void checkReCorrectionOnStart() {
        InputConnection ic;
        if (this.mReCorrectionEnabled && isPredictionOn() && (ic = getCurrentInputConnection()) != null) {
            ExtractedTextRequest etr = new ExtractedTextRequest();
            etr.token = 0;
            ExtractedText et = ic.getExtractedText(etr, 0);
            if (et != null) {
                this.mLastSelectionStart = et.startOffset + et.selectionStart;
                this.mLastSelectionEnd = et.startOffset + et.selectionEnd;
                if (!TextUtils.isEmpty(et.text) && isCursorTouchingWord()) {
                    postUpdateOldSuggestions();
                }
            }
        }
    }

    @Override
    public void onFinishInput() {
        dismissClipChoice();
        cancelAutoType();
        super.onFinishInput();
        LatinImeLogger.commit();
        onAutoCompletionStateChanged(false);
        if (!this.mConfigurationChanging && this.mVoiceInput != null) {
            if (this.mAfterVoiceInput) {
                this.mVoiceInput.flushAllTextModificationCounters();
                this.mVoiceInput.logInputEnded();
            }
            this.mVoiceInput.flushLogs();
            this.mVoiceInput.cancel();
        }
        if (this.mCalibration.getInputView() != null) {
            this.mCalibration.getInputView().closing();
        }
        if (this.mAutoDictionary != null) {
            this.mAutoDictionary.flushPendingWrites();
        }
        if (this.mUserBigramDictionary != null) {
            this.mUserBigramDictionary.flushPendingWrites();
        }
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        dismissClipChoice();
        this.mHandler.removeMessages(0);
        this.mHandler.removeMessages(4);
        dism();
    }

    @Override
    public void onUpdateExtractedText(int token, ExtractedText text) {
        super.onUpdateExtractedText(token, text);
        InputConnection ic = getCurrentInputConnection();
        if (!this.mImmediatelyAfterVoiceInput && this.mAfterVoiceInput && ic != null && this.mHints.showPunctuationHintIfNecessary(ic)) {
            this.mVoiceInput.logPunctuationHintDisplayed();
        }
        this.mImmediatelyAfterVoiceInput = false;
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        if (DEBUG) {
            Log.i(TAG, "onUpdateSelection: oss=" + oldSelStart + ", ose=" + oldSelEnd + ", nss=" + newSelStart + ", nse=" + newSelEnd + ", cs=" + candidatesStart + ", ce=" + candidatesEnd);
        }
        if (this.mAfterVoiceInput) {
            this.mVoiceInput.setCursorPos(newSelEnd);
            this.mVoiceInput.setSelectionSpan(newSelEnd - newSelStart);
        }
        if (((this.mComposing.length() > 0 && this.mPredicting) || this.mVoiceInputHighlighted) && ((newSelStart != candidatesEnd || newSelEnd != candidatesEnd) && this.mLastSelectionStart != newSelStart)) {
            this.mComposing.setLength(0);
            this.mPredicting = false;
            postUpdateSuggestions();
            TextEntryState.reset();
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) {
                ic.finishComposingText();
            }
            this.mVoiceInputHighlighted = false;
        } else if (!this.mPredicting && !this.mJustAccepted) {
            switch (TextEntryState.getState()) {
                case ACCEPTED_DEFAULT:
                    TextEntryState.reset();
                case SPACE_AFTER_PICKED:
                    this.mJustAddedAutoSpace = false;
                    break;
            }
        }
        this.mJustAccepted = false;
        postUpdateShiftKeyState();
        this.mLastSelectionStart = newSelStart;
        this.mLastSelectionEnd = newSelEnd;
        if (this.mReCorrectionEnabled && this.mCalibration != null && this.mCalibration.getInputView() != null && this.mCalibration.getInputView().isShown() && isPredictionOn() && this.mJustRevertedSeparator == null) {
            if (candidatesStart == candidatesEnd || newSelStart != oldSelStart || TextEntryState.isCorrecting()) {
                if ((newSelStart < newSelEnd - 1 || !this.mPredicting) && !this.mVoiceInputHighlighted) {
                    if (isCursorTouchingWord() || this.mLastSelectionStart < this.mLastSelectionEnd) {
                        if (!this.scrolled) {
                            postUpdateOldSuggestions();
                            return;
                        } else {
                            if (oldSelStart < newSelStart) {
                                this.scrolled = false;
                                return;
                            }
                            return;
                        }
                    }
                    abortCorrection(false);
                    if (this.mCandidateView != null && !mSuggestPuncList.equals(this.mCandidateView.getSuggestions()) && !this.mCandidateView.isShowingAddToDictionaryHint()) {
                        setNextSuggestions();
                    }
                }
            }
        }
    }

    @Override
    public void onExtractedTextClicked() {
        if (!this.mReCorrectionEnabled || !isPredictionOn()) {
            super.onExtractedTextClicked();
        }
    }

    @Override
    public void onExtractedCursorMovement(int dx, int dy) {
        if (!this.mReCorrectionEnabled || !isPredictionOn()) {
            super.onExtractedCursorMovement(dx, dy);
        }
    }

    @Override
    public void hideWindow() {
        dismissClipChoice();
        LatinImeLogger.commit();
        onAutoCompletionStateChanged(false);
        if (TRACE) {
            Debug.stopMethodTracing();
        }
        if (this.mOptionsDialog != null && this.mOptionsDialog.isShowing()) {
            this.mOptionsDialog.dismiss();
            this.mOptionsDialog = null;
        }
        if (!this.mConfigurationChanging) {
            if (this.mAfterVoiceInput) {
                this.mVoiceInput.logInputEnded();
            }
            if (this.mVoiceWarningDialog != null && this.mVoiceWarningDialog.isShowing()) {
                this.mVoiceInput.logKeyboardWarningDialogDismissed();
                this.mVoiceWarningDialog.dismiss();
                this.mVoiceWarningDialog = null;
            }
            if (this.mRecognizing) {
                this.mVoiceInput.cancel();
            }
        }
        this.mWordToSuggestions.clear();
        this.mWordHistory.clear();
        super.hideWindow();
        TextEntryState.endSession();
    }

    @Override
    public void onDisplayCompletions(CompletionInfo[] completions) {
        if (DEBUG) {
            Log.i("foo", "Received completions:");
            int i = 0;
            while (true) {
                if (i >= (completions != null ? completions.length : 0)) {
                    break;
                }
                Log.i("foo", "  #" + i + ": " + completions[i]);
                i++;
            }
        }
        if (this.mCompletionOn) {
            this.mCompletions = completions;
            if (completions == null) {
                clearSuggestions();
                return;
            }
            List<CharSequence> stringList = new ArrayList<>();
            int i2 = 0;
            while (true) {
                if (i2 < (completions != null ? completions.length : 0)) {
                    CompletionInfo ci = completions[i2];
                    if (ci != null) {
                        stringList.add(ci.getText());
                    }
                    i2++;
                } else {
                    setSuggestions(stringList, true, true, true);
                    this.mBestWord = null;
                    setCandidatesViewShown(true);
                    return;
                }
            }
        }
    }

    private void setCandidatesViewShownInternal(boolean shown, boolean needsInputViewShown) {
        if (Build.VERSION.SDK_INT >= 21 && this.mInputWrapper != null && this.mCandidateViewContainer != null) {
            this.mCandidateViewContainer.setVisibility((shown && this.mCalibration.getInputView() != null) ? View.VISIBLE : View.GONE);
            return;
        }
        if (onEvaluateInputViewShown()) {
            super.setCandidatesViewShown(shown && this.mCalibration.getInputView() != null && (!needsInputViewShown || this.mCalibration.getInputView().isShown()));
        }
    }

    @Override
    public void setCandidatesViewShown(boolean shown) {
        setCandidatesViewShownInternal(shown, true);
    }

    @Override
    public void onComputeInsets(InputMethodService.Insets outInsets) {
        super.onComputeInsets(outInsets);
        if (!isFullscreenMode()) {
            outInsets.contentTopInsets = outInsets.visibleTopInsets;
        }
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        Configuration conf = this.mResources.getConfiguration();
        if (this.mNoFullScreenLandscape && conf.orientation == 2) {
            return false;
        }
        if (this.mFullScreenPortrait && conf.orientation == 1) {
            return true;
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float displayHeight = dm.heightPixels;
        float dimen = getResources().getDimension(R.dimen.max_height_for_fullscreen);
        if (displayHeight <= dimen) {
            return super.onEvaluateFullscreenMode();
        }
        return false;
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 4:
                if (event.getRepeatCount() == 0 && this.mCalibration.getInputView() != null) {
                    if (this.mCalibration.getInputView().handleBack()) {
                        return true;
                    }
                    if (this.mTutorial != null) {
                        this.mTutorial.close();
                        this.mTutorial = null;
                    }
                }
                return super.onKeyDown(keyCode, event);
            case LoggingEvents.VoiceIme.VOICE_INPUT_SETTING_ENABLED /* 19 */:
            case 20:
            case LoggingEvents.VoiceIme.IME_TEXT_ACCEPTED /* 21 */:
            case 22:
                if (this.mTutorial != null) {
                    return true;
                }
                return super.onKeyDown(keyCode, event);
            case 24:
                if (this.mUseVolumeKeyForLeftRight && isInputViewShown()) {
                    sendDownUpKeyEvents(21);
                    return true;
                }
                return super.onKeyDown(keyCode, event);
            case 25:
                if (this.mUseVolumeKeyForLeftRight && isInputViewShown()) {
                    sendDownUpKeyEvents(22);
                    return true;
                }
                return super.onKeyDown(keyCode, event);
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    @Override // android.inputmethodservice.InputMethodService, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 24:
            case 25:
                // Volume keys: swallow when they are used as left/right cursor keys.
                if (this.mUseVolumeKeyForLeftRight && isInputViewShown()) {
                    return true;
                }
                // fall through to the DPAD/shift handling below (as in the original)
            case 19:
            case 20:
            case 21:
            case 22:
                if (this.mTutorial != null) {
                    return true;
                }
                LatinKeyboardView inputView = this.mCalibration.getInputView();
                if (inputView != null && inputView.isShown() && inputView.isShifted()) {
                    KeyEvent shifted = new KeyEvent(event.getDownTime(), event.getEventTime(), event.getAction(), event.getKeyCode(), event.getRepeatCount(), event.getDeviceId(), event.getScanCode(), 65);
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) {
                        ic.sendKeyEvent(shifted);
                    }
                    return true;
                }
                break;
            default:
                break;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void revertVoiceInput() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.commitText(LoggingEvents.EXTRA_CALLING_APP_NAME, 1);
        }
        updateSuggestions();
        this.mVoiceInputHighlighted = false;
    }

    private void commitVoiceInput() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.finishComposingText();
        }
        updateSuggestions();
        this.mVoiceInputHighlighted = false;
    }

    public void reloadKeyboards() {
        if (this.mCalibration != null) {
            this.mCalibration.setLanguageSwitcher(this.mLanguageSwitcher);
            if (this.mCalibration.getInputView() != null && this.mCalibration.getKeyboardMode() != 0) {
                this.mCalibration.setVoiceMode(this.mEnableVoice && this.mEnableVoiceButton, this.mVoiceOnPrimary);
            }
            this.mCalibration.makeKeyboards(true, this.mLanguageSwitcher.getInputLayout());
        }
    }

    private void commitTyped(InputConnection inputConnection) {
        if (this.mPredicting) {
            this.mPredicting = false;
            if (this.mComposing.length() > 0) {
                if (inputConnection != null) {
                    inputConnection.commitText(this.mComposing, 1);
                }
                this.mCommittedLength = this.mComposing.length();
                TextEntryState.acceptedTyped(this.mComposing);
                addToDictionaries(this.mComposing, 1);
            }
            updateSuggestions();
        }
    }

    private void postUpdateShiftKeyState() {
        this.mHandler.removeMessages(2);
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(2), 300L);
    }

    public void updateShiftKeyState(EditorInfo attr) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && attr != null && this.mCalibration.isAlphabetMode()) {
            this.mCalibration.setShifted(this.mShiftKeyState.isMomentary() || this.mCapsLock || getCursorCapsMode(ic, attr) != 0);
        }
    }

    private int getCursorCapsMode(InputConnection ic, EditorInfo attr) {
        int caps = 0;
        EditorInfo ei = getCurrentInputEditorInfo();
        if (!ei.packageName.equals("com.android.email")) {
            if (this.mAutoCap && ei != null && ei.inputType != 0) {
                caps = ic.getCursorCapsMode(attr.inputType);
            }
            return caps;
        }
        ExtractedTextRequest etr = new ExtractedTextRequest();
        etr.token = 0;
        ExtractedText et = ic.getExtractedText(etr, 0);
        if (et == null) {
            return 0;
        }
        Integer a = Integer.valueOf(et.startOffset + et.selectionStart);
        Integer b = Integer.valueOf(et.startOffset + et.selectionEnd);
        if (a.intValue() > b.intValue()) {
            int tmp = a.intValue();
            a = b;
            Integer.valueOf(tmp);
        }
        Integer inputtype = Integer.valueOf(attr.inputType);
        return getCapsMode(et.text, a.intValue(), inputtype.intValue());
    }

    public static int getCapsMode(CharSequence cs, int off, int reqModes) {
        if (off < 0) {
            return 0;
        }
        if (cs.length() == 0) {
            return 1;
        }
        if (off > cs.length()) {
            return 0;
        }
        int mode = 0;
        if ((reqModes & 4096) != 0) {
            mode = 0 | 4096;
        }
        if ((reqModes & 24576) != 0) {
            int i = off;
            while (i > 0) {
                char c = cs.charAt(i - 1);
                if (c != '\"' && c != '\'' && Character.getType(c) != 21) {
                    break;
                }
                i--;
            }
            int j = i;
            while (j > 0) {
                char c2 = cs.charAt(j - 1);
                if (c2 != ' ' && c2 != '\t' && c2 != 194 && c2 != 160) {
                    break;
                }
                j--;
            }
            if (j == 0 || cs.charAt(j - 1) == '\n') {
                return mode | 8192;
            }
            if ((reqModes & 16384) == 0) {
                return i != j ? mode | 8192 : mode;
            }
            if (i != j) {
                while (j > 0) {
                    char c3 = cs.charAt(j - 1);
                    if (c3 != '\"' && c3 != '\'' && Character.getType(c3) != 22) {
                        break;
                    }
                    j--;
                }
                if (j > 0) {
                    char c4 = cs.charAt(j - 1);
                    if (c4 == KEYCODE_PERIOD || c4 == '?' || c4 == '!') {
                        if (c4 == KEYCODE_PERIOD) {
                            for (int k = j - 2; k >= 0; k--) {
                                char c5 = cs.charAt(k);
                                if (c5 != KEYCODE_PERIOD) {
                                    if (!Character.isLetter(c5)) {
                                        break;
                                    }
                                } else {
                                    return mode;
                                }
                            }
                        }
                        return mode | 16384;
                    }
                    return mode;
                }
                return mode;
            }
            return mode;
        }
        return mode;
    }

    private void swapPunctuationAndSpace() {
        CharSequence lastTwo;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && (lastTwo = ic.getTextBeforeCursor(2, 0)) != null && lastTwo.length() == 2 && isSpace(lastTwo.charAt(0)) && isSentenceSeparator(lastTwo.charAt(1))) {
            ic.beginBatchEdit();
            ic.deleteSurroundingText(2, 0);
            ic.commitText(String.valueOf(lastTwo.charAt(1)) + " ", 1);
            ic.endBatchEdit();
            updateShiftKeyState(getCurrentInputEditorInfo());
            this.mJustAddedAutoSpace = true;
        }
    }

    private void reswapPeriodAndSpace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            CharSequence lastThree = ic.getTextBeforeCursor(4, 0);
            if (lastThree != null && lastThree.length() == 4 && lastThree.charAt(0) != KEYCODE_PERIOD && lastThree.charAt(1) == KEYCODE_PERIOD && isSpace(lastThree.charAt(2)) && lastThree.charAt(3) == KEYCODE_PERIOD) {
                ic.beginBatchEdit();
                ic.deleteSurroundingText(3, 0);
                ic.commitText(" ..", 1);
                ic.endBatchEdit();
                updateShiftKeyState(getCurrentInputEditorInfo());
                return;
            }
            if (lastThree != null && lastThree.length() == 4 && lastThree.charAt(0) == KEYCODE_PERIOD && lastThree.charAt(1) == KEYCODE_PERIOD && isSpace(lastThree.charAt(2)) && lastThree.charAt(3) == KEYCODE_PERIOD) {
                ic.beginBatchEdit();
                ic.deleteSurroundingText(3, 0);
                ic.commitText("..", 1);
                ic.endBatchEdit();
                updateShiftKeyState(getCurrentInputEditorInfo());
            }
        }
    }

    private void doubleSpace() {
        InputConnection ic;
        CharSequence lastThree;
        if (this.mCorrectionMode != 0 && (ic = getCurrentInputConnection()) != null && (lastThree = ic.getTextBeforeCursor(3, 0)) != null && lastThree.length() == 3 && Character.isLetterOrDigit(lastThree.charAt(0)) && isSpace(lastThree.charAt(1)) && isSpace(lastThree.charAt(2))) {
            ic.beginBatchEdit();
            ic.deleteSurroundingText(2, 0);
            ic.commitText(". ", 1);
            ic.endBatchEdit();
            updateShiftKeyState(getCurrentInputEditorInfo());
            this.mJustAddedAutoSpace = true;
        }
    }

    private boolean isSpace(int c) {
        return c == 32 || c == 194 || c == 160;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes, int x, int y) {
        long when = SystemClock.uptimeMillis();
        switch (primaryCode) {
            case 1:
                po1();
                return;
            case 2:
                po2();
                return;
            case 3:
                cut();
                return;
            case 4:
                copy();
                return;
            case 5:
                paste();
                return;
            case 6:
                po3();
                return;
            case 7:
                po4();
                return;
            case 8:
                sall();
                return;
            case 9:
                nl();
                return;
            case 10:
            default:
                if (primaryCode != -5 || when > this.mLastKeyTime + 200) {
                    this.mDeleteCount = 0;
                }
                this.mLastKeyTime = when;
                boolean distinctMultiTouch = this.mCalibration.hasDistinctMultitouch();
                switch (primaryCode) {
                    case -108:
                        launchSettings();
                        break;
                    case -107:
                        toggleArrow(false);
                        break;
                    case -106:
                        toggleArrow(true);
                        break;
                    case -105:
                        toggleLanguage(false, false);
                        break;
                    case -104:
                        toggleLanguage(false, true);
                        break;
                    case -102:
                        startListening(false);
                        break;
                    case -101:
                        onOptionKeyLongPressed();
                        break;
                    case -100:
                        onOptionKeyPressed();
                        break;
                    case -12:
                        handleClose();
                        break;
                    case -11:
                        if (this.mCandidateView != null) {
                            this.mBestWord = null;
                            if (this.mCandidateView.getSuggestions().size() > 0) {
                                this.mCandidateView.moveToNextSuggestion();
                                if (!mSuggestPuncList.equals(this.mCandidateView.getSuggestions())) {
                                    this.mBestWord = this.mCandidateView.getSuggestions().get(this.mCandidateView.mCurrentRecommendedWord);
                                    this.scrolled = true;
                                    InputConnection ic = getCurrentInputConnection();
                                    if (ic != null && this.mBestWord != null) {
                                        ic.setComposingText(this.mBestWord, 1);
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                    case -10:
                        handleT9();
                        break;
                    case -9:
                        handleCharacter(x, keyCodes, true, x, y);
                        break;
                    case -5:
                        handleBackspace();
                        this.mDeleteCount++;
                        LatinImeLogger.logOnDelete();
                        break;
                    case -3:
                        if (!isShowingOptionDialog()) {
                            handleClose();
                            break;
                        }
                        break;
                    case -2:
                        if (!distinctMultiTouch) {
                            changeKeyboardMode(true);
                            break;
                        }
                        break;
                    case -1:
                        if (!distinctMultiTouch) {
                            handleShift();
                            break;
                        }
                        break;
                    case 9:
                        sendDownUpKeyEvents(61);
                        break;
                    case LoggingEvents.VoiceIme.VOICE_INPUT_SETTING_ENABLED /* 19 */:
                    case 20:
                    case LoggingEvents.VoiceIme.IME_TEXT_ACCEPTED /* 21 */:
                    case 22:
                        sendDownUpKeyEvents(primaryCode);
                        handleArrow(primaryCode);
                        break;
                    default:
                        if (primaryCode != 10) {
                            this.mJustAddedAutoSpace = false;
                        }
                        if (primaryCode == -13) {
                            primaryCode = 32;
                        }
                        ImeUtils.RingCharBuffer.getInstance().push((char) primaryCode, x, y);
                        LatinImeLogger.logOnInputChar();
                        if (isWordSeparator(primaryCode)) {
                            handleSeparator(primaryCode);
                        } else {
                            handleCharacter(primaryCode, keyCodes, false, x, y);
                        }
                        this.mJustRevertedSeparator = null;
                        break;
                }
                this.mCalibration.onKey(primaryCode);
                this.mEnteredText = null;
                return;
            case 11:
                clall();
                return;
        }
    }

    private void maybeRemovePreviousPeriod(CharSequence text) {
        CharSequence lastOne;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && (lastOne = ic.getTextBeforeCursor(1, 0)) != null && lastOne.length() == 1 && lastOne.charAt(0) == KEYCODE_PERIOD && text.charAt(0) == KEYCODE_PERIOD) {
            ic.deleteSurroundingText(1, 0);
        }
    }

    private void removeTrailingSpace() {
        CharSequence lastOne;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && (lastOne = ic.getTextBeforeCursor(1, 0)) != null && lastOne.length() == 1 && lastOne.charAt(0) == ' ') {
            ic.deleteSurroundingText(1, 0);
        }
    }

    public boolean addWordToDictionary(String word) {
        this.mUserDictionary.addWord(word, 128);
        postUpdateSuggestions();
        return true;
    }

    private boolean isAlphabet(int code) {
        return Character.isLetter(code);
    }

    private boolean isNumber(int code) {
        return Character.isDigit(code);
    }

    private void showInputMethodPicker() {
        ((InputMethodManager) getSystemService("input_method")).showInputMethodPicker();
    }

    private void onOptionKeyPressed() {
        if (!isShowingOptionDialog()) {
            if (ImeUtils.hasMultipleEnabledIMEs(this)) {
                showOptionsMenu();
            } else {
                launchSettings();
            }
        }
    }

    private void onOptionKeyLongPressed() {
        if (!isShowingOptionDialog()) {
            if (ImeUtils.hasMultipleEnabledIMEs(this)) {
                showInputMethodPicker();
            } else {
                launchSettings();
            }
        }
    }

    private boolean isShowingOptionDialog() {
        return this.mOptionsDialog != null && this.mOptionsDialog.isShowing();
    }

    @Override
    public void onText(CharSequence text) {
        if (this.mVoiceInputHighlighted) {
            commitVoiceInput();
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            abortCorrection(false);
            ic.beginBatchEdit();
            if (this.mPredicting) {
                commitTyped(ic);
            }
            maybeRemovePreviousPeriod(text);
            ic.commitText(text, 1);
            ic.endBatchEdit();
            updateShiftKeyState(getCurrentInputEditorInfo());
            this.mCalibration.onKey(0);
            this.mJustRevertedSeparator = null;
            this.mJustAddedAutoSpace = false;
            this.mEnteredText = text;
        }
    }

    @Override
    public void onCancel() {
        this.mCalibration.onCancelInput();
    }

    private void handleArrow(int primaryCode) {
    }

    private void handleBackspace() {
        if (this.mVoiceInputHighlighted) {
            this.mVoiceInput.incrementTextModificationDeleteCount(this.mVoiceResults.candidates.get(0).toString().length());
            revertVoiceInput();
            return;
        }
        boolean deleteChar = false;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.beginBatchEdit();
            if (this.mAfterVoiceInput && this.mVoiceInput.getCursorPos() > 0) {
                int deleteLen = this.mVoiceInput.getSelectionSpan() > 0 ? this.mVoiceInput.getSelectionSpan() : 1;
                this.mVoiceInput.incrementTextModificationDeleteCount(deleteLen);
            }
            if (this.mPredicting) {
                int length = this.mComposing.length();
                if (length > 0) {
                    this.mComposing.delete(length - 1, length);
                    this.mWord.deleteLast();
                    ic.setComposingText(this.mComposing, 1);
                    if (this.mComposing.length() == 0) {
                        this.mPredicting = false;
                    }
                    postUpdateSuggestions();
                } else {
                    ic.deleteSurroundingText(1, 0);
                }
            } else {
                deleteChar = true;
            }
            postUpdateShiftKeyState();
            TextEntryState.backspace();
            if (TextEntryState.getState() == TextEntryState.State.UNDO_COMMIT) {
                revertLastWord(deleteChar);
                ic.endBatchEdit();
                return;
            }
            if (this.mEnteredText != null && sameAsTextBeforeCursor(ic, this.mEnteredText)) {
                ic.deleteSurroundingText(this.mEnteredText.length(), 0);
            } else if (deleteChar) {
                if (this.mCandidateView != null && this.mCandidateView.dismissAddToDictionaryHint()) {
                    revertLastWord(deleteChar);
                } else {
                    ic.finishComposingText();
                    sendDownUpKeyEvents(67);
                    if (this.mDeleteCount > 20) {
                        sendDownUpKeyEvents(67);
                    }
                }
            }
            this.mJustRevertedSeparator = null;
            ic.endBatchEdit();
        }
    }

    private void resetShift() {
        handleShiftInternal(true);
    }

    private void handleShift() {
        handleShiftInternal(false);
    }

    private void handleShiftInternal(boolean forceNormal) {
        this.mHandler.removeMessages(2);
        Calibration switcher = this.mCalibration;
        LatinKeyboardView inputView = switcher.getInputView();
        if (switcher.isAlphabetMode()) {
            if (this.mCapsLock || forceNormal) {
                this.mCapsLock = false;
                switcher.setShifted(false);
                return;
            } else {
                if (inputView != null) {
                    if (inputView.isShifted()) {
                        this.mCapsLock = true;
                        switcher.setShiftLocked(true);
                        return;
                    } else {
                        switcher.setShifted(true);
                        return;
                    }
                }
                return;
            }
        }
        switcher.toggleShift();
    }

    private void handleToggleCapsLock() {
        this.mHandler.removeMessages(2);
        Calibration switcher = this.mCalibration;
        if (switcher.isAlphabetMode()) {
            if (this.mCapsLock) {
                this.mCapsLock = false;
                switcher.setShifted(false);
            } else {
                this.mCapsLock = true;
                switcher.setShiftLocked(true);
                postUpdateShiftKeyState();
            }
        }
    }

    private void handleT9() {
        LatinKeyboardView inputView = this.mCalibration.getInputView();
        boolean t9modeWas = T9Mode;
        T9Mode = ((LatinKeyboard) inputView.getKeyboard()).isT9on();
        if (t9modeWas && !T9Mode && this.mBestWord != null && this.mPredicting) {
            pickSuggestion(this.mBestWord, true);
        }
    }

    public static boolean isT9Mode() {
        return T9Mode && Calibration.isT9orCompatMode();
    }

    private void abortCorrection(boolean force) {
        if (force || TextEntryState.isCorrecting()) {
            getCurrentInputConnection().finishComposingText();
            clearSuggestions();
        }
    }

    private void handleCharacter(int primaryCode, int[] keyCodes, boolean rplacing, int x, int y) {
        int upperCaseCode;
        if (this.mVoiceInputHighlighted) {
            commitVoiceInput();
        }
        if (this.mAfterVoiceInput) {
            this.mVoiceInput.incrementTextModificationInsertCount(1);
        }
        if (this.mLastSelectionStart == this.mLastSelectionEnd && TextEntryState.isCorrecting()) {
            abortCorrection(false);
        }
        if ((isAlphabet(primaryCode) || isNumber(primaryCode)) && isPredictionOn() && !isCursorTouchingWord() && !this.mPredicting) {
            this.mPredicting = true;
            this.mComposing.setLength(0);
            saveWordInHistory(this.mBestWord);
            this.mWord.reset();
        }
        if (this.mCalibration.getInputView().isShifted()) {
            if (keyCodes != null && keyCodes[0] >= 0 && keyCodes[0] <= 1114111) {
                if (!rplacing) {
                    primaryCode = keyCodes[0];
                }
                if (this.mCalibration.isAlphabetMode() && Character.isLowerCase(primaryCode)) {
                    int upperCaseCode2 = Character.toUpperCase(primaryCode);
                    if (upperCaseCode2 != primaryCode) {
                        primaryCode = upperCaseCode2;
                    } else {
                        String upperCase = new String(new int[]{primaryCode}, 0, 1).toUpperCase();
                        onText(upperCase);
                        return;
                    }
                }
            } else {
                return;
            }
        }
        if (rplacing) {
            if (this.mPredicting) {
                if (this.mComposing.length() >= 1) {
                    if (Character.isUpperCase(this.mComposing.codePointAt(this.mComposing.length() - 1)) && (upperCaseCode = Character.toUpperCase(primaryCode)) != primaryCode) {
                        primaryCode = upperCaseCode;
                    }
                    this.mComposing.setCharAt(this.mComposing.length() - 1, (char) primaryCode);
                }
                this.mWord.deleteLast();
                postUpdateShiftKeyState();
            } else {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.deleteSurroundingText(1, 0);
                }
            }
        }
        if (this.mPredicting) {
            if (this.mCalibration.getInputView().isShifted() && this.mCalibration.isAlphabetMode() && this.mComposing.length() == 0) {
                this.mWord.setFirstCharCapitalized(true);
            }
            if (!rplacing) {
                this.mComposing.append((char) primaryCode);
            }
            this.mWord.add(primaryCode, keyCodes, x, y);
            InputConnection ic2 = getCurrentInputConnection();
            if (ic2 != null) {
                if (this.mWord.size() == 1) {
                    this.mWord.setAutoCapitalized(getCursorCapsMode(ic2, getCurrentInputEditorInfo()) != 0);
                }
                ic2.setComposingText(this.mComposing, 1);
            }
            postUpdateSuggestions();
        } else {
            sendKeyChar((char) primaryCode);
        }
        updateShiftKeyState(getCurrentInputEditorInfo());
        if (PERF_DEBUG) {
            measureCps();
        }
        TextEntryState.typedCharacter((char) primaryCode, isWordSeparator(primaryCode));
    }

    private void handleSeparator(int primaryCode) {
        if (this.mVoiceInputHighlighted) {
            commitVoiceInput();
        }
        if (this.mAfterVoiceInput) {
            this.mVoiceInput.incrementTextModificationInsertPunctuationCount(1);
        }
        if (this.mCandidateView != null && this.mCandidateView.dismissAddToDictionaryHint()) {
            postUpdateSuggestions();
        }
        String iso3lang = this.mLanguageSwitcher.getInputLocale().getISO3Language();
        if (primaryCode < 256 && iso3lang.equals("heb")) {
            primaryCode = AndroidCharacter.getMirror((char) primaryCode);
        }
        boolean pickedDefault = false;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.beginBatchEdit();
            abortCorrection(false);
        }
        if (this.mPredicting) {
            if ((this.mAutoCorrectOn || isT9Mode()) && ((primaryCode != 39 || primaryCode != 34) && (this.mJustRevertedSeparator == null || this.mJustRevertedSeparator.length() == 0 || this.mJustRevertedSeparator.charAt(0) != primaryCode || Calibration.isT9orCompatMode()))) {
                pickedDefault = pickDefaultSuggestion();
                if (!this.mFieldUrlOrWeb && !isWordURLorEmail() && this.mAutoSpaceAfterPunc && pickedDefault && (primaryCode == KEYCODE_PERIOD || primaryCode == 39 || primaryCode == 44 || primaryCode == 41 || primaryCode == 63 || primaryCode == 33)) {
                    sendSpace();
                }
                if (primaryCode == 32) {
                    this.mJustAddedAutoSpace = true;
                }
            } else {
                commitTyped(ic);
            }
        }
        if (this.mJustAddedAutoSpace && primaryCode == 10) {
            removeTrailingSpace();
            this.mJustAddedAutoSpace = false;
        }
        sendKeyChar((char) primaryCode);
        if (TextEntryState.getState() == TextEntryState.State.PUNCTUATION_AFTER_ACCEPTED && primaryCode == KEYCODE_PERIOD) {
            reswapPeriodAndSpace();
        }
        TextEntryState.typedCharacter((char) primaryCode, true);
        if (TextEntryState.getState() == TextEntryState.State.PUNCTUATION_AFTER_ACCEPTED && primaryCode != 10) {
            swapPunctuationAndSpace();
        } else if (isPredictionOn() && primaryCode == 32 && this.mDoubleSpaceToPeriod) {
            doubleSpace();
        }
        if (pickedDefault) {
            TextEntryState.backToAcceptedDefault(this.mWord.getTypedWord());
        }
        updateShiftKeyState(getCurrentInputEditorInfo());
        if (ic != null) {
            ic.endBatchEdit();
        }
    }

    private void handleClose() {
        LatinKeyboardView inputView;
        commitTyped(getCurrentInputConnection());
        if (this.mRecognizing) {
            this.mVoiceInput.cancel();
        }
        requestHideSelf(0);
        if (this.mCalibration != null && (inputView = this.mCalibration.getInputView()) != null) {
            inputView.closing();
        }
        TextEntryState.endSession();
    }

    private void saveWordInHistory(CharSequence result) {
        if (this.mWord.size() <= 1) {
            this.mWord.reset();
        } else if (!TextUtils.isEmpty(result)) {
            String resultCopy = result.toString();
            TypedWordAlternatives entry = new TypedWordAlternatives(resultCopy, new WordComposer(this.mWord));
            this.mWordHistory.add(entry);
        }
    }

    public void postUpdateSuggestions() {
        this.mHandler.removeMessages(0);
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(0), 100L);
    }

    private void postUpdateOldSuggestions() {
        this.mHandler.removeMessages(4);
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(4), 300L);
    }

    private boolean isPredictionOn() {
        return this.mPredictionOn;
    }

    private boolean isCandidateStripVisible() {
        return isPredictionOn() && this.mShowSuggestions;
    }

    @Override
    public void onCancelVoice() {
        if (this.mRecognizing) {
            switchToKeyboardView();
        }
    }

    private void switchToKeyboardView() {
        this.mHandler.post(new Runnable() {
            @Override
            public void run() {
                AlsarabIME.this.mRecognizing = false;
                View v = AlsarabIME.this.mCalibration.getInputView();
                if (v != null) {
                    ViewParent p = v.getParent();
                    if (p != null && (p instanceof ViewGroup)) {
                        ((ViewGroup) p).removeView(v);
                    }
                    AlsarabIME.this.setInputView(v);
                }
                AlsarabIME.this.setCandidatesViewShown(true);
                AlsarabIME.this.updateInputViewShown();
                AlsarabIME.this.postUpdateSuggestions();
            }
        });
    }

    public void switchToRecognitionStatusView(final Configuration configuration) {
        this.mHandler.post(new Runnable() {
            @Override
            public void run() {
                AlsarabIME.this.setCandidatesViewShown(false);
                AlsarabIME.this.mRecognizing = true;
                AlsarabIME.this.mVoiceInput.newView();
                View v = AlsarabIME.this.mVoiceInput.getView();
                ViewParent p = v.getParent();
                if (p != null && (p instanceof ViewGroup)) {
                    ((ViewGroup) p).removeView(v);
                }
                View keyboardView = AlsarabIME.this.mCalibration.getInputView();
                if (keyboardView != null) {
                    View popupLayout = v.findViewById(R.id.popup_layout);
                    int displayHeight = AlsarabIME.this.getResources().getDisplayMetrics().heightPixels;
                    int currentHeight = popupLayout.getLayoutParams().height;
                    int keyboardHeight = keyboardView.getHeight();
                    if (AlsarabIME.this.mMinimumVoiceRecognitionViewHeightPixel > keyboardHeight || AlsarabIME.this.mMinimumVoiceRecognitionViewHeightPixel > currentHeight) {
                        popupLayout.getLayoutParams().height = AlsarabIME.this.mMinimumVoiceRecognitionViewHeightPixel;
                    } else if (keyboardHeight > currentHeight || keyboardHeight > displayHeight / 6) {
                        popupLayout.getLayoutParams().height = keyboardHeight;
                    }
                }
                AlsarabIME.this.setInputView(v);
                AlsarabIME.this.updateInputViewShown();
                if (configuration != null) {
                    AlsarabIME.this.mVoiceInput.onConfigurationChanged();
                }
            }
        });
    }

    private void startListening(boolean swipe) {
        if (!this.mHasUsedVoiceInput || (!this.mLocaleSupportedForVoiceInput && !this.mHasUsedVoiceInputUnsupportedLocale)) {
            showVoiceWarningDialog(swipe);
            return;
        }
        launchVoice(swipe);
    }

    /** Uses the system speech screen (Google) when the device has it, otherwise the keyboard own listening panel; never both. */
    private void launchVoice(boolean swipe) {
        if (this.mVoiceRecognitionTrigger != null && this.mVoiceRecognitionTrigger.isInstalled()) {
            if (!this.mHasUsedVoiceInput) {
                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
                editor.putBoolean(PREF_HAS_USED_VOICE_INPUT, true);
                SharedPreferencesCompat.apply(editor);
                this.mHasUsedVoiceInput = true;
            }
            if (!this.mLocaleSupportedForVoiceInput && !this.mHasUsedVoiceInputUnsupportedLocale) {
                SharedPreferences.Editor editor2 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                editor2.putBoolean(PREF_HAS_USED_VOICE_INPUT_UNSUPPORTED_LOCALE, true);
                SharedPreferencesCompat.apply(editor2);
                this.mHasUsedVoiceInputUnsupportedLocale = true;
            }
            this.mVoiceRecognitionTrigger.startVoiceRecognition(this.mLanguageSwitcher.getInputLanguage());
            return;
        }
        reallyStartListening(swipe);
    }

    public void reallyStartListening(boolean swipe) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.RECORD_AUDIO") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            PermissionActivity.request(this, "android.permission.RECORD_AUDIO");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            android.widget.Toast.makeText(this, R.string.voice_not_available, android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        if (!this.mHasUsedVoiceInput) {
            SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
            editor.putBoolean(PREF_HAS_USED_VOICE_INPUT, true);
            SharedPreferencesCompat.apply(editor);
            this.mHasUsedVoiceInput = true;
        }
        if (!this.mLocaleSupportedForVoiceInput && !this.mHasUsedVoiceInputUnsupportedLocale) {
            SharedPreferences.Editor editor2 = PreferenceManager.getDefaultSharedPreferences(this).edit();
            editor2.putBoolean(PREF_HAS_USED_VOICE_INPUT_UNSUPPORTED_LOCALE, true);
            SharedPreferencesCompat.apply(editor2);
            this.mHasUsedVoiceInputUnsupportedLocale = true;
        }
        clearSuggestions();
        FieldContext context2 = new FieldContext(getCurrentInputConnection(), getCurrentInputEditorInfo(), this.mLanguageSwitcher.getInputLanguage(), this.mLanguageSwitcher.getEnabledLanguages());
        this.mVoiceInput.startListening(context2, swipe);
        switchToRecognitionStatusView(null);
    }

    private void showVoiceWarningDialog(final boolean swipe) {
        float dp = getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * dp);
        box.setPadding(pad, pad, pad, (int) (8 * dp));
        android.graphics.drawable.GradientDrawable card = new android.graphics.drawable.GradientDrawable();
        card.setColor(0xfff7f7f7);
        card.setCornerRadius(20.0f * dp);
        box.setBackground(card);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_mic_dialog);
        icon.setColorFilter(0xff111111);
        header.addView(icon, new LinearLayout.LayoutParams((int) (28 * dp), (int) (28 * dp)));
        android.widget.TextView title = new android.widget.TextView(this);
        title.setText(R.string.voice_warning_title);
        title.setTextColor(0xff111111);
        title.setTextSize(20);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setPadding((int) (12 * dp), 0, (int) (12 * dp), 0);
        header.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String message;
        if (this.mLocaleSupportedForVoiceInput) {
            message = getString(R.string.voice_warning_may_not_understand) + "\n\n" + getString(R.string.voice_warning_how_to_turn_off);
        } else {
            message = getString(R.string.voice_warning_locale_not_supported) + "\n\n" + getString(R.string.voice_warning_may_not_understand) + "\n\n" + getString(R.string.voice_warning_how_to_turn_off);
        }
        android.widget.TextView body = new android.widget.TextView(this);
        body.setText(message);
        body.setTextColor(0xff2b2b2b);
        body.setTextSize(15);
        body.setLineSpacing(0, 1.25f);
        body.setPadding(0, (int) (16 * dp), 0, (int) (12 * dp));
        box.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AlertDialog[] holder = new AlertDialog[1];
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(android.view.Gravity.END);
        android.widget.TextView cancel = new android.widget.TextView(this);
        cancel.setText(android.R.string.cancel);
        cancel.setTextColor(0xff555555);
        cancel.setTextSize(16);
        cancel.setPadding((int) (18 * dp), (int) (12 * dp), (int) (18 * dp), (int) (12 * dp));
        cancel.setClickable(true);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder[0].dismiss();
                AlsarabIME.this.mVoiceInput.logKeyboardWarningDialogCancel();
            }
        });
        android.widget.TextView ok = new android.widget.TextView(this);
        ok.setText(android.R.string.ok);
        ok.setTextColor(0xff1a5fd0);
        ok.setTextSize(16);
        ok.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        ok.setPadding((int) (18 * dp), (int) (12 * dp), (int) (18 * dp), (int) (12 * dp));
        ok.setClickable(true);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder[0].dismiss();
                AlsarabIME.this.mVoiceInput.logKeyboardWarningDialogOk();
                AlsarabIME.this.launchVoice(swipe);
            }
        });
        buttons.addView(cancel);
        buttons.addView(ok);
        box.addView(buttons, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setView(box);
        this.mVoiceWarningDialog = builder.create();
        holder[0] = this.mVoiceWarningDialog;
        Window window = this.mVoiceWarningDialog.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1003;
        window.setAttributes(lp);
        window.addFlags(131072);
        window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        this.mVoiceInput.logKeyboardWarningDialogShown();
        this.mVoiceWarningDialog.show();
    }

    @Override
    public void onVoiceResults(List<String> candidates, Map<String, List<CharSequence>> alternatives) {
        if (this.mRecognizing) {
            this.mVoiceResults.candidates = candidates;
            this.mVoiceResults.alternatives = alternatives;
            this.mHandler.sendMessage(this.mHandler.obtainMessage(3));
        }
    }

    public void handleVoiceResults() {
        this.mAfterVoiceInput = true;
        this.mImmediatelyAfterVoiceInput = true;
        InputConnection ic = getCurrentInputConnection();
        if (!isFullscreenMode() && ic != null) {
            ExtractedTextRequest req = new ExtractedTextRequest();
            ic.getExtractedText(req, 1);
        }
        vibrate();
        switchToKeyboardView();
        List<CharSequence> nBest = new ArrayList<>();
        boolean capitalizeFirstWord = preferCapitalization() || (this.mCalibration.isAlphabetMode() && this.mCalibration.getInputView().isShifted());
        for (String c : this.mVoiceResults.candidates) {
            if (capitalizeFirstWord) {
                c = String.valueOf(Character.toUpperCase(c.charAt(0))) + c.substring(1, c.length());
            }
            nBest.add(c);
        }
        if (nBest.size() != 0) {
            CharSequence[] cs = (CharSequence[]) nBest.toArray(new CharSequence[nBest.size()]);
            if (this.mBestVoiceCohice) {
                String bestResult = nBest.get(0).toString();
                this.mVoiceInput.logVoiceInputDelivered(bestResult.length());
                this.mHints.registerVoiceResult(bestResult);
                if (ic != null) {
                    ic.beginBatchEdit();
                }
                commitTyped(ic);
                EditingUtil.appendText(ic, bestResult);
                if (ic != null) {
                    ic.endBatchEdit();
                }
                this.mVoiceInputHighlighted = true;
                this.mWordToSuggestions.putAll(this.mVoiceResults.alternatives);
                return;
            }
            createResultDialog(cs);
        }
    }

    private void clearSuggestions() {
        setSuggestions(null, false, false, false);
    }

    private void setSuggestions(List<CharSequence> suggestions, boolean completions, boolean typedWordValid, boolean haveMinimalSuggestion) {
        if (this.mIsShowingHint) {
            setCandidatesView(this.mCandidateViewContainer);
            this.mIsShowingHint = false;
        }
        if (this.mCandidateView != null) {
            this.mCandidateView.setSuggestions(suggestions, completions, typedWordValid, haveMinimalSuggestion);
        }
    }

    public void updateSuggestions() {
        LatinKeyboardView inputView = this.mCalibration.getInputView();
        ((LatinKeyboard) inputView.getKeyboard()).setPreferredLetters(null);
        if ((this.mSuggest != null && isPredictionOn()) || this.mVoiceInputHighlighted) {
            if (!this.mPredicting) {
                setNextSuggestions();
            } else {
                showSuggestions(this.mWord);
            }
        }
    }

    public List<CharSequence> getTypedSuggestions(WordComposer word) {
        List<CharSequence> stringList = this.mSuggest.getSuggestions(this.mCalibration.getInputView(), word, false, null, this.mCalibration.getKeyboard().getProximityInfo());
        return stringList;
    }

    private void showCorrections(WordAlternatives alternatives) {
        List<CharSequence> stringList = alternatives.getAlternatives();
        ((LatinKeyboard) this.mCalibration.getInputView().getKeyboard()).setPreferredLetters(null);
        showSuggestions(stringList, alternatives.getOriginalWord(), false, false);
    }

    private void showSuggestions(WordComposer word) {
        CharSequence prevWord = EditingUtil.getPreviousWord(getCurrentInputConnection(), this.mWordSeparators);
        List<CharSequence> stringList = this.mSuggest.getSuggestions(this.mCalibration.getInputView(), word, false, prevWord, this.mCalibration.getKeyboard().getProximityInfo());
        int[] nextLettersFrequencies = this.mSuggest.getNextLettersFrequencies();
        ((LatinKeyboard) this.mCalibration.getInputView().getKeyboard()).setPreferredLetters(nextLettersFrequencies);
        boolean correctionAvailable = !this.mInputTypeNoAutoCorrect && this.mSuggest.hasMinimalCorrection();
        CharSequence typedWord = word.getTypedWord();
        boolean typedWordValid = !isT9Mode() && (this.mSuggest.isValidWord(typedWord) || (preferCapitalization() && this.mSuggest.isValidWord(typedWord.toString().toLowerCase())));
        if (this.mCorrectionMode == 2 || this.mCorrectionMode == 3 || !isT9Mode()) {
            correctionAvailable |= typedWordValid;
        }
        if (!isT9Mode()) {
            correctionAvailable &= !word.isMostlyCaps();
        }
        boolean correctionAvailable2 = correctionAvailable & (!TextEntryState.isCorrecting());
        if (typedWord.length() > 0) {
            correctionAvailable2 &= Character.isDigit(typedWord.toString().charAt(0)) ? false : true;
        }
        if (this.mSuggest.hasAutoText()) {
            correctionAvailable2 = true;
            typedWordValid = false;
        }
        showSuggestions(stringList, typedWord, typedWordValid, correctionAvailable2);
    }

    private void showSuggestions(List<CharSequence> stringList, CharSequence typedWord, boolean typedWordValid, boolean correctionAvailable) {
        InputConnection ic;
        setSuggestions(stringList, false, typedWordValid, correctionAvailable);
        if (stringList.size() > 0) {
            if (correctionAvailable && !typedWordValid && stringList.size() > 1) {
                this.mBestWord = stringList.get(1);
                if (isT9Mode() && (ic = getCurrentInputConnection()) != null && this.mBestWord != null) {
                    ic.setComposingText(this.mBestWord.subSequence(0, Math.min(this.mComposing.length(), this.mBestWord.length())), 1);
                }
            } else {
                this.mBestWord = typedWord;
            }
        } else {
            this.mBestWord = null;
        }
        setCandidatesViewShown(isCandidateStripVisible() || this.mCompletionOn);
    }

    private boolean pickDefaultSuggestion() {
        if (this.mHandler.hasMessages(0)) {
            this.mHandler.removeMessages(0);
            updateSuggestions();
        }
        if (this.mBestWord == null || this.mBestWord.length() <= 0) {
            return false;
        }
        TextEntryState.acceptedDefault(this.mWord.getTypedWord(), this.mBestWord);
        this.mJustAccepted = true;
        pickSuggestion(this.mBestWord, false);
        addToDictionaries(this.mBestWord, 1);
        return true;
    }

    public void pickSuggestionManually(int index, CharSequence suggestion) {
        List<CharSequence> suggestions = this.mCandidateView.getSuggestions();
        if (this.mAfterVoiceInput && this.mShowingVoiceSuggestions) {
            this.mVoiceInput.flushAllTextModificationCounters();
            this.mVoiceInput.logTextModifiedByChooseSuggestion(suggestion.toString(), index, this.mWordSeparators, getCurrentInputConnection(), getCurrentInputEditorInfo());
        }
        boolean correcting = TextEntryState.isCorrecting() || isT9Mode();
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.beginBatchEdit();
        }
        if (this.mCompletionOn && this.mCompletions != null && index >= 0 && index < this.mCompletions.length) {
            CompletionInfo ci = this.mCompletions[index];
            if (ic != null) {
                ic.commitCompletion(ci);
            }
            this.mCommittedLength = suggestion.length();
            if (this.mCandidateView != null) {
                this.mCandidateView.clear();
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
            if (ic != null) {
                ic.endBatchEdit();
                return;
            }
            return;
        }
        if (suggestion.length() == 1 && (isWordSeparator(suggestion.charAt(0)) || isSuggestedPunctuation(suggestion.charAt(0)))) {
            LatinImeLogger.logOnManualSuggestion(LoggingEvents.EXTRA_CALLING_APP_NAME, suggestion.toString(), index, suggestions);
            char primaryCode = suggestion.charAt(0);
            onKey(primaryCode, new int[]{primaryCode}, -1, -1);
            if (ic != null) {
                ic.endBatchEdit();
                return;
            }
            return;
        }
        this.mJustAccepted = true;
        pickSuggestion(suggestion, correcting);
        if (index == 0) {
            addToDictionaries(suggestion, 3);
        } else {
            addToBigramDictionary(suggestion, 1);
        }
        LatinImeLogger.logOnManualSuggestion(this.mComposing.toString(), suggestion.toString(), index, suggestions);
        TextEntryState.acceptedSuggestion(this.mComposing.toString(), suggestion);
        if (!this.mFieldUrlOrWeb && !isWordURLorEmail() && this.mAutoSpaceAfterPunc && (!correcting || isT9Mode())) {
            sendSpace();
            this.mJustAddedAutoSpace = true;
        }
        boolean showingAddToDictionaryHint = index == 0 && this.mCorrectionMode > 0 && !this.mSuggest.isValidWord(suggestion) && !this.mSuggest.isValidWord(suggestion.toString().toLowerCase());
        if (!correcting) {
            TextEntryState.typedCharacter(' ', true);
            setNextSuggestions();
        } else if (!showingAddToDictionaryHint) {
            clearSuggestions();
            postUpdateOldSuggestions();
        }
        if (showingAddToDictionaryHint) {
            this.mCandidateView.showAddToDictionaryHint(suggestion);
        }
        if (ic != null) {
            ic.endBatchEdit();
        }
    }

    private boolean isWordURLorEmail() {
        String wordAtCursor = EditingUtil.getWordAtCursor(getCurrentInputConnection(), "\t\n ");
        if (wordAtCursor == null) {
            return false;
        }
        int length = wordAtCursor.length();
        for (int i = 0; i < length; i++) {
            if (Character.isLetter(wordAtCursor.charAt(i))) {
                return wordAtCursor.contains("@") || wordAtCursor.toLowerCase().contains("www") || wordAtCursor.toLowerCase().contains("http");
            }
        }
        return true;
    }

    private void rememberReplacedWord(CharSequence suggestion) {
        if (this.mShowingVoiceSuggestions) {
            String wordToBeReplaced = EditingUtil.getWordAtCursor(getCurrentInputConnection(), this.mWordSeparators);
            if (!this.mWordToSuggestions.containsKey(wordToBeReplaced)) {
                wordToBeReplaced = wordToBeReplaced.toLowerCase();
            }
            if (this.mWordToSuggestions.containsKey(wordToBeReplaced)) {
                List<CharSequence> suggestions = this.mWordToSuggestions.get(wordToBeReplaced);
                if (suggestions.contains(suggestion)) {
                    suggestions.remove(suggestion);
                }
                suggestions.add(wordToBeReplaced);
                this.mWordToSuggestions.remove(wordToBeReplaced);
                this.mWordToSuggestions.put(suggestion.toString(), suggestions);
            }
        }
    }

    private void pickSuggestion(CharSequence suggestion, boolean correcting) {
        this.mPredicting = false;
        LatinKeyboardView inputView = this.mCalibration.getInputView();
        if (this.mCapsLock) {
            suggestion = suggestion.toString().toUpperCase();
        } else if (preferCapitalization() || (this.mCalibration.isAlphabetMode() && inputView.isShifted())) {
            suggestion = String.valueOf(suggestion.toString().toUpperCase().charAt(0)) + suggestion.subSequence(1, suggestion.length()).toString();
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            rememberReplacedWord(suggestion);
            if (correcting) {
                EditingUtil.deleteWordAtCursor(ic, this.mWordSeparators);
            }
            List<CharSequence> suggestedWords = this.mCandidateView.getSuggestions();
            ic.commitText(SuggestionSpanUtils.getTextWithSuggestionSpan(this, suggestion, suggestedWords), 1);
        }
        saveWordInHistory(suggestion);
        this.mCommittedLength = suggestion.length();
        ((LatinKeyboard) inputView.getKeyboard()).setPreferredLetters(null);
        if (!correcting) {
            setNextSuggestions();
        }
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    private boolean applyVoiceAlternatives(EditingUtil.SelectedWord touching) {
        String selectedWord = touching.mWord.toString().trim();
        if (!this.mWordToSuggestions.containsKey(selectedWord)) {
            selectedWord = selectedWord.toLowerCase();
        }
        if (!this.mWordToSuggestions.containsKey(selectedWord)) {
            return false;
        }
        this.mShowingVoiceSuggestions = true;
        List<CharSequence> suggestions = this.mWordToSuggestions.get(selectedWord);
        if (Character.isUpperCase(touching.mWord.charAt(0))) {
            for (int i = 0; i < suggestions.size(); i++) {
                String origSugg = (String) suggestions.get(i);
                String capsSugg = String.valueOf(origSugg.toUpperCase().charAt(0)) + origSugg.subSequence(1, origSugg.length()).toString();
                suggestions.set(i, capsSugg);
            }
        }
        setSuggestions(suggestions, false, true, true);
        setCandidatesViewShown(true);
        return true;
    }

    private boolean applyTypedAlternatives(EditingUtil.SelectedWord touching) {
        WordComposer foundWord = null;
        WordAlternatives alternatives = null;
        Iterator<WordAlternatives> it = this.mWordHistory.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            WordAlternatives entry = it.next();
            if (TextUtils.equals(entry.getChosenWord(), touching.mWord)) {
                if (entry instanceof TypedWordAlternatives) {
                    foundWord = ((TypedWordAlternatives) entry).word;
                }
                alternatives = entry;
            }
        }
        if (foundWord == null && (this.mSuggest.isValidWord(touching.mWord) || this.mSuggest.isValidWord(touching.mWord.toString().toLowerCase()))) {
            foundWord = new WordComposer();
            for (int i = 0; i < touching.mWord.length(); i++) {
                foundWord.add(touching.mWord.charAt(i), new int[]{touching.mWord.charAt(i)}, -1, -1);
            }
            foundWord.setFirstCharCapitalized(Character.isUpperCase(touching.mWord.charAt(0)));
        }
        if (foundWord == null && alternatives == null) {
            return false;
        }
        if (alternatives == null) {
            alternatives = new TypedWordAlternatives(touching.mWord, foundWord);
        }
        showCorrections(alternatives);
        if (foundWord != null) {
            this.mWord = new WordComposer(foundWord);
        } else {
            this.mWord.reset();
        }
        return true;
    }

    public void setOldSuggestions() {
        InputConnection ic;
        this.mShowingVoiceSuggestions = false;
        if ((this.mCandidateView == null || !this.mCandidateView.isShowingAddToDictionaryHint()) && (ic = getCurrentInputConnection()) != null) {
            if (!this.mPredicting) {
                EditingUtil.SelectedWord touching = EditingUtil.getWordAtCursorOrSelection(ic, this.mLastSelectionStart, this.mLastSelectionEnd, this.mWordSeparators);
                if (touching != null && touching.mWord.length() > 1) {
                    ic.beginBatchEdit();
                    if (!applyVoiceAlternatives(touching) && !applyTypedAlternatives(touching)) {
                        abortCorrection(true);
                    } else {
                        TextEntryState.selectedForCorrection();
                        EditingUtil.underlineWord(ic, touching);
                    }
                    ic.endBatchEdit();
                    return;
                }
                abortCorrection(true);
                setNextSuggestions();
                return;
            }
            abortCorrection(true);
        }
    }

    private void setNextSuggestions() {
        setSuggestions(mSuggestPuncList, false, false, false);
    }

    private void addToDictionaries(CharSequence suggestion, int frequencyDelta) {
        checkAddToDictionary(suggestion, frequencyDelta, false);
    }

    private void addToBigramDictionary(CharSequence suggestion, int frequencyDelta) {
        checkAddToDictionary(suggestion, frequencyDelta, true);
    }

    private void checkAddToDictionary(CharSequence suggestion, int frequencyDelta, boolean addToBigramDictionary) {
        if (suggestion != null && suggestion.length() >= 1) {
            if ((this.mCorrectionMode == 2 || this.mCorrectionMode == 3) && suggestion != null) {
                if ((!addToBigramDictionary && this.mAutoDictionary.isValidWord(suggestion)) || (!this.mSuggest.isValidWord(suggestion.toString()) && !this.mSuggest.isValidWord(suggestion.toString().toLowerCase()))) {
                    this.mAutoDictionary.addWord(suggestion.toString(), frequencyDelta);
                }
                if (this.mUserBigramDictionary != null) {
                    CharSequence prevWord = EditingUtil.getPreviousWord(getCurrentInputConnection(), this.mSentenceSeparators);
                    if (!TextUtils.isEmpty(prevWord)) {
                        this.mUserBigramDictionary.addBigrams(prevWord.toString(), suggestion.toString());
                    }
                }
            }
        }
    }

    private boolean isCursorTouchingWord() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return false;
        }
        CharSequence toLeft = ic.getTextBeforeCursor(1, 0);
        CharSequence toRight = ic.getTextAfterCursor(1, 0);
        if (TextUtils.isEmpty(toLeft) || isWordSeparator(toLeft.charAt(0)) || isSuggestedPunctuation(toLeft.charAt(0))) {
            return (TextUtils.isEmpty(toRight) || isWordSeparator(toRight.charAt(0)) || isSuggestedPunctuation(toRight.charAt(0))) ? false : true;
        }
        return true;
    }

    private boolean sameAsTextBeforeCursor(InputConnection ic, CharSequence text) {
        CharSequence beforeText = ic.getTextBeforeCursor(text.length(), 0);
        return TextUtils.equals(text, beforeText);
    }

    public void revertLastWord(boolean deleteChar) {
        int length = this.mComposing.length();
        if (!this.mPredicting && length > 0) {
            InputConnection ic = getCurrentInputConnection();
            this.mPredicting = true;
            this.mJustRevertedSeparator = ic.getTextBeforeCursor(1, 0);
            if (deleteChar) {
                ic.deleteSurroundingText(1, 0);
            }
            int toDelete = this.mCommittedLength;
            CharSequence toTheLeft = ic.getTextBeforeCursor(this.mCommittedLength, 0);
            if (toTheLeft != null && toTheLeft.length() > 0 && isWordSeparator(toTheLeft.charAt(toTheLeft.length() - 1))) {
                toDelete++;
            }
            if (toTheLeft != null && toTheLeft.length() > 0 && isWordSeparator(toTheLeft.charAt(0))) {
                toDelete--;
            }
            ic.deleteSurroundingText(toDelete, 0);
            ic.setComposingText(this.mComposing, 1);
            TextEntryState.backspace();
            postUpdateSuggestions();
            return;
        }
        sendDownUpKeyEvents(67);
        this.mJustRevertedSeparator = null;
    }

    protected String getWordSeparators() {
        return this.mWordSeparators;
    }

    public boolean isWordSeparator(int code) {
        String separators = getWordSeparators();
        return separators.contains(String.valueOf((char) code));
    }

    private boolean isSentenceSeparator(int code) {
        return this.mSentenceSeparators.contains(String.valueOf((char) code));
    }

    private void sendSpace() {
        sendKeyChar(' ');
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    public boolean preferCapitalization() {
        return this.mWord.isFirstCharCapitalized();
    }

    private void toggleLanguage(boolean reset, boolean next) {
        if (reset) {
            this.mLanguageSwitcher.reset();
        } else if (next) {
            this.mLanguageSwitcher.next();
        } else {
            this.mLanguageSwitcher.prev();
        }
        initSuggest(this.mLanguageSwitcher.getInputLanguage());
        int currentKeyboardMode = this.mCalibration.getKeyboardMode();
        reloadKeyboards();
        this.mCalibration.makeKeyboards(true, this.mLanguageSwitcher.getInputLayout());
        this.mCalibration.setKeyboardMode(currentKeyboardMode, 0, this.mEnableVoiceButton && this.mEnableVoice);
        this.mLanguageSwitcher.persist();
        this.mLanguageSwitcher.getInputLayout();
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    private void toggleArrow(boolean arrow_on) {
        if (mEnableCursorsMode == 1) {
            reloadKeyboards();
            LatinKeyboard.mode_arrows = arrow_on;
            this.mCalibration.setKeyboardMode(this.mCalibration.mMode, this.mCalibration.getKeyboardmImeOptions(), this.mCalibration.mHasVoice);
        }
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        updateSwipesettings(sharedPreferences, key);
        boolean recreate = false;
        boolean recreateSuggestions = false;
        boolean redraw = this.mCalibration.LoadKeyboardLayoutChanged(sharedPreferences, key);
        if (PREF_ALWAYS_SUGGEST.equals(key)) {
            this.mAlwaysSuggest = sharedPreferences.getBoolean(PREF_ALWAYS_SUGGEST, this.mResources.getBoolean(R.bool.always_suggest));
        }
        if (PREF_BIGRAM_SUGGESTIONS.equals(key)) {
            this.mBigramSuggestionEnabled = sharedPreferences.getBoolean(PREF_BIGRAM_SUGGESTIONS, true) & this.mShowSuggestions;
            updateCorrectionMode();
        }
        if (PREF_AUTO_SELECT_BEST_VOICE_CHOICE.equals(key)) {
            this.mBestVoiceCohice = sharedPreferences.getBoolean(PREF_AUTO_SELECT_BEST_VOICE_CHOICE, true);
        }
        if (PREF_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER.equals(key)) {
            mSuggestWordsMissingSpace = sharedPreferences.getBoolean(PREF_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER, false);
        }
        if (PREF_NO_POPUP_ON_SPACE.equals(key)) {
            mNoPopupOnSpace = sharedPreferences.getBoolean(PREF_NO_POPUP_ON_SPACE, false);
        }
        if (PREF_AUTO_SWITCH_BACK_TO_ALPHA.equals(key)) {
            mAutoBackToAlpha = sharedPreferences.getBoolean(PREF_AUTO_SWITCH_BACK_TO_ALPHA, true);
        }
        if (PREF_LONG_PRESS_ON_123_TO_SETTINGS.equals(key)) {
            mLongPressOn123ToSettings = sharedPreferences.getBoolean(PREF_LONG_PRESS_ON_123_TO_SETTINGS, true);
        }
        if (Calibration.PREF_URI_BACKGROUND_IMAGE.equals(key)) {
            redraw = true;
            recreate = true;
        } else if (Calibration.PREF_USE_CUSTOM_IMAGTE.equals(key)) {
            redraw = true;
            recreate = true;
        } else if (PREF_BACKGROUND_CUSTOM_KEY.equals(key)) {
            mUseCustomBackgrounColors = sharedPreferences.getBoolean(PREF_BACKGROUND_CUSTOM_KEY, this.mResources.getBoolean(R.bool.pref_background_custom));
            redraw = true;
            recreate = true;
        } else if (PREF_SUGGESTION_CUSTOM_KEY.equals(key)) {
            mUseCustomSuggestionColors = sharedPreferences.getBoolean(PREF_SUGGESTION_CUSTOM_KEY, this.mResources.getBoolean(R.bool.pref_suggestion_custom));
            redraw = true;
            recreate = true;
            recreateSuggestions = true;
        } else if (PREF_DOUBLE_SPACE_TO_PERIOD.equals(key)) {
            this.mDoubleSpaceToPeriod = sharedPreferences.getBoolean(PREF_DOUBLE_SPACE_TO_PERIOD, this.mResources.getBoolean(R.bool.double_space_to_period));
        } else if (PREF_EXTERNAL_SKIN.equals(key)) {
            this.mExternalSkin = sharedPreferences.getString(PREF_EXTERNAL_SKIN, LoggingEvents.EXTRA_CALLING_APP_NAME);
            WordInfo.getAllBuilders(context);
            skinData = WordInfo.getSkinDataByName(this.mExternalSkin);
            if (skinData != null) {
                mUseExternalSkin = true;
            } else {
                mUseExternalSkin = false;
            }
            redraw = true;
            recreate = true;
            recreateSuggestions = true;
        } else if (PREF_PUNCTUATION_EDITOR.equals(key)) {
            initSuggestPuncList(sharedPreferences);
        } else if (PREF_USE_CONTACT_DICTIONARY.equals(key)) {
            if (this.mLanguageSwitcher != null) {
                initSuggest(this.mLanguageSwitcher.getInputLanguage());
            }
        } else if (PREF_SUGGESTIONS_FONT_COLOR.equals(key)) {
            mSuggestionFontClor = sharedPreferences.getInt(PREF_SUGGESTIONS_FONT_COLOR, this.mResources.getColor(R.color.candidate_recommended));
            CandidateView.setColor(mSuggestionFontClor);
        } else if (PREF_GESTURE_SENSITIVITY.equals(key)) {
            this.mGestureSensitivity = sharedPreferences.getInt(PREF_GESTURE_SENSITIVITY, getResources().getInteger(R.integer.gesture_sesitivity));
            LatinKeyboardBaseView.mSwipeThresholdMul = this.mGestureSensitivity;
        } else if (PREF_SUGGESTIONS_FONT_COLOR.equals(key)) {
            mSuggestionBarColor = sharedPreferences.getInt(PREF_SUGGESTIONS_FONT_COLOR, -16777216);
        } else if (PREF_KEYBOARD_BACKGROUND_COLOR.equals(key)) {
            mKeyboardBackgroundColor = sharedPreferences.getInt(PREF_KEYBOARD_BACKGROUND_COLOR, -16777216);
            redraw = true;
            recreate = true;
        } else if (PREF_ENABLE_CURSORS.equals(key)) {
            String enableCursors = sharedPreferences.getString(PREF_ENABLE_CURSORS, getString(R.string.enable_cursors_on_swipe));
            if (enableCursors.equals(getString(R.string.enable_cursors_never))) {
                mEnableCursorsMode = 0;
                LatinKeyboard.mode_arrows = false;
            } else if (enableCursors.equals(getString(R.string.enable_cursors_on_swipe))) {
                mEnableCursorsMode = 1;
            } else if (enableCursors.equals(getString(R.string.enable_cursors_always))) {
                mEnableCursorsMode = 2;
                LatinKeyboard.mode_arrows = true;
            }
            redraw = true;
        } else if (PREF_AUTO_SPACE.equals(key)) {
            this.mAutoSpaceAfterPunc = sharedPreferences.getBoolean(PREF_AUTO_SPACE, this.mResources.getBoolean(R.bool.auto_space_after_punc));
        } else if (PREF_VOLUME_KEY_FOR_LEFT_RIGHT_SUPPORT.equals(key)) {
            this.mUseVolumeKeyForLeftRight = sharedPreferences.getBoolean(PREF_VOLUME_KEY_FOR_LEFT_RIGHT_SUPPORT, false);
        } else if (PREF_RTL_SUPPORTED.equals(key)) {
            mRTLEnabled = sharedPreferences.getBoolean(PREF_RTL_SUPPORTED, false);
            CandidateView.setRTL(mRTLEnabled);
        } else if (PREF_FULL_SCREEN_PORTRAIT.equals(key)) {
            this.mFullScreenPortrait = sharedPreferences.getBoolean(PREF_FULL_SCREEN_PORTRAIT, false);
            redraw = true;
        } else if (PREF_FULL_SCREEN_LANDSCAPE.equals(key)) {
            this.mNoFullScreenLandscape = sharedPreferences.getBoolean(PREF_FULL_SCREEN_LANDSCAPE, false);
            redraw = true;
        } else if (PREF_SELECTED_LANGUAGES.equals(key)) {
            this.mLanguageSwitcher.loadLocales(sharedPreferences);
            this.mRefreshKeyboardRequired = true;
        } else if (PREF_RECORRECTION_ENABLED.equals(key)) {
            this.mReCorrectionEnabled = sharedPreferences.getBoolean(PREF_RECORRECTION_ENABLED, getResources().getBoolean(R.bool.default_recorrection_enabled));
        } else if (PREF_SOUND_VOLUME.equals(key) || PREF_KB_SOUND_STYLE.equals(key)) {
            String soundStyle = sharedPreferences.getString(PREF_KB_SOUND_STYLE, getString(R.string.sound_android));
            if ((PREF_SOUND_VOLUME.equals(key) && this.mTypePlay == null) || PREF_KB_SOUND_STYLE.equals(key)) {
                if (this.mTypePlay != null) {
                    this.mTypePlay.release();
                }
                if (soundStyle.equals(getString(R.string.sound_android))) {
                    this.path = "android.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_pop))) {
                    this.path = "pop.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_soft))) {
                    this.path = "soft.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_tock))) {
                    this.path = "tock.ogg";
                } else {
                    this.path = "android.ogg";
                }
                if (this.path != null) {
                    this.mTypePlay = new SoundPool(4, 1, 0);
                    try {
                        try {
                            AssetFileDescriptor descriptor = getAssets().openFd(this.path);
                            this.mSoundID = this.mTypePlay.load(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength(), 1);
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    } catch (IllegalArgumentException e3) {
                        e3.printStackTrace();
                    } catch (IllegalStateException e4) {
                        e4.printStackTrace();
                    }
                }
                if (PREF_SOUND_VOLUME.equals(key)) {
                    this.mSoundVolume = sharedPreferences.getInt(PREF_SOUND_VOLUME, getResources().getInteger(R.integer.config_defalut_sound_volume));
                }
            }
        }
        if (PREF_DEBUG_ON.equals(key)) {
            PERF_DEBUG = sharedPreferences.getBoolean(PREF_DEBUG_ON, false);
            if (PERF_DEBUG) {
                DEBUG = true;
                TRACE = false;
            }
        }
        if (PREF_SHOW_TOUCH_POINTS.equals(key)) {
            this.mShowTouchPoints = sharedPreferences.getBoolean(PREF_SHOW_TOUCH_POINTS, false);
            LatinKeyboardBaseView.setShowTouchPoints(this.mShowTouchPoints);
        }
        if (key.equals("suggestion_bar_color")) {
            redraw = true;
            recreate = true;
        }
        if (key.equals(PREF_SUGGESTION_BAR_SIZE)) {
            redraw = true;
            recreate = true;
            recreateSuggestions = true;
        }
        if (redraw) {
            if (this.mLanguageSwitcher != null) {
                this.mCalibration.setKeyboardMode(this.mCalibration.mMode, this.mCalibration.getKeyboardmImeOptions(), this.mCalibration.mHasVoice);
            }
            reloadKeyboards();
            if (recreate) {
                this.mCalibration.recreateInputView();
                if (this.mCandidateViewContainer != null) {
                    this.mCandidateViewContainer.invalidateDrawable(this.mCandidateViewContainer.getBackground());
                }
            }
            if (recreateSuggestions) {
                if (this.mLanguageSwitcher != null) {
                    initSuggest(this.mLanguageSwitcher.getInputLanguage());
                }
                if (this.mCandidateViewContainer != null) {
                    ((ViewGroup) this.mCandidateViewContainer.getParent()).removeView(this.mCandidateViewContainer);
                    setCandidatesView(onCreateCandidatesView());
                }
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
        }
    }

    @Override
    public void swipeRight() {
        exectueGesture(this.mGestureRight);
    }

    @Override
    public void swipeLeft() {
        exectueGesture(this.mGestureLeft);
    }

    @Override
    public void swipeDown() {
        exectueGesture(this.mGestureDown);
    }

    @Override
    public void swipeUp() {
        exectueGesture(this.mGestureUp);
    }

    @Override
    public void onPress(int primaryCode) {
        if (this.mCalibration.isVibrateAndSoundFeedbackRequired()) {
            vibrate();
            playKeyClick(primaryCode);
        }
        boolean distinctMultiTouch = this.mCalibration.hasDistinctMultitouch();
        if (distinctMultiTouch && primaryCode == -1) {
            this.mShiftKeyState.onPress();
            handleShift();
        } else if (distinctMultiTouch && primaryCode == -2) {
            changeKeyboardMode(true);
            this.mSymbolKeyState.onPress();
            this.mCalibration.setAutoModeSwitchStateMomentary();
        } else {
            this.mShiftKeyState.onOtherKeyPressed();
            this.mSymbolKeyState.onOtherKeyPressed();
        }
    }

    @Override
    public void onRelease(int primaryCode) {
        ((LatinKeyboard) this.mCalibration.getInputView().getKeyboard()).keyReleased();
        boolean distinctMultiTouch = this.mCalibration.hasDistinctMultitouch();
        if (distinctMultiTouch && primaryCode == -1) {
            if (this.mShiftKeyState.isMomentary()) {
                resetShift();
            }
            this.mShiftKeyState.onRelease();
        } else if (distinctMultiTouch && primaryCode == -2) {
            if (this.mCalibration.isInChordingAutoModeSwitchState()) {
                changeKeyboardMode(true);
            }
            this.mSymbolKeyState.onRelease();
        }
    }

    private FieldContext makeFieldContext() {
        return new FieldContext(getCurrentInputConnection(), getCurrentInputEditorInfo(), this.mLanguageSwitcher.getInputLanguage(), this.mLanguageSwitcher.getEnabledLanguages());
    }

    private boolean fieldCanDoVoice(FieldContext fieldContext) {
        return (this.mPasswordText || this.mVoiceInput == null || this.mVoiceInput.isBlacklistedField(fieldContext)) ? false : true;
    }

    /** The microphone key is shown on every field except password fields (apps cannot hide it). */
    private boolean shouldShowVoiceButton(FieldContext fieldContext, EditorInfo attribute) {
        return !this.mPasswordText && this.mVoiceInput != null;
    }

    public void updateRingerMode() {
        if (this.mAudioManager == null) {
            this.mAudioManager = (AudioManager) getSystemService("audio");
        }
        if (this.mAudioManager != null) {
            this.mSilentMode = this.mAudioManager.getRingerMode() != 2;
        }
    }

    private void playKeyClick(int primaryCode) {
        if (this.mAudioManager == null && this.mCalibration.getInputView() != null) {
            updateRingerMode();
        }
        if (this.mSoundOn && !this.mSilentMode) {
            this.mTypePlay.play(this.mSoundID, this.mSoundVolume / 100.0f, this.mSoundVolume / 100.0f, 1, 0, 1.0f);
        }
    }

    private void vibrate() {
        if (!this.mVibrateOn) {
            return;
        }
        try {
            // 1) نظام الاستجابة اللمسية (مثل لوحات المفاتيح الحديثة) اذا كان مفعّل بالموبايل
            boolean sysHaptic = android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0;
            android.view.View hv = this.mCalibration != null ? this.mCalibration.getInputView() : null;
            if (sysHaptic && hv != null) {
                hv.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP, android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING | android.view.HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
            }
        } catch (Throwable ignored) {
        }
        // 2) اهتزاز مباشر بالمدة اللي اختارها المستخدم (يشتغل حتى لو الاستجابة اللمسية مطفية)
        if (this.mVibrator == null) {
            this.mVibrator = AlsarabApp.getVibrator(this);
        }
        AlsarabApp.vibrate(this.mVibrator, this.mVibrateLength > 0 ? this.mVibrateLength : 30);
    }

    private void checkTutorial(String privateImeOptions) {
        if (privateImeOptions != null) {
            if (privateImeOptions.equals("com.android.setupwizard:ShowTutorial")) {
                if (this.mTutorial == null) {
                    startTutorial();
                }
            } else if (privateImeOptions.equals("com.android.setupwizard:HideTutorial") && this.mTutorial != null && this.mTutorial.close()) {
                this.mTutorial = null;
            }
        }
    }

    private void startTutorial() {
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1), 500L);
    }

    public void tutorialDone() {
        this.mTutorial = null;
    }

    public void promoteToUserDictionary(String word, int frequency) {
        if (!this.mUserDictionary.isValidWord(word)) {
            this.mUserDictionary.addWord(word, frequency);
        }
    }

    public WordComposer getCurrentWord() {
        return this.mWord;
    }

    public boolean getPopupOn() {
        return this.mPopupOn;
    }

    private void updateCorrectionMode() {
        int i = 1;
        mHasDictionary = this.mSuggest != null;
        this.mAutoCorrectOn = (this.mAutoCorrectEnabled || this.mQuickFixes) && !this.mInputTypeNoAutoCorrect && mHasDictionary;
        if (this.mAutoCorrectOn && this.mAutoCorrectEnabled) {
            i = 2;
        } else if (!this.mAutoCorrectOn) {
            i = 0;
        }
        this.mCorrectionMode = i;
        this.mCorrectionMode = (this.mBigramSuggestionEnabled && this.mAutoCorrectOn && this.mAutoCorrectEnabled) ? 3 : this.mCorrectionMode;
        if (this.mSuggest != null) {
            this.mSuggest.setCorrectionMode(this.mCorrectionMode);
        }
    }

    private void updateAutoTextEnabled(Locale systemLocale) {
        if (this.mSuggest != null) {
            boolean different = !systemLocale.getLanguage().equalsIgnoreCase(mInputLocale.substring(0, 2));
            this.mSuggest.setAutoTextEnabled(!different && this.mQuickFixes);
        }
    }

    protected void launchSettings() {
        launchSettings(SettingsActivity.class);
    }

    protected void launchUserDictionaryEditor() {
        handleClose();
        Intent intent = new Intent();
        intent.setClass(this, CustomDictionaryActivity.class);
        intent.setFlags(268435456);
        startActivity(intent);
    }

    public void launchDebugSettings() {
        launchSettings(DebugSettingsActivity.class);
    }

    protected void launchSettings(Class<? extends PreferenceActivity> settingsClass) {
        handleClose();
        Intent intent = new Intent();
        intent.setClass(this, settingsClass);
        intent.setFlags(268435456);
        startActivity(intent);
    }

    private void loadSettings() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        HandlePopularDomain(sp);
        HandleCustomeSmileys(sp);
        HandlePunctuationPopup(sp);
        this.mVibrateOn = sp.getBoolean(PREF_VIBRATE_ON, false);
        if (this.mVibrateOn) {
            this.mVibrateLength = sp.getInt(PREF_VIBRATE_LENGTH, getResources().getInteger(R.integer.vibrate_duration_ms));
            if (this.mVibrator == null) {
                this.mVibrator = AlsarabApp.getVibrator(this);
            }
        }
        mNoPopupOnSpace = sp.getBoolean(PREF_NO_POPUP_ON_SPACE, false);
        mAutoBackToAlpha = sp.getBoolean(PREF_AUTO_SWITCH_BACK_TO_ALPHA, true);
        mLongPressOn123ToSettings = sp.getBoolean(PREF_LONG_PRESS_ON_123_TO_SETTINGS, true);
        this.mGestureSensitivity = sp.getInt(PREF_GESTURE_SENSITIVITY, getResources().getInteger(R.integer.gesture_sesitivity));
        LatinKeyboardBaseView.mSwipeThresholdMul = this.mGestureSensitivity;
        this.mSoundOn = sp.getBoolean(PREF_SOUND_ON, false);
        this.mBestVoiceCohice = sp.getBoolean(PREF_AUTO_SELECT_BEST_VOICE_CHOICE, true);
        mSuggestWordsMissingSpace = sp.getBoolean(PREF_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER, false);
        getAllSwipesettings(sp);
        this.mPopupOn = sp.getBoolean(PREF_POPUP_ON, this.mResources.getBoolean(R.bool.default_popup_preview));
        this.mAutoCap = sp.getBoolean(PREF_AUTO_CAP, true);
        this.mLongPressDelay = sp.getInt("long_press_delay", getResources().getInteger(R.integer.config_long_press_key_timeout));
        Log.d(TAG, "mLongPressDelay = " + this.mLongPressDelay);
        this.mQuickFixes = sp.getBoolean(PREF_QUICK_FIXES, true);
        this.mHasUsedVoiceInput = sp.getBoolean(PREF_HAS_USED_VOICE_INPUT, false);
        this.mHasUsedVoiceInputUnsupportedLocale = sp.getBoolean(PREF_HAS_USED_VOICE_INPUT_UNSUPPORTED_LOCALE, false);
        String supportedLocalesString = SettingsUtil.getSettingsString(getContentResolver(), SettingsUtil.LATIN_IME_VOICE_INPUT_SUPPORTED_LOCALES, DEFAULT_VOICE_INPUT_SUPPORTED_LOCALES);
        ArrayList<String> voiceInputSupportedLocales = newArrayList(supportedLocalesString.split("\\s+"));
        this.mLocaleSupportedForVoiceInput = voiceInputSupportedLocales.contains(mInputLocale);
        this.mShowSuggestions = sp.getBoolean(PREF_SHOW_SUGGESTIONS, false);
        String voiceMode = sp.getString(PREF_VOICE_MODE, getString(R.string.voice_mode_main));
        boolean enableVoice = !voiceMode.equals(getString(R.string.voice_mode_off)) && this.mEnableVoiceButton;
        boolean voiceOnPrimary = false;
        if (this.mCalibration != null && (enableVoice != this.mEnableVoice || voiceOnPrimary != this.mVoiceOnPrimary)) {
            this.mCalibration.setVoiceMode(enableVoice, voiceOnPrimary);
        }
        this.mEnableVoice = enableVoice;
        this.mVoiceOnPrimary = voiceOnPrimary;
        String enableCursors = sp.getString(PREF_ENABLE_CURSORS, getString(R.string.enable_cursors_on_swipe));
        if (enableCursors.equals(getString(R.string.enable_cursors_never))) {
            mEnableCursorsMode = 0;
            LatinKeyboard.mode_arrows = false;
        } else if (enableCursors.equals(getString(R.string.enable_cursors_on_swipe))) {
            mEnableCursorsMode = 1;
        } else if (enableCursors.equals(getString(R.string.enable_cursors_always))) {
            mEnableCursorsMode = 2;
            LatinKeyboard.mode_arrows = true;
        }
        String soundStyle = sp.getString(PREF_KB_SOUND_STYLE, getString(R.string.sound_android));
        if (soundStyle.equals(getString(R.string.sound_android))) {
            this.path = "android.ogg";
        } else if (soundStyle.equals(getString(R.string.sound_pop))) {
            this.path = "pop.ogg";
        } else if (soundStyle.equals(getString(R.string.sound_soft))) {
            this.path = "soft.ogg";
        } else if (soundStyle.equals(getString(R.string.sound_tock))) {
            this.path = "tock.ogg";
        } else {
                    this.path = "android.ogg";
                }
        if (this.path != null) {
            this.mTypePlay = new SoundPool(4, 1, 0);
            try {
                try {
                    AssetFileDescriptor descriptor = getAssets().openFd(this.path);
                    this.mSoundID = this.mTypePlay.load(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength(), 1);
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
            } catch (IllegalArgumentException e4) {
                e4.printStackTrace();
            } catch (IllegalStateException e5) {
                e5.printStackTrace();
            }
        }
        this.mSoundVolume = sp.getInt(PREF_SOUND_VOLUME, getResources().getInteger(R.integer.config_defalut_sound_volume));
        mSuggestionFontClor = sp.getInt(PREF_SUGGESTIONS_FONT_COLOR, this.mResources.getColor(R.color.candidate_recommended));
        CandidateView.setColor(mSuggestionFontClor);
        if (mUseCustomBackgrounColors) {
            mButtonColor = sp.getInt(PREF_BUTTON_COLOR, this.mResources.getColor(R.color.button_color));
            LatinKeyboardBaseView.setColor(mButtonColor);
        } else if (!mUseExternalSkin) {
            mButtonColor = this.mResources.getColor(R.color.button_color);
            LatinKeyboardBaseView.setColor(mButtonColor);
        }
        this.mDoubleSpaceToPeriod = sp.getBoolean(PREF_DOUBLE_SPACE_TO_PERIOD, this.mResources.getBoolean(R.bool.double_space_to_period));
        this.mAutoSpaceAfterPunc = sp.getBoolean(PREF_AUTO_SPACE, this.mResources.getBoolean(R.bool.auto_space_after_punc));
        this.mUseVolumeKeyForLeftRight = sp.getBoolean(PREF_VOLUME_KEY_FOR_LEFT_RIGHT_SUPPORT, false);
        this.mAutoCorrectEnabled = sp.getBoolean(PREF_AUTO_COMPLETE, this.mResources.getBoolean(R.bool.enable_autocorrect)) & this.mShowSuggestions;
        this.mBigramSuggestionEnabled = sp.getBoolean(PREF_BIGRAM_SUGGESTIONS, true) & this.mShowSuggestions;
        updateCorrectionMode();
        updateAutoTextEnabled(this.mResources.getConfiguration().locale);
        this.mLanguageSwitcher.loadLocales(sp);
    }

    private void initSuggestPuncList(SharedPreferences prefs) {
        mSuggestPuncList = new ArrayList();
        this.mSuggestPuncs = prefs.getString(PREF_PUNCTUATION_EDITOR, this.mResources.getString(R.string.suggested_punctuations));
        if (this.mSuggestPuncs != null) {
            for (int i = 0; i < this.mSuggestPuncs.length(); i++) {
                mSuggestPuncList.add(this.mSuggestPuncs.subSequence(i, i + 1));
            }
        }
    }

    private boolean isSuggestedPunctuation(int code) {
        return this.mSuggestPuncs.contains(String.valueOf((char) code));
    }

    private void showOptionsMenu() {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= 14) {
            ContextThemeWrapper wrapper = new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault);
            builder = new AlertDialog.Builder(wrapper);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setCancelable(true);
        builder.setIcon(R.drawable.ic_application);
        builder.setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null);
        CharSequence itemSettings = getString(R.string.english_ime_settings);
        CharSequence itemInputMethod = getString(R.string.selectInputMethod);
        builder.setItems(new CharSequence[]{itemInputMethod, itemSettings}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface di, int position) {
                di.dismiss();
                switch (position) {
                    case 0:
                        ((InputMethodManager) AlsarabIME.this.getSystemService("input_method")).showInputMethodPicker();
                        return;
                    case 1:
                        AlsarabIME.this.launchSettings();
                        return;
                    default:
                        return;
                }
            }
        });
        builder.setTitle(this.mResources.getString(R.string.english_ime_input_options));
        this.mOptionsDialog = builder.create();
        Window window = this.mOptionsDialog.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.token = this.mCalibration.getInputView().getWindowToken();
        lp.type = 1003;
        window.setAttributes(lp);
        window.addFlags(131072);
        this.mOptionsDialog.show();
    }

    public void changeKeyboardMode(boolean allowNumbers) {
        this.mCalibration.toggleSymbols(allowNumbers);
        if (this.mCapsLock && this.mCalibration.isAlphabetMode()) {
            this.mCalibration.setShiftLocked(this.mCapsLock);
        }
        updateShiftKeyState(getCurrentInputEditorInfo());
    }

    public static <E> ArrayList<E> newArrayList(E... eArr) {
        int capacity = ((eArr.length * 110) / 100) + 5;
        ArrayList<E> list = new ArrayList<>(capacity);
        Collections.addAll(list, eArr);
        return list;
    }

    @Override // android.inputmethodservice.InputMethodService, android.inputmethodservice.AbstractInputMethodService, android.app.Service
    protected void dump(FileDescriptor fd, PrintWriter fout, String[] args) {
        super.dump(fd, fout, args);
        Printer p = new PrintWriterPrinter(fout);
        p.println("AlsarabIME state :");
        p.println("  Keyboard mode = " + this.mCalibration.getKeyboardMode());
        p.println("  mCapsLock=" + this.mCapsLock);
        p.println("  mComposing=" + this.mComposing.toString());
        p.println("  mPredictionOn=" + this.mPredictionOn);
        p.println("  mCorrectionMode=" + this.mCorrectionMode);
        p.println("  mPredicting=" + this.mPredicting);
        p.println("  mAutoCorrectOn=" + this.mAutoCorrectOn);
        p.println("  mAutoSpace=" + this.mAutoSpace);
        p.println("  mCompletionOn=" + this.mCompletionOn);
        p.println("  TextEntryState.state=" + TextEntryState.getState());
        p.println("  mSoundOn=" + this.mSoundOn);
        p.println("  mVibrateOn=" + this.mVibrateOn);
        p.println("  mPopupOn=" + this.mPopupOn);
    }

    private void measureCps() {
        long now = System.currentTimeMillis();
        if (this.mLastCpsTime == 0) {
            this.mLastCpsTime = now - 100;
        }
        this.mCpsIntervals[this.mCpsIndex] = now - this.mLastCpsTime;
        this.mLastCpsTime = now;
        this.mCpsIndex = (this.mCpsIndex + 1) % 16;
        long total = 0;
        for (int i = 0; i < 16; i++) {
            total += this.mCpsIntervals[i];
        }
        System.out.println("CPS = " + (16000.0f / ((float) total)));
    }

    public void onAutoCompletionStateChanged(boolean isAutoCompletion) {
        this.mCalibration.onAutoCompletionStateChanged(isAutoCompletion);
    }

    public static int getKeyboardBackgroundColor() {
        return mKeyboardBackgroundColor;
    }

    public static void setKeyboardBackgroundColor(int color) {
        mKeyboardBackgroundColor = color;
    }

    public static int getSuggestionBarColor() {
        return mSuggestionBarColor;
    }

    public static void setSuggestionBarColor(int color) {
        mSuggestionBarColor = color;
    }

    private void HandlePopularDomain(SharedPreferences prefs) {
        for (int i = 0; i < 6; i++) {
            LatinKeyboardBaseView.popularDomains[i] = prefs.getString(SettingsActivity.PREF_POPULAR_DOMAIN[i], getString(SettingsActivity.popular_domains_res[i]));
        }
    }

    private void HandleCustomeSmileys(SharedPreferences prefs) {
        for (int i = 0; i < 44; i++) {
            LatinKeyboardBaseView.CustomSmileys[i] = prefs.getString(SettingsActivity.PREF_CUSTOME_SMILEYS[i], getString(SettingsActivity.popular_smileys_res[i]));
        }
    }

    private void HandlePunctuationPopup(SharedPreferences prefs) {
        for (int i = 0; i < 13; i++) {
            LatinKeyboardBaseView.CustomPunctuationPopup[i] = prefs.getString(SettingsActivity.PREF_CUSTOME_PUNCTUATION_POPUP[i], getString(SettingsActivity.PunctuationPopup_res[i]));
        }
    }

    private void getAllSwipesettings(SharedPreferences sp) {
        this.mGestureRight = getSwipesettings(sp, PREF_SWIPE_RIGHT);
        this.mGestureLeft = getSwipesettings(sp, PREF_SWIPE_LEFT);
        this.mGestureUp = getSwipesettings(sp, PREF_SWIPE_UP);
        this.mGestureDown = getSwipesettings(sp, PREF_SWIPE_DOWN);
    }

    private int getSwipesettings(SharedPreferences sp, String swipe) {
        String gesture = sp.getString(swipe, getString(R.string.gesture_do_nothing));
        if (gesture.equals(getString(R.string.gesture_do_nothing))) {
            return 0;
        }
        if (gesture.equals(getString(R.string.gesture_delete_word))) {
            return 1;
        }
        if (gesture.equals(getString(R.string.gesture_go_setting))) {
            return 2;
        }
        if (gesture.equals(getString(R.string.gesture_close_keyboard))) {
            return 3;
        }
        if (gesture.equals(getString(R.string.gesture_paste_from_clipboard))) {
            return 4;
        }
        if (gesture.equals(getString(R.string.gesture_pickup_suggestion))) {
            return 5;
        }
        if (gesture.equals(getString(R.string.gesture_next_lang))) {
            return 6;
        }
        if (gesture.equals(getString(R.string.gesture_prev_lang))) {
            return 7;
        }
        if (gesture.equals(getString(R.string.gesture_key_down))) {
            return 11;
        }
        if (gesture.equals(getString(R.string.gesture_key_up))) {
            return 10;
        }
        if (gesture.equals(getString(R.string.gesture_key_right))) {
            return 8;
        }
        if (gesture.equals(getString(R.string.gesture_key_left))) {
            return 9;
        }
        if (gesture.equals(getString(R.string.gesture_toggle_t9))) {
            return 12;
        }
        if (gesture.equals(getString(R.string.gesture_toggle_compact))) {
            return 13;
        }
        if (gesture.equals(getString(R.string.gesture_toggle_t9compact))) {
            return 14;
        }
        if (gesture.equals(getString(R.string.gesture_toggle_symbols))) {
            return 15;
        }
        if (gesture.equals(getString(R.string.gesture_launch_user_dic))) {
            return 16;
        }
        if (gesture.equals(getString(R.string.gesture_start_voice))) {
            return 17;
        }
        if (gesture.equals(getString(R.string.gesture_toggle_normal_splited))) {
            return 18;
        }
        return gesture.equals(getString(R.string.gesture_toggle_caps_lock)) ? 19 : 0;
    }

    private void updateSwipesettings(SharedPreferences sp, String key) {
        if (PREF_SWIPE_RIGHT.equals(key)) {
            this.mGestureRight = getSwipesettings(sp, PREF_SWIPE_RIGHT);
            return;
        }
        if (PREF_SWIPE_LEFT.equals(key)) {
            this.mGestureLeft = getSwipesettings(sp, PREF_SWIPE_LEFT);
        } else if (PREF_SWIPE_UP.equals(key)) {
            this.mGestureUp = getSwipesettings(sp, PREF_SWIPE_UP);
        } else if (PREF_SWIPE_DOWN.equals(key)) {
            this.mGestureDown = getSwipesettings(sp, PREF_SWIPE_DOWN);
        }
    }

    private void exectueGesture(int gesture) {
        switch (gesture) {
            case 0:
            default:
                return;
            case 1:
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.beginBatchEdit();
                    EditingUtil.deleteWordBeforeCursor(ic, this.mWordSeparators);
                    ic.endBatchEdit();
                    return;
                }
                return;
            case 2:
                launchSettings();
                return;
            case 3:
                handleClose();
                return;
            case 4:
                paste_from_clipboard();
                return;
            case 5:
                boolean pickedDefault = pickDefaultSuggestion();
                if (pickedDefault) {
                    TextEntryState.backToAcceptedDefault(this.mWord.getTypedWord());
                    sendSpace();
                    this.mBestWord = null;
                    return;
                }
                return;
            case 6:
                toggleLanguage(false, true);
                return;
            case 7:
                toggleLanguage(false, false);
                return;
            case 8:
                sendDownUpKeyEvents(22);
                handleArrow(22);
                return;
            case 9:
                sendDownUpKeyEvents(21);
                handleArrow(21);
                return;
            case 10:
                sendDownUpKeyEvents(19);
                handleArrow(19);
                return;
            case 11:
                sendDownUpKeyEvents(20);
                handleArrow(20);
                return;
            case 12:
                SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
                if (Calibration.mPortaraitLayoutMode == 0) {
                    editor.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_t9));
                    Calibration.mPortaraitLayoutMode = 1;
                } else {
                    editor.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_normal));
                    Calibration.mPortaraitLayoutMode = 0;
                    Calibration.mIsPortraitModeAndT9 = false;
                }
                SharedPreferencesCompat.apply(editor);
                return;
            case 13:
                SharedPreferences.Editor editor2 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                if (Calibration.mPortaraitLayoutMode == 0) {
                    editor2.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_compact));
                    Calibration.mPortaraitLayoutMode = 2;
                } else {
                    editor2.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_normal));
                    Calibration.mPortaraitLayoutMode = 0;
                }
                SharedPreferencesCompat.apply(editor2);
                return;
            case 14:
                SharedPreferences.Editor editor3 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                if (Calibration.mPortaraitLayoutMode == 0) {
                    editor3.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_t9));
                    Calibration.mPortaraitLayoutMode = 1;
                } else if (Calibration.mPortaraitLayoutMode == 1) {
                    editor3.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_compact));
                    Calibration.mPortaraitLayoutMode = 2;
                } else {
                    editor3.putString(PREF_PORTRAIT_LAYOUT, getString(R.string.layout_default_mode_normal));
                    Calibration.mPortaraitLayoutMode = 0;
                }
                SharedPreferencesCompat.apply(editor3);
                return;
            case 15:
                changeKeyboardMode(false);
                return;
            case 16:
                launchUserDictionaryEditor();
                return;
            case LoggingEvents.VoiceIme.TEXT_MODIFIED /* 17 */:
                startListening(true);
                return;
            case 18:
                SharedPreferences.Editor editor4 = PreferenceManager.getDefaultSharedPreferences(this).edit();
                if (Calibration.mLandscapeLayoutMode == 0) {
                    editor4.putString(PREF_LANDSCAPE_LAYOUT, getString(R.string.layout_landscape_default_mode_split));
                    Calibration.mLandscapeLayoutMode = 1;
                } else if (Calibration.mLandscapeLayoutMode == 1) {
                    editor4.putString(PREF_LANDSCAPE_LAYOUT, getString(R.string.layout_landscape_default_mode_normal));
                    Calibration.mLandscapeLayoutMode = 0;
                }
                SharedPreferencesCompat.apply(editor4);
                return;
            case LoggingEvents.VoiceIme.VOICE_INPUT_SETTING_ENABLED /* 19 */:
                handleToggleCapsLock();
                return;
        }
    }

    public void paste_from_clipboard() {
        InputConnection ic;
        android.text.ClipboardManager cm = (android.text.ClipboardManager) getSystemService("clipboard");
        CharSequence text = cm.getText();
        if (!TextUtils.isEmpty(text) && (ic = getCurrentInputConnection()) != null) {
            ic.beginBatchEdit();
            EditingUtil.appendText(ic, text.toString());
            ic.endBatchEdit();
        }
    }

    public void deleteLastCharactersFromInput(int countToDelete) {
        boolean shouldDeleteUsingCompletion;
        if (countToDelete != 0) {
            int currentLength = this.mComposing.length();
            if (currentLength > 0) {
                shouldDeleteUsingCompletion = true;
                if (currentLength > countToDelete) {
                    this.mComposing.delete(currentLength - countToDelete, currentLength);
                    this.mWord.deleteLast(countToDelete);
                } else {
                    this.mComposing.setLength(0);
                    this.mWord.reset();
                }
            } else {
                shouldDeleteUsingCompletion = false;
            }
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) {
                if (this.mCompletionOn && shouldDeleteUsingCompletion) {
                    ic.setComposingText(this.mComposing, 1);
                } else {
                    ic.deleteSurroundingText(countToDelete, 0);
                }
            }
            updateShiftKeyState(getCurrentInputEditorInfo());
        }
    }

    public static boolean isAltSpaceLangSwitchNotPossible() {
        String model = Build.MODEL.toLowerCase();
        return model.equals("milestone") || model.equals("droid");
    }



    private void createResultDialog(final CharSequence[] recognitionResults) {
        if (Build.VERSION.SDK_INT >= 14) {
            ContextThemeWrapper wrapper = new ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault);
            new AlertDialog.Builder(wrapper);
        } else {
            new AlertDialog.Builder(this);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setItems(recognitionResults, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                AlsarabIME.this.notifyResult(recognitionResults[which]);
            }
        });
        builder.setCancelable(true);
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                AlsarabIME.this.notifyResult(null);
            }
        });
        builder.setNeutralButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                AlsarabIME.this.notifyResult(null);
            }
        });
        builder.setTitle("Perfect keyboard");
        AlertDialog Dialog = builder.create();
        Window window = Dialog.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.token = this.mVoiceInput.getView().getWindowToken();
        lp.type = 1003;
        window.setAttributes(lp);
        window.addFlags(131072);
        Dialog.show();
    }

    public void notifyResult(CharSequence result) {
        if (result != null) {
            this.mVoiceInput.logVoiceInputDelivered(result.length());
            this.mHints.registerVoiceResult(result.toString());
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) {
                ic.beginBatchEdit();
            }
            commitTyped(ic);
            EditingUtil.appendText(ic, result.toString());
            if (ic != null) {
                ic.endBatchEdit();
            }
            this.mVoiceInputHighlighted = true;
            this.mWordToSuggestions.putAll(this.mVoiceResults.alternatives);
        }
    }
}
