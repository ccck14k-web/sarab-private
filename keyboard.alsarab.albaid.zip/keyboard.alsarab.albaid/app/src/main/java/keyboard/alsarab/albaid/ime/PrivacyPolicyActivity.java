package keyboard.alsarab.albaid.ime;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;
import keyboard.alsarab.albaid.R;

/** Shows the privacy policy page (the same HTML that is published on the website) from the app assets. */
public class PrivacyPolicyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.privacy_policy_title);
        try {
            WebView web = new WebView(this);
            WebSettings settings = web.getSettings();
            settings.setJavaScriptEnabled(false);
            settings.setAllowFileAccess(false);
            settings.setAllowContentAccess(false);
            web.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return true;
                }
            });
            String page = "ar".equals(Locale.getDefault().getLanguage()) ? "privacy_policy.html" : "privacy_policy_en.html";
            web.loadUrl("file:///android_asset/" + page);
            setContentView(web);
        } catch (Exception e) {
            finish();
        }
    }
}
