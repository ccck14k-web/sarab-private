package keyboard.alsarab.albaid.ime;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Process;
import android.os.Vibrator;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.speech.SpeechRecognizer;
import android.text.AutoText;
import android.util.Log;
import android.widget.Toast;
import keyboard.alsarab.albaid.colorpicker.AmbilWarnaDialog;
import keyboard.alsarab.albaid.common.speech.LoggingEvents;
import keyboard.alsarab.albaid.ime.voice.SettingsUtil;
import keyboard.alsarab.albaid.ime.voice.VoiceInputLogger;
import keyboard.alsarab.albaid.R;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

public class SettingsActivity extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener, DialogInterface.OnDismissListener {
    @Override
    public boolean onPreferenceTreeClick(PreferenceScreen screen, Preference preference) {
        boolean handled = super.onPreferenceTreeClick(screen, preference);
        if (preference instanceof PreferenceScreen) {
            AlsarabApp.fixDialog(((PreferenceScreen) preference).getDialog());
        }
        return handled;
    }

    void openOurStorePage() {
        String pkg = getPackageName();
        try {
            Intent i = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + pkg));
            i.setFlags(268435456);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            try {
                Intent i2 = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
                i2.setFlags(268435456);
                startActivity(i2);
            } catch (ActivityNotFoundException e2) {
            }
        }
    }

    private static final String DISPLAY_LUNCHER_ICON = "display_BackupPro_icon";
    private static final String PREDICTION_SETTINGS_KEY = "prediction_settings";
    private static final String PREF_KB_SOUND_STYLE = "tap_sound_style_pref";
    static final String PREF_LONG_PRESS_DELAY = "long_press_delay";
    private static final String PREF_PUNCTUATION_EDITOR = "punctuation_editor";
    static final String PREF_SETTINGS_KEY = "settings_key";
    private static final String PREF_SOUND_VOLUME = "sound_volume";
    public static final String PREF_SUGGESTION_BAR_COLOR = "suggestion_bar_color";
    private static final String PREF_VIBRATE_LENGTH = "vibration_length";
    private static final String PREF_VIBRATE_ON = "vibrate_on";
    private static final String QUICK_FIXES_KEY = "quick_fixes";
    private static final int REQ_CODE_PICK_IMAGE = 0;
    private static final String TAG = "SettingsActivity";
    private static final int VOICE_INPUT_CONFIRM_DIALOG = 0;
    private static final String VOICE_SETTINGS_KEY = "voice_mode";
    private EditTextPreference CustomPunctuationPopup;
    private EditTextPreference CustomSmileys;
    private EditTextPreference customePunctuation;
    private VoiceInputLogger mLogger;
    private int mLongPressDelay;
    private DialogSeekBarPreference mLongPressDelayPreference;
    private CheckBoxPreference mQuickFixes;
    private ListPreference mSettingsKeyPreference;
    private boolean mShowIcon;
    private float mSoundVolume;
    private int mVibrateLength;
    private String mVoiceModeOff;
    private boolean mVoiceOn;
    private ListPreference mVoicePreference;
    String path;
    private EditTextPreference popularDomains;
    public static final String[] PREF_CUSTOME_SMILEYS = {"sm0", "sm1", "sm2", "sm3", "sm4", "sm5", "sm6", "sm7", "sm8", "sm9", "sm10", "sm11", "sm12", "sm13", "sm14", "sm15", "sm16", "sm17", "sm18", "sm19", "sm20", "sm21", "sm22", "sm23", "sm24", "sm25", "sm26", "sm27", "sm28", "sm29", "sm30", "sm31", "sm32", "sm33", "sm34", "sm35", "sm36", "sm37", "sm38", "sm39", "sm40", "sm41", "sm42", "sm43"};
    public static int[] popular_smileys_res = {R.string.sm0, R.string.sm1, R.string.sm2, R.string.sm3, R.string.sm4, R.string.sm5, R.string.sm6, R.string.sm7, R.string.sm8, R.string.sm9, R.string.sm10, R.string.sm11, R.string.sm12, R.string.sm13, R.string.sm14, R.string.sm15, R.string.sm16, R.string.sm17, R.string.sm18, R.string.sm19, R.string.sm20, R.string.sm21, R.string.sm22, R.string.sm23, R.string.sm24, R.string.sm25, R.string.sm26, R.string.sm27, R.string.sm28, R.string.sm29, R.string.sm30, R.string.sm31, R.string.sm32, R.string.sm33, R.string.sm34, R.string.sm35, R.string.sm36, R.string.sm37, R.string.sm38, R.string.sm39, R.string.sm40, R.string.sm41, R.string.sm42, R.string.sm43};
    public static final String[] PREF_CUSTOME_PUNCTUATION_POPUP = {"punctuation0", "punctuation1", "punctuation2", "punctuation3", "punctuation4", "punctuation5", "punctuation6", "punctuation7", "punctuation8", "punctuation9", "punctuation10", "punctuation11", "punctuation12", "punctuation13"};
    public static int[] PunctuationPopup_res = {R.string.punctuation0, R.string.punctuation1, R.string.punctuation2, R.string.punctuation3, R.string.punctuation4, R.string.punctuation5, R.string.punctuation6, R.string.punctuation7, R.string.punctuation8, R.string.punctuation9, R.string.punctuation10, R.string.punctuation11, R.string.punctuation12, R.string.punctuation13};
    public static final String[] PREF_POPULAR_DOMAIN = {"popular_domain_0", "popular_domain_1", "popular_domain_2", "popular_domain_3", "popular_domain_4", "popular_domain_5"};
    public static int[] popular_domains_res = {R.string.popular_domain_0, R.string.popular_domain_1, R.string.popular_domain_2, R.string.popular_domain_3, R.string.popular_domain_4, R.string.popular_domain_5};
    MediaPlayer mTypePlay = null;
    private Vibrator mVibrator = null;
    private boolean mOkClicked = false;

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        addPreferencesFromResource(R.xml.prefs);
        char[] a = {'h', 'e', 'l', 'p', '_', 's', 'c', 'r', 'e', 'e', 'n'};
        char[] b = {1575, 1604, 1587, 1585, 1575, 1576, ' ', 1575, 1604, 1576, 1593, 1610, 1583};
        findPreference(new String(a)).setTitle(new String(b));
        this.mQuickFixes = (CheckBoxPreference) findPreference(QUICK_FIXES_KEY);
        this.mVoicePreference = (ListPreference) findPreference(VOICE_SETTINGS_KEY);
        this.mSettingsKeyPreference = (ListPreference) findPreference(PREF_SETTINGS_KEY);
        this.mLongPressDelayPreference = (DialogSeekBarPreference) findPreference(PREF_LONG_PRESS_DELAY);
        SharedPreferences prefs = getPreferenceManager().getSharedPreferences();
        HandlePopularDomain(prefs);
        HandleSmileys(prefs);
        HandlePunctuationPopup(prefs);
        HandlePunctuation(prefs);
        prefs.registerOnSharedPreferenceChangeListener(this);
        this.mVoiceModeOff = getString(R.string.voice_mode_off);
        this.mVoiceOn = !prefs.getString(VOICE_SETTINGS_KEY, this.mVoiceModeOff).equals(this.mVoiceModeOff);
        this.mLongPressDelay = prefs.getInt(PREF_LONG_PRESS_DELAY, getResources().getInteger(R.integer.config_long_press_key_timeout));
        this.mLogger = VoiceInputLogger.getLogger(this);
        Preference pref_go_website = findPreference("go_website");
        pref_go_website.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                SettingsActivity.this.openOurStorePage();
                return true;
            }
        });
        Preference pref_send_feedback = findPreference("send_feedback");
        pref_send_feedback.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent emailIntent = new Intent("android.intent.action.SEND");
                Resources res = preference.getContext().getResources();
                String[] aEmailList = {"gggk14k@gmail.com"};
                emailIntent.putExtra("android.intent.extra.EMAIL", aEmailList);
                emailIntent.putExtra("android.intent.extra.SUBJECT", "Alsarab keyboard");
                emailIntent.setType("plain/text");
                emailIntent.putExtra("android.intent.extra.TEXT", "Device : " + Build.DEVICE + "\nVersion:" + Build.VERSION.RELEASE + "\nKeyboard version:" + res.getString(R.string.version_string) + "\n\n");
                try {
                    SettingsActivity.this.startActivity(emailIntent);
                } catch (ActivityNotFoundException e) {
                }
                return true;
            }
        });
        Preference pref_select_background = findPreference("pref_select_background");
        pref_select_background.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction("android.intent.action.GET_CONTENT");
                SettingsActivity.this.startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);
                return true;
            }
        });
        Preference pref_rate_app = findPreference("rate_application");
        pref_rate_app.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                SettingsActivity.this.openOurStorePage();
                return true;
            }
        });
        Preference Pref_suggestion_font_color = findPreference("suggestion_font_color");
        Pref_suggestion_font_color.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Resources res = preference.getContext().getResources();
                AmbilWarnaDialog dialog = new AmbilWarnaDialog(SettingsActivity.this, res.getColor(R.color.candidate_recommended), new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    @Override
                    public void onOk(AmbilWarnaDialog dialog2, int color) {
                        CandidateView.setColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit();
                        editor.putInt("suggestion_font_color", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog2) {
                    }
                });
                dialog.show();
                return true;
            }
        });
        Preference button_color_Pref = findPreference("button_color");
        button_color_Pref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Resources res = preference.getContext().getResources();
                AmbilWarnaDialog dialogbutton = new AmbilWarnaDialog(SettingsActivity.this, res.getColor(R.color.button_color), new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        LatinKeyboardBaseView.setColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit();
                        editor.putInt("button_color", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbutton.show();
                return true;
            }
        });
        Preference Pref_keyboard_background_color = findPreference("keyboard_background_color");
        Pref_keyboard_background_color.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                AmbilWarnaDialog dialogbackgroundColor = new AmbilWarnaDialog(SettingsActivity.this, -16777216, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        AlsarabIME.setKeyboardBackgroundColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit();
                        editor.putInt("keyboard_background_color", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbackgroundColor.show();
                return true;
            }
        });
        Preference Pref_suggestion_bar_color = findPreference(PREF_SUGGESTION_BAR_COLOR);
        Pref_suggestion_bar_color.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                AmbilWarnaDialog dialogbackgroundColor = new AmbilWarnaDialog(SettingsActivity.this, -16777216, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        AlsarabIME.setSuggestionBarColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit();
                        editor.putInt(SettingsActivity.PREF_SUGGESTION_BAR_COLOR, color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbackgroundColor.show();
                return true;
            }
        });
        Preference keyboard_font_symbol_color_new = findPreference("keyboard_font_symbol_color_new");
        keyboard_font_symbol_color_new.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                AmbilWarnaDialog dialogbackgroundColor = new AmbilWarnaDialog(SettingsActivity.this, -1, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    @Override
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        Calibration.mFontSymbolColors = color;
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit();
                        editor.putInt("keyboard_font_symbol_color_new", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbackgroundColor.show();
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        int autoTextSize = AutoText.getSize(getListView());
        if (autoTextSize < 1) {
            ((PreferenceGroup) findPreference(PREDICTION_SETTINGS_KEY)).removePreference(this.mQuickFixes);
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            getPreferenceScreen().removePreference(this.mVoicePreference);
        } else {
            updateVoiceModeSummary();
        }
        updateSettingsKeySummary();
        updateLongPressDelaySummary();
    }

    @Override // android.preference.PreferenceActivity, android.app.ListActivity, android.app.Activity
    protected void onDestroy() {
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
        if ("use_contact_dictionary".equals(key) && prefs.getBoolean(key, false)) {
            askPermission("android.permission.READ_CONTACTS");
        }
        if (key.equals(VOICE_SETTINGS_KEY) && !this.mVoiceOn) {
            if (!prefs.getString(VOICE_SETTINGS_KEY, this.mVoiceModeOff).equals(this.mVoiceModeOff)) {
                showVoiceConfirmation();
            }
        } else if (PREF_VIBRATE_LENGTH.equals(key)) {
            if (this.mVibrator == null) {
                this.mVibrator = AlsarabApp.getVibrator(this);
            }
            this.mVibrateLength = prefs.getInt(PREF_VIBRATE_LENGTH, getResources().getInteger(R.integer.vibrate_duration_ms));
            AlsarabApp.vibrate(this.mVibrator, this.mVibrateLength);
        } else if (PREF_SOUND_VOLUME.equals(key) || PREF_KB_SOUND_STYLE.equals(key)) {
            String soundStyle = prefs.getString(PREF_KB_SOUND_STYLE, getString(R.string.sound_android));
            if ((PREF_SOUND_VOLUME.equals(key) && this.mTypePlay == null) || PREF_KB_SOUND_STYLE.equals(key)) {
                if (this.mTypePlay != null) {
                    this.mTypePlay.release();
                }
                if (soundStyle.equals(getString(R.string.sound_android))) {
                    this.path = "android.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_pop))) {
                    this.path = "pop.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_soft))) {
                    this.path = "soft.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_tock))) {
                    this.path = "tock.ogg";
                } else {
                    this.path = "android.ogg";
                }
                if (this.path != null) {
                    this.mTypePlay = new MediaPlayer();
                    this.mTypePlay.setAudioStreamType(1);
                    try {
                        AssetFileDescriptor descriptor = getAssets().openFd(this.path);
                        this.mTypePlay.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                        descriptor.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    } catch (IllegalArgumentException e7) {
                        e7.printStackTrace();
                    } catch (IllegalStateException e8) {
                        e8.printStackTrace();
                    }
                    try {
                        this.mTypePlay.prepare();
                    } catch (IOException e9) {
                        e9.printStackTrace();
                    } catch (IllegalStateException e10) {
                        e10.printStackTrace();
                    }
                }
            }
            if (PREF_SOUND_VOLUME.equals(key)) {
                this.mSoundVolume = prefs.getInt(PREF_SOUND_VOLUME, getResources().getInteger(R.integer.config_defalut_sound_volume));
                this.mTypePlay.setVolume(this.mSoundVolume / 100.0f, this.mSoundVolume / 100.0f);
                this.mTypePlay.start();
            }
        }
        if (DISPLAY_LUNCHER_ICON.equals(key)) {
            PackageManager pm = getPackageManager();
            String packagename = getBaseContext().getPackageName();
            this.mShowIcon = prefs.getBoolean(DISPLAY_LUNCHER_ICON, true);
            if (this.mShowIcon) {
                pm.setComponentEnabledSetting(new ComponentName(packagename, "keyboard.alsarab.albaid.ime.MainActivity"), 0, 1);
            } else {
                pm.setComponentEnabledSetting(new ComponentName(packagename, "keyboard.alsarab.albaid.ime.MainActivity"), 2, 1);
            }
        }
        this.mVoiceOn = !prefs.getString(VOICE_SETTINGS_KEY, this.mVoiceModeOff).equals(this.mVoiceModeOff);
        this.mLongPressDelay = prefs.getInt(PREF_LONG_PRESS_DELAY, getResources().getInteger(R.integer.config_long_press_key_timeout));
        updateVoiceModeSummary();
        updateSettingsKeySummary();
        updateLongPressDelaySummary();
        HandlePopularDomain(prefs);
        HandleSmileys(prefs);
        HandlePunctuationPopup(prefs);
        HandlePunctuation(prefs);
    }

    private void updateSettingsKeySummary() {
        this.mSettingsKeyPreference.setSummary(getResources().getStringArray(R.array.settings_key_modes)[this.mSettingsKeyPreference.findIndexOfValue(this.mSettingsKeyPreference.getValue())]);
    }

    private void updateLongPressDelaySummary() {
        this.mLongPressDelayPreference.setSummary(String.format(getResources().getString(R.string.long_press_delay_summary), Integer.valueOf(this.mLongPressDelay)));
    }

    private void askPermission(String permission) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{permission}, 92);
        }
    }

    private void showVoiceConfirmation() {
        this.mOkClicked = false;
        showDialog(0);
    }

    private void updateVoiceModeSummary() {
        this.mVoicePreference.setSummary(getResources().getStringArray(R.array.voice_input_modes_summary)[this.mVoicePreference.findIndexOfValue(this.mVoicePreference.getValue())]);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case 0:
                DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if (whichButton == -2) {
                            SettingsActivity.this.mVoicePreference.setValue(SettingsActivity.this.mVoiceModeOff);
                            SettingsActivity.this.mLogger.settingsWarningDialogCancel();
                        } else if (whichButton == -1) {
                            SettingsActivity.this.mOkClicked = true;
                            SettingsActivity.this.mLogger.settingsWarningDialogOk();
                        }
                        SettingsActivity.this.updateVoicePreference();
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle(R.string.voice_warning_title).setPositiveButton(android.R.string.ok, listener).setNegativeButton(android.R.string.cancel, listener);
                String supportedLocalesString = SettingsUtil.getSettingsString(getContentResolver(), SettingsUtil.LATIN_IME_VOICE_INPUT_SUPPORTED_LOCALES, AlsarabIME.DEFAULT_VOICE_INPUT_SUPPORTED_LOCALES);
                ArrayList<String> voiceInputSupportedLocales = AlsarabIME.newArrayList(supportedLocalesString.split("\\s+"));
                boolean localeSupported = voiceInputSupportedLocales.contains(Locale.getDefault().toString());
                if (localeSupported) {
                    String message = String.valueOf(getString(R.string.voice_warning_may_not_understand)) + "\n\n" + getString(R.string.voice_hint_dialog_message);
                    builder.setMessage(message);
                } else {
                    String message2 = String.valueOf(getString(R.string.voice_warning_locale_not_supported)) + "\n\n" + getString(R.string.voice_warning_may_not_understand) + "\n\n" + getString(R.string.voice_hint_dialog_message);
                    builder.setMessage(message2);
                }
                AlertDialog dialog = builder.create();
                dialog.setOnDismissListener(this);
                this.mLogger.settingsWarningDialogShown();
                return dialog;
            default:
                Log.e(TAG, "unknown dialog " + id);
                return null;
        }
    }


    @Override
    public void onDismiss(DialogInterface dialog) {
        this.mLogger.settingsWarningDialogDismissed();
        if (!this.mOkClicked) {
            this.mVoicePreference.setValue(this.mVoiceModeOff);
        }
    }

    public void updateVoicePreference() {
        boolean isChecked = !this.mVoicePreference.getValue().equals(this.mVoiceModeOff);
        if (isChecked) {
            this.mLogger.voiceInputSettingEnabled();
        } else {
            this.mLogger.voiceInputSettingDisabled();
        }
    }

    private void HandlePopularDomain(SharedPreferences prefs) {
        for (int i = 0; i < 6; i++) {
            String DefaultString = getString(popular_domains_res[i]);
            String temp = prefs.getString(PREF_POPULAR_DOMAIN[i], getString(popular_domains_res[i]));
            this.popularDomains = (EditTextPreference) findPreference(PREF_POPULAR_DOMAIN[i]);
            if (temp.equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                temp = DefaultString;
            }
            this.popularDomains.setText(temp);
            this.popularDomains.setTitle(temp);
            LatinKeyboardBaseView.popularDomains[i] = this.popularDomains.getText();
        }
    }

    private void HandleSmileys(SharedPreferences prefs) {
        for (int i = 0; i < 44; i++) {
            String DefaultString = getString(popular_smileys_res[i]);
            String temp = prefs.getString(PREF_CUSTOME_SMILEYS[i], getString(popular_smileys_res[i]));
            this.CustomSmileys = (EditTextPreference) findPreference(PREF_CUSTOME_SMILEYS[i]);
            if (temp.equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                temp = DefaultString;
            }
            this.CustomSmileys.setText(temp);
            this.CustomSmileys.setTitle(temp);
            LatinKeyboardBaseView.CustomSmileys[i] = this.CustomSmileys.getText();
        }
    }

    private void HandlePunctuationPopup(SharedPreferences prefs) {
        for (int i = 0; i < 13; i++) {
            String DefaultString = getString(PunctuationPopup_res[i]);
            String temp = prefs.getString(PREF_CUSTOME_PUNCTUATION_POPUP[i], getString(PunctuationPopup_res[i]));
            this.CustomPunctuationPopup = (EditTextPreference) findPreference(PREF_CUSTOME_PUNCTUATION_POPUP[i]);
            if (temp.equals(LoggingEvents.EXTRA_CALLING_APP_NAME) || temp.length() != 1) {
                temp = DefaultString;
            }
            this.CustomPunctuationPopup.setText(temp);
            this.CustomPunctuationPopup.setTitle(temp);
            LatinKeyboardBaseView.CustomPunctuationPopup[i] = this.CustomPunctuationPopup.getText();
        }
    }

    private void HandlePunctuation(SharedPreferences prefs) {
        String temp = prefs.getString(PREF_PUNCTUATION_EDITOR, getString(R.string.suggested_punctuations));
        this.customePunctuation = (EditTextPreference) findPreference(PREF_PUNCTUATION_EDITOR);
        this.customePunctuation.setText(temp);
        this.customePunctuation.setTitle(temp);
    }





    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        switch (requestCode) {
            case 0:
                if (resultCode == -1) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
                    editor.putString(Calibration.PREF_URI_BACKGROUND_IMAGE, selectedImage.toString());
                    SharedPreferencesCompat.apply(editor);
                    return;
                }
                return;
            default:
                return;
        }
    }
}
