#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Builds a keyboard word-list in the binary format read by DictionaryEngine
(magic 0x78B1).

Usage:
  python3 build_dictionary.py --corpus ar_full.txt --min-count 30 \
        --extra iraqi_words.txt --out ../app/src/main/res/raw-ar/en_binary.mp3

  --corpus   text file, one "word count" pair per line (e.g. FrequencyWords "ar_full.txt")
  --extra    optional "word<TAB>freq(1-255)" lists with hand-picked words (dialect, names ...)
  --verify   re-reads the produced file and checks every word is present

The resource is deliberately called en_binary.mp3: the app looks the main dictionary up by
that name and lets Android's resource qualifiers pick the language (raw-ar/ for Arabic).
The ".mp3" extension keeps aapt from compressing the file, which the app needs because it
reads the dictionary straight out of the APK.
"""
import argparse
import collections
import math
import re
import sys

AR_LETTERS = re.compile(
    r'^[\u0621-\u063A\u0641-\u064A\u067E\u0686\u06AF\u06A4\u0698]+$')
TASHKEEL = re.compile(r'[\u064B-\u065F\u0670\u0640]')
THREE_RUN = re.compile(r'(.)\1\1')


def clean(word, min_len=2, max_len=24):
    word = TASHKEEL.sub('', word.strip())
    if not (min_len <= len(word) <= max_len):
        return None
    if not AR_LETTERS.match(word):
        return None
    if THREE_RUN.search(word):
        return None
    return word


def load_corpus(path, min_count):
    agg = collections.Counter()
    with open(path, encoding='utf8') as f:
        for line in f:
            parts = line.rstrip('\n').split(' ')
            if len(parts) != 2:
                continue
            w = clean(parts[0])
            if w is None:
                continue
            try:
                agg[w] += int(parts[1])
            except ValueError:
                continue
    return {w: c for w, c in agg.items() if c >= min_count}


def to_freq(counts):
    """Log-scale the counts to 1..255 (the range the original format stores)."""
    lo, hi = min(counts.values()), max(counts.values())
    span = math.log(hi / lo) or 1.0
    return {w: max(1, min(255, int(round(1 + 254 * math.log(c / lo) / span))))
            for w, c in counts.items()}


def load_extra(path):
    out = {}
    with open(path, encoding='utf8') as f:
        for line in f:
            line = line.rstrip('\n')
            if not line or line.startswith('#'):
                continue
            w, _, fr = line.partition('\t')
            w = clean(w, min_len=1)
            if w is None:
                print('skipped (invalid characters): %r' % line, file=sys.stderr)
                continue
            out[w] = max(out.get(w, 0), max(1, min(255, int(fr))))
    return out


# ----------------------------------------------------------------------------- trie

class Node:
    __slots__ = ('kids', 'freq')

    def __init__(self):
        self.kids = {}      # char -> Node
        self.freq = None    # terminal frequency


def build_trie(words):
    root = Node()
    for w, fr in words.items():
        n = root
        for ch in w:
            n = n.kids.setdefault(ch, Node())
        n.freq = fr
    return root


class Group:
    __slots__ = ('chars', 'freq', 'child', 'off', 'field_off')

    def __init__(self, chars, freq, child):
        self.chars, self.freq, self.child = chars, freq, child


class Out:
    __slots__ = ('groups', 'off')

    def __init__(self, groups):
        self.groups, self.off = groups, 0


def compress(node):
    """Turns a trie node into an Out node, merging single-child chains into one group."""
    groups = []
    for ch in sorted(node.kids):
        chars = [ch]
        cur = node.kids[ch]
        while cur.freq is None and len(cur.kids) == 1:
            (nch, nxt), = cur.kids.items()
            chars.append(nch)
            cur = nxt
        child = compress(cur) if cur.kids else None
        groups.append(Group(chars, cur.freq, child))
    return Out(groups)


def char_bytes(c):
    if 0x20 <= c <= 0xFF:
        return bytes([c])
    return bytes([(c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF])


def group_size(g):
    n = 1                                           # flags
    n += sum(len(char_bytes(ord(c))) for c in g.chars)
    if len(g.chars) > 1:
        n += 1                                      # 0x1F terminator
    if g.freq is not None:
        n += 1
    if g.child is not None:
        n += 3                                      # always a 3 byte address
    return n


def node_size(o):
    cnt = len(o.groups)
    return (1 if cnt < 0x80 else 2) + sum(group_size(g) for g in o.groups)


def serialize(root_out):
    # breadth first layout: every child is stored after its parent, so addresses are positive
    order, queue = [], [root_out]
    while queue:
        o = queue.pop(0)
        order.append(o)
        for g in o.groups:
            if g.child is not None:
                queue.append(g.child)
    pos = 5
    for o in order:
        o.off = pos
        pos += node_size(o)
    if pos >= 0x7FFFFF:
        raise SystemExit('dictionary too large for 3 byte addresses (%d bytes)' % pos)
    buf = bytearray(b'\x78\xb1\x01\x00\x00')
    for o in order:
        assert len(buf) == o.off
        cnt = len(o.groups)
        if cnt < 0x80:
            buf.append(cnt)
        else:
            buf += bytes([0x80 | (cnt >> 8), cnt & 0xFF])
        for g in o.groups:
            flags = 0
            if len(g.chars) > 1:
                flags |= 0x20
            if g.freq is not None:
                flags |= 0x10
            if g.child is not None:
                flags |= 0xC0
            buf.append(flags)
            for c in g.chars:
                buf += char_bytes(ord(c))
            if len(g.chars) > 1:
                buf.append(0x1F)
            if g.freq is not None:
                buf.append(g.freq)
            if g.child is not None:
                field = len(buf)
                rel = g.child.off - field
                assert 0 < rel < 0x7FFFFF
                buf += bytes([(rel >> 16) & 0xFF, (rel >> 8) & 0xFF, rel & 0xFF])
    return bytes(buf)


# ----------------------------------------------------------------------------- verify

def read_words(data):
    """Independent re-implementation of the reader, used only to verify the output."""
    assert data[:2] == b'\x78\xb1'
    sys.setrecursionlimit(10000)
    words = {}

    def rc(p):
        b = data[p]
        if b >= 0x20:
            return b, p + 1
        return (b << 16) | (data[p + 1] << 8) | data[p + 2], p + 3

    def walk(p, prefix):
        c = data[p]
        if c & 0x80:
            n, p = ((c & 0x7F) << 8) | data[p + 1], p + 2
        else:
            n, p = c, p + 1
        for _ in range(n):
            flags = data[p]
            p += 1
            ch, p = rc(p)
            chars = [ch]
            if flags & 0x20:
                while data[p] != 0x1F:
                    ch, p = rc(p)
                    chars.append(ch)
                p += 1
            fr = None
            if flags & 0x10:
                fr = data[p]
                p += 1
            child = None
            at = (flags >> 6) & 3
            if at:
                fs, v = p, 0
                for i in range(at):
                    v = (v << 8) | data[p + i]
                p += at
                child = fs + v
            w = prefix + ''.join(chr(x) for x in chars)
            if fr is not None:
                words[w] = fr
            if child:
                walk(child, w)

    walk(5, '')
    return words


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--corpus', required=True)
    ap.add_argument('--min-count', type=int, default=30)
    ap.add_argument('--extra', action='append', default=[])
    ap.add_argument('--out', required=True)
    ap.add_argument('--verify', action='store_true')
    a = ap.parse_args()

    counts = load_corpus(a.corpus, a.min_count)
    words = to_freq(counts)
    print('corpus words kept: %d' % len(words))
    for path in a.extra:
        extra = load_extra(path)
        for w, fr in extra.items():
            words[w] = max(words.get(w, 0), fr)
        print('extra words from %s: %d' % (path, len(extra)))

    data = serialize(compress(build_trie(words)))
    with open(a.out, 'wb') as f:
        f.write(data)
    print('wrote %s: %d words, %d bytes (%.1f bytes/word)'
          % (a.out, len(words), len(data), len(data) / len(words)))

    if a.verify:
        back = read_words(data)
        missing = [w for w in words if back.get(w) != words[w]]
        extra_w = [w for w in back if w not in words]
        print('verify: %d mismatching, %d unexpected' % (len(missing), len(extra_w)))
        if missing or extra_w:
            raise SystemExit(1)
        print('verify OK')


if __name__ == '__main__':
    main()
