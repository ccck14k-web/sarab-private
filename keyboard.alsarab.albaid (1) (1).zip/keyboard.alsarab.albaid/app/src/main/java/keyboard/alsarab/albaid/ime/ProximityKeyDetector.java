package keyboard.alsarab.albaid.ime;

import android.inputmethodservice.Keyboard;
import java.util.Arrays;

class ProximityKeyDetector extends KeyDetector {
    private static final int MAX_NEARBY_KEYS = 18;
    private int[] mDistances = new int[18];

    @Override
    protected int getMaxNearbyKeys() {
        return 18;
    }

    @Override
    public int getKeyIndexAndNearbyCodes(int x, int y, int[] allKeys) {
        Keyboard.Key[] keys = getKeys();
        int touchX = getTouchX(x);
        int touchY = getTouchY(y);
        int primaryIndex = -1;
        int closestKey = -1;
        int closestKeyDist = this.mProximityThresholdSquare + 1;
        int[] distances = this.mDistances;
        Arrays.fill(distances, Integer.MAX_VALUE);
        int[] nearestKeyIndices = this.mKeyboard.getNearestKeys(touchX, touchY);
        int keyCount = nearestKeyIndices.length;
        for (int i = 0; i < keyCount; i++) {
            Keyboard.Key key = keys[nearestKeyIndices[i]];
            int dist = 0;
            boolean isInside = key.isInside(touchX, touchY);
            if (isInside) {
                primaryIndex = nearestKeyIndices[i];
            }
            if ((this.mProximityCorrectOn && (dist = key.squaredDistanceFrom(touchX, touchY)) < this.mProximityThresholdSquare) || isInside) {
                int nCodes = key.codes.length;
                if (dist < closestKeyDist) {
                    closestKeyDist = dist;
                    closestKey = nearestKeyIndices[i];
                }
                if (allKeys != null) {
                    int j = 0;
                    while (true) {
                        if (j >= distances.length - nCodes) {
                            break;
                        }
                        if (distances[j] <= dist) {
                            j++;
                        } else {
                            System.arraycopy(distances, j, distances, j + nCodes, (distances.length - j) - nCodes);
                            System.arraycopy(allKeys, j, allKeys, j + nCodes, (allKeys.length - j) - nCodes);
                            System.arraycopy(key.codes, 0, allKeys, j, nCodes);
                            Arrays.fill(distances, j, j + nCodes, dist);
                            break;
                        }
                    }
                }
            }
        }
        if (primaryIndex == -1) {
            int primaryIndex2 = closestKey;
            return primaryIndex2;
        }
        return primaryIndex;
    }
}
