package keyboard.alsarab.albaid.ime;

import android.R;
import android.app.ListActivity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import keyboard.alsarab.albaid.common.speech.LoggingEvents;
import keyboard.alsarab.albaid.ime.WordInfo;
import java.util.ArrayList;

public class SkinSelector extends ListActivity {
    String goToMarket = "تحميل ثيمات اكثر";
    String[] names = {"Basic", "Alsarab1", "IceCreamSandwich", "Stone (normal)", "Gingerbread", "Alsarab2", "HTC", "Alsarab3", "Alsarab4"};
    private WordInfo.SkinData skinsData;

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        WordInfo.resetBuildersCache();
        WordInfo.getAllBuilders(getBaseContext());
        ArrayList<String> Skins = WordInfo.getSkinsNames();
        for (int i = 0; i < this.names.length; i++) {
            Skins.add(0, this.names[(this.names.length - i) - 1]);
        }
        Skins.add(this.goToMarket);
        setListAdapter(new ArrayAdapter(this, R.layout.simple_list_item_1, Skins));
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Object o = getListAdapter().getItem(position);
        String keyword = o.toString();
        boolean InternalSkinSelected = false;
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sp.edit();
        Integer i = 0;
        while (true) {
            if (i.intValue() >= this.names.length) {
                break;
            }
            if (!keyword.equals(this.names[i.intValue()])) {
                i = Integer.valueOf(i.intValue() + 1);
            } else {
                InternalSkinSelected = true;
                editor.putString(Calibration.PREF_KEYBOARD_LAYOUT, i.toString());
                editor.putString("external_skin", LoggingEvents.EXTRA_CALLING_APP_NAME);
                break;
            }
        }
        if (!InternalSkinSelected) {
            if (keyword.equals(this.goToMarket)) {
                Intent goToMarket = new Intent("android.intent.action.VIEW", Uri.parse("https://ap9ap.com"));
                goToMarket.setFlags(268435456);
                try {
                    startActivity(goToMarket);
                    return;
                } catch (ActivityNotFoundException e) {
                    return;
                }
            }
            editor.putString("external_skin", keyword);
        }
        editor.commit();
        Toast.makeText(this, "انت اخترت :" + keyword, 1).show();
    }
}
