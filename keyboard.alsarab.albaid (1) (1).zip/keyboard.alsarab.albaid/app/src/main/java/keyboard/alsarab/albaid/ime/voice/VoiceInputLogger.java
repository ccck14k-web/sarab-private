package keyboard.alsarab.albaid.ime.voice;

import android.content.Context;
import android.content.Intent;
import keyboard.alsarab.albaid.common.speech.LoggingEvents;
import keyboard.alsarab.albaid.common.userhappiness.UserHappinessSignals;

public class VoiceInputLogger {
    private static final String TAG = VoiceInputLogger.class.getSimpleName();
    private static VoiceInputLogger sVoiceInputLogger;
    private final Context mContext;
    private boolean mHasLoggingInfo = false;
    private final Intent mBaseIntent = new Intent(LoggingEvents.ACTION_LOG_EVENT);

    public static synchronized VoiceInputLogger getLogger(Context contextHint) {
        VoiceInputLogger voiceInputLogger;
        synchronized (VoiceInputLogger.class) {
            if (sVoiceInputLogger == null) {
                sVoiceInputLogger = new VoiceInputLogger(contextHint);
            }
            voiceInputLogger = sVoiceInputLogger;
        }
        return voiceInputLogger;
    }

    public VoiceInputLogger(Context context) {
        this.mContext = context;
        this.mBaseIntent.putExtra(LoggingEvents.EXTRA_APP_NAME, LoggingEvents.VoiceIme.APP_NAME);
    }

    /** Voice usage events are intentionally not sent anywhere; nothing leaves the device. */
    private void dispatch(Intent event) {
    }

    private Intent newLoggingBroadcast(int event) {
        Intent i = new Intent(this.mBaseIntent);
        i.putExtra(LoggingEvents.EXTRA_EVENT, event);
        return i;
    }

    public void flush() {
        if (hasLoggingInfo()) {
            Intent i = new Intent(this.mBaseIntent);
            i.putExtra(LoggingEvents.EXTRA_FLUSH, true);
            dispatch(i);
            setHasLoggingInfo(false);
        }
    }

    public void keyboardWarningDialogShown() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(0));
    }

    public void keyboardWarningDialogDismissed() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(1));
    }

    public void keyboardWarningDialogOk() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(2));
    }

    public void keyboardWarningDialogCancel() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(3));
    }

    public void settingsWarningDialogShown() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(4));
    }

    public void settingsWarningDialogDismissed() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(5));
    }

    public void settingsWarningDialogOk() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(6));
    }

    public void settingsWarningDialogCancel() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(7));
    }

    public void swipeHintDisplayed() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(8));
    }

    public void cancelDuringListening() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(10));
    }

    public void cancelDuringWorking() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(11));
    }

    public void cancelDuringError() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(12));
    }

    public void punctuationHintDisplayed() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(9));
    }

    public void error(int code) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(13);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_ERROR_CODE, code);
        dispatch(i);
    }

    public void start(String locale, boolean swipe) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(14);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_START_LOCALE, locale);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_START_SWIPE, swipe);
        i.putExtra(LoggingEvents.EXTRA_TIMESTAMP, System.currentTimeMillis());
        dispatch(i);
    }

    public void voiceInputDelivered(int length) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(15);
        i.putExtra("length", length);
        dispatch(i);
    }

    public void textModifiedByTypingInsertion(int length) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(17);
        i.putExtra("length", length);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_TYPE, 3);
        dispatch(i);
    }

    public void textModifiedByTypingInsertionPunctuation(int length) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(17);
        i.putExtra("length", length);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_TYPE, 4);
        dispatch(i);
    }

    public void textModifiedByTypingDeletion(int length) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(17);
        i.putExtra("length", length);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_TYPE, 2);
        dispatch(i);
    }

    public void textModifiedByChooseSuggestion(int suggestionLength, int replacedPhraseLength, int index, String before, String after) {
        setHasLoggingInfo(true);
        Intent i = newLoggingBroadcast(17);
        i.putExtra(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_TYPE, 1);
        i.putExtra("length", suggestionLength);
        i.putExtra("index", index);
        dispatch(i);
    }

    public void inputEnded() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(18));
    }

    public void voiceInputSettingEnabled() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(19));
    }

    public void voiceInputSettingDisabled() {
        setHasLoggingInfo(true);
        dispatch(newLoggingBroadcast(20));
    }

    private void setHasLoggingInfo(boolean hasLoggingInfo) {
        this.mHasLoggingInfo = hasLoggingInfo;
        UserHappinessSignals.setHasVoiceLoggingInfo(hasLoggingInfo);
    }

    private boolean hasLoggingInfo() {
        return this.mHasLoggingInfo;
    }
}
