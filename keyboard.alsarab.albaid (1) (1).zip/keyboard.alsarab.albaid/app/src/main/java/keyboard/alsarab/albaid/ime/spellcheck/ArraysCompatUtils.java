package keyboard.alsarab.albaid.ime.spellcheck;

import java.util.Arrays;

public class ArraysCompatUtils {
    public static int binarySearch(int[] array, int startIndex, int endIndex, int value) {
        return compatBinarySearch(array, startIndex, endIndex, value);
    }

    static int compatBinarySearch(int[] array, int startIndex, int endIndex, int value) {
        if (startIndex > endIndex) {
            throw new IllegalArgumentException();
        }
        if (startIndex < 0 || endIndex > array.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int[] work = new int[endIndex - startIndex];
        System.arraycopy(array, startIndex, work, 0, work.length);
        int index = Arrays.binarySearch(work, value);
        return index >= 0 ? index + startIndex : ((index ^ (-1)) + startIndex) ^ (-1);
    }
}
