package keyboard.alsarab.albaid.ime;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.StaticLayout;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.TextView;
import keyboard.alsarab.albaid.R;
import java.util.ArrayList;
import java.util.List;

public class Tutorial implements View.OnTouchListener {
    private static final int MSG_SHOW_BUBBLE = 0;
    private int mBubbleIndex;
    private AlsarabIME mIme;
    private View mInputView;
    private List<Bubble> mBubbles = new ArrayList();
    private int[] mLocation = new int[2];
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    Bubble bubba = (Bubble) msg.obj;
                    bubba.show(Tutorial.this.mLocation[0], Tutorial.this.mLocation[1]);
                    return;
                default:
                    return;
            }
        }
    };

    public class Bubble {
        Drawable bubbleBackground;
        View inputView;
        CharSequence text;
        TextView textView;
        int width;
        PopupWindow window;
        int x;
        int y;
        int gravity = 51;
        boolean dismissOnTouch = true;
        boolean dismissOnClose = false;

        Bubble(Context context, View inputView, int backgroundResource, int bx, int by, int textResource1, int textResource2) {
            this.bubbleBackground = context.getResources().getDrawable(backgroundResource);
            this.x = bx;
            this.y = by;
            this.width = (int) (inputView.getWidth() * 0.9d);
            this.text = new SpannableStringBuilder().append(context.getResources().getText(textResource1)).append((CharSequence) "\n").append(context.getResources().getText(textResource2));
            this.inputView = inputView;
            this.window = new PopupWindow(context);
            this.window.setBackgroundDrawable(null);
            LayoutInflater inflate = (LayoutInflater) context.getSystemService("layout_inflater");
            this.textView = (TextView) inflate.inflate(R.layout.bubble_text, (ViewGroup) null);
            this.textView.setBackgroundDrawable(this.bubbleBackground);
            this.textView.setText(this.text);
            this.window.setContentView(this.textView);
            this.window.setFocusable(false);
            this.window.setTouchable(true);
            this.window.setOutsideTouchable(false);
        }

        private int chooseSize(PopupWindow pop, View parentView, CharSequence text, TextView tv) {
            int wid = tv.getPaddingLeft() + tv.getPaddingRight();
            int ht = tv.getPaddingTop() + tv.getPaddingBottom();
            int cap = this.width - wid;
            Layout l = new StaticLayout(text, tv.getPaint(), cap, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            float max = 0.0f;
            for (int i = 0; i < l.getLineCount(); i++) {
                max = Math.max(max, l.getLineWidth(i));
            }
            pop.setWidth(this.width);
            pop.setHeight(l.getHeight() + ht);
            return l.getHeight();
        }

        void show(int offx, int offy) {
            int textHeight = chooseSize(this.window, this.inputView, this.text, this.textView);
            int offy2 = offy - (this.textView.getPaddingTop() + textHeight);
            if (this.inputView.getVisibility() == 0 && this.inputView.getWindowVisibility() == 0) {
                try {
                    if ((this.gravity & 80) == 80) {
                        offy2 -= this.window.getHeight();
                    }
                    if ((this.gravity & 5) == 5) {
                        offx -= this.window.getWidth();
                    }
                    this.textView.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View view, MotionEvent me) {
                            Tutorial.this.next();
                            return true;
                        }
                    });
                    this.window.showAtLocation(this.inputView, 0, this.x + offx, this.y + offy2);
                } catch (Exception e) {
                }
            }
        }

        void hide() {
            if (this.window.isShowing()) {
                this.textView.setOnTouchListener(null);
                this.window.dismiss();
            }
        }

        boolean isShowing() {
            return this.window.isShowing();
        }
    }

    public Tutorial(AlsarabIME ime, LatinKeyboardView inputView) {
        Context context = inputView.getContext();
        this.mIme = ime;
        int inputWidth = inputView.getWidth();
        int x = inputWidth / 20;
        Bubble bWelcome = new Bubble(context, inputView, R.drawable.dialog_bubble_step02, x, 0, R.string.tip_to_open_keyboard, R.string.touch_to_continue);
        this.mBubbles.add(bWelcome);
        Bubble bAccents = new Bubble(context, inputView, R.drawable.dialog_bubble_step02, x, 0, R.string.tip_to_view_accents, R.string.touch_to_continue);
        this.mBubbles.add(bAccents);
        Bubble b123 = new Bubble(context, inputView, R.drawable.dialog_bubble_step07, x, 0, R.string.tip_to_open_symbols, R.string.touch_to_continue);
        this.mBubbles.add(b123);
        Bubble bABC = new Bubble(context, inputView, R.drawable.dialog_bubble_step07, x, 0, R.string.tip_to_close_symbols, R.string.touch_to_continue);
        this.mBubbles.add(bABC);
        Bubble bSettings = new Bubble(context, inputView, R.drawable.dialog_bubble_step07, x, 0, R.string.tip_to_launch_settings, R.string.touch_to_continue);
        this.mBubbles.add(bSettings);
        Bubble bDone = new Bubble(context, inputView, R.drawable.dialog_bubble_step02, x, 0, R.string.tip_to_start_typing, R.string.touch_to_finish);
        this.mBubbles.add(bDone);
        this.mInputView = inputView;
    }

    public void start() {
        this.mInputView.getLocationInWindow(this.mLocation);
        this.mBubbleIndex = -1;
        this.mInputView.setOnTouchListener(this);
        next();
    }

    boolean next() {
        if (this.mBubbleIndex >= 0) {
            if (!this.mBubbles.get(this.mBubbleIndex).isShowing()) {
                return true;
            }
            for (int i = 0; i <= this.mBubbleIndex; i++) {
                this.mBubbles.get(i).hide();
            }
        }
        this.mBubbleIndex++;
        if (this.mBubbleIndex >= this.mBubbles.size()) {
            this.mInputView.setOnTouchListener(null);
            this.mIme.sendDownUpKeyEvents(-1);
            this.mIme.tutorialDone();
            return false;
        }
        if (this.mBubbleIndex == 3 || this.mBubbleIndex == 4) {
            this.mIme.mCalibration.toggleSymbols(true);
        }
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(0, this.mBubbles.get(this.mBubbleIndex)), 500L);
        return true;
    }

    void hide() {
        for (int i = 0; i < this.mBubbles.size(); i++) {
            this.mBubbles.get(i).hide();
        }
        this.mInputView.setOnTouchListener(null);
    }

    public boolean close() {
        this.mHandler.removeMessages(0);
        hide();
        return true;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == 0) {
            next();
            return true;
        }
        return true;
    }
}
