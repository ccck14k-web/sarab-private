package keyboard.alsarab.albaid.ime;

import android.content.Context;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.util.Log;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SuggestionSpanUtils {
    public static final String ACTION_SUGGESTION_PICKED = "android.text.style.SUGGESTION_PICKED";
    public static final int FLAG_AUTO_CORRECTION = 4;
    public static final int SUGGESTION_MAX_SIZE = 5;
    public static final boolean SUGGESTION_SPAN_IS_SUPPORTED;
    public static final String SUGGESTION_SPAN_PICKED_AFTER = "after";
    public static final String SUGGESTION_SPAN_PICKED_BEFORE = "before";
    public static final String SUGGESTION_SPAN_PICKED_HASHCODE = "hashcode";
    private static final String TAG = SuggestionSpanUtils.class.getSimpleName();
    private static final Class<?> CLASS_SuggestionSpan = CompatUtils.getClass("android.text.style.SuggestionSpan");
    private static final Class<?>[] INPUT_TYPE_SuggestionSpan = {Context.class, Locale.class, String[].class, Integer.TYPE, Class.class};
    private static final Constructor<?> CONSTRUCTOR_SuggestionSpan = CompatUtils.getConstructor(CLASS_SuggestionSpan, INPUT_TYPE_SuggestionSpan);

    static {
        SUGGESTION_SPAN_IS_SUPPORTED = (CLASS_SuggestionSpan == null || CONSTRUCTOR_SuggestionSpan == null) ? false : true;
    }

    public static CharSequence getTextWithAutoCorrectionIndicatorUnderline(Context context, CharSequence text) {
        if (!TextUtils.isEmpty(text) && CONSTRUCTOR_SuggestionSpan != null) {
            Spannable spannable = text instanceof Spannable ? (Spannable) text : new SpannableString(text);
            Object[] args = new Object[5];
            args[0] = context;
            args[2] = new String[0];
            args[3] = 4;
            args[4] = SuggestionSpanPickedNotificationReceiver.class;
            Object ss = CompatUtils.newInstance(CONSTRUCTOR_SuggestionSpan, args);
            if (ss == null) {
                Log.w(TAG, "Suggestion span was not created.");
                return text;
            }
            spannable.setSpan(ss, 0, text.length(), 289);
            return spannable;
        }
        return text;
    }

    public static CharSequence getTextWithSuggestionSpan(Context context, CharSequence pickedWord, List<CharSequence> suggestedWords) {
        Spannable spannable;
        if (!TextUtils.isEmpty(pickedWord) && CONSTRUCTOR_SuggestionSpan != null && suggestedWords != null && suggestedWords.size() != 0) {
            if (pickedWord instanceof Spannable) {
                spannable = (Spannable) pickedWord;
            } else {
                spannable = new SpannableString(pickedWord);
            }
            ArrayList<String> suggestionsList = new ArrayList<>();
            for (int i = 0; i < suggestedWords.size() && suggestionsList.size() < 5; i++) {
                CharSequence word = suggestedWords.get(i);
                if (!TextUtils.equals(pickedWord, word)) {
                    suggestionsList.add(word.toString());
                }
            }
            Object[] args = new Object[5];
            args[0] = context;
            args[2] = suggestionsList.toArray(new String[suggestionsList.size()]);
            args[3] = 0;
            args[4] = SuggestionSpanPickedNotificationReceiver.class;
            Object ss = CompatUtils.newInstance(CONSTRUCTOR_SuggestionSpan, args);
            if (ss != null) {
                spannable.setSpan(ss, 0, pickedWord.length(), 33);
                return spannable;
            }
            return pickedWord;
        }
        return pickedWord;
    }
}
