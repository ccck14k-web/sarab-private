package keyboard.alsarab.albaid.ime;

import android.content.Context;
import android.util.Log;
import keyboard.alsarab.albaid.ime.Dictionary;
import keyboard.alsarab.albaid.R;
import java.util.Arrays;

public class BinaryDictionary extends Dictionary {
    public static final String DICTIONARY_PACK_AUTHORITY = "keyboard.alsarab.albaid.ime.dictionarypack";
    private static final int MAX_BIGRAMS = 60;
    private static final int MAX_PROXIMITY_CHARS_SIZE = 16;
    public static final int MAX_WORDS = 18;
    public static final int MAX_WORD_LENGTH = 48;
    private static final String TAG = "BinaryDictionary";
    private static final int TYPED_LETTER_MULTIPLIER = 2;
    private int mFlags;
    private DictionaryEngine mEngine;
    public static final Flag FLAG_REQUIRES_GERMAN_UMLAUT_PROCESSING = new Flag(R.bool.config_require_umlaut_processing, 1);
    public static final Flag FLAG_USE_FULL_EDIT_DISTANCE = new Flag(2);
    public static final Flag FLAG_HEBREW_PROCESSING = new Flag(R.bool.config_require_hebrew_processing, 4);
    public static final Flag FLAG_T9MODE_PROCESSING = new Flag(8);
    public static final Flag FLAG_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER = new Flag(22);
    public static final Flag[] ALL_CONFIG_FLAGS = {FLAG_REQUIRES_GERMAN_UMLAUT_PROCESSING, FLAG_HEBREW_PROCESSING};
    private final int[] mInputCodes = new int[768];
    private final char[] mOutputChars = new char[864];
    private final char[] mOutputChars_bigrams = new char[2880];
    private final int[] mScores = new int[18];
    private final int[] mBigramScores = new int[MAX_BIGRAMS];
    private int mDicTypeId = 1;

    public BinaryDictionary(Context context, String filename, long offset, long length, Flag[] flagArray) {
        this.mFlags = 0;
        this.mFlags = Flag.initFlags(flagArray == null ? ALL_CONFIG_FLAGS : flagArray, context);
        loadDictionary(filename, offset, length);
    }

    private final void loadDictionary(String path, long startOffset, long length) {
        try {
            this.mEngine = DictionaryEngine.open(path, startOffset, length);
        } catch (Exception e) {
            Log.e(TAG, "Could not open dictionary " + path + " : " + e);
            this.mEngine = null;
        }
    }

    @Override
    public void getBigrams(WordComposer codes, CharSequence previousWord, Dictionary.WordCallback callback) {
        // The bundled word lists contain no bigram data, so there is nothing to look up here.
    }

    @Override
    public void getWords(WordComposer codes, Dictionary.WordCallback callback, ProximityInfo proximityInfo) {
        int count = getSuggestions(codes, proximityInfo, this.mOutputChars, this.mScores);
        for (int j = 0; j < count && this.mScores[j] >= 1; j++) {
            int start = j * 48;
            int len = 0;
            while (len < 48 && this.mOutputChars[start + len] != 0) {
                len++;
            }
            if (len > 0) {
                callback.addWord(this.mOutputChars, start, len, this.mScores[j], this.mDicTypeId, Dictionary.DataType.UNIGRAM);
            }
        }
    }

    public boolean isValidDictionary() {
        return this.mEngine != null;
    }

    int getSuggestions(WordComposer codes, ProximityInfo proximityInfo, char[] outputChars, int[] scores) {
        int codesSize;
        if (!isValidDictionary() || (codesSize = codes.size()) > 47) {
            return -1;
        }
        Arrays.fill(this.mInputCodes, -1);
        for (int i = 0; i < codesSize; i++) {
            int[] alternatives = codes.getCodesAt(i);
            System.arraycopy(alternatives, 0, this.mInputCodes, i * 16, Math.min(alternatives.length, 16));
        }
        Arrays.fill(outputChars, (char) 0);
        Arrays.fill(scores, 0);
        int flags = 0;
        if (AlsarabIME.isT9Mode()) {
            flags |= DictionaryEngine.FLAG_T9_MODE;
        }
        if (AlsarabIME.mSuggestWordsMissingSpace) {
            flags |= DictionaryEngine.FLAG_SUGGEST_MISSING_SPACE;
        }
        return this.mEngine.getSuggestions(this.mInputCodes, codesSize, flags, outputChars, scores);
    }

    @Override
    public boolean isValidWord(CharSequence word) {
        if (word == null) {
            return false;
        }
        if (this.mEngine == null) {
            return false;
        }
        char[] chars = word.toString().toCharArray();
        return this.mEngine.isValidWord(chars, chars.length);
    }

    @Override
    public synchronized void close() {
        closeInternal();
    }

    private void closeInternal() {
        this.mEngine = null;
    }

    protected void finalize() throws Throwable {
        try {
            closeInternal();
        } finally {
            super.finalize();
        }
    }
}
