package keyboard.alsarab.albaid.ime;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;

public class FileTransforms {
    public static OutputStream getCryptedStream(OutputStream out) {
        return out;
    }

    public static InputStream getDecryptedStream(InputStream in) {
        return in;
    }

    public static InputStream getUncompressedStream(InputStream in) throws IOException {
        return new GZIPInputStream(in);
    }
}
