package keyboard.alsarab.albaid.ime;

import java.io.File;

class AssetFileAddress {
    public final String mFilename;
    public final long mLength;
    public final long mOffset;

    public AssetFileAddress(String filename, long offset, long length) {
        this.mFilename = filename;
        this.mOffset = offset;
        this.mLength = length;
    }

    public static AssetFileAddress makeFromFileName(String filename) {
        if (filename == null) {
            return null;
        }
        File f = new File(filename);
        if (f.isFile()) {
            return new AssetFileAddress(filename, 0L, f.length());
        }
        return null;
    }

    public static AssetFileAddress makeFromFileNameAndOffset(String filename, long offset, long length) {
        if (filename == null) {
            return null;
        }
        File f = new File(filename);
        if (f.isFile()) {
            return new AssetFileAddress(filename, offset, length);
        }
        return null;
    }
}
