package keyboard.alsarab.albaid.ime;

import android.view.View;
import android.widget.EditText;
import keyboard.alsarab.albaid.R;

/* compiled from: CustomDictionaryActivity.java */
public class CustomDialogWrapper {
    View base;
    EditText localeField;
    EditText wordField;

    public CustomDialogWrapper(View base) {
        this.wordField = null;
        this.localeField = null;
        this.base = null;
        this.base = base;
        this.wordField = (EditText) base.findViewById(R.id.theword);
        this.localeField = (EditText) base.findViewById(R.id.thelocale);
    }

    public String getWord() {
        return getwordField().getText().toString();
    }

    public String getLocale() {
        return getlocaleField().getText().toString();
    }

    private EditText getwordField() {
        if (this.wordField == null) {
            this.wordField = (EditText) this.base.findViewById(R.id.theword);
        }
        return this.wordField;
    }

    private EditText getlocaleField() {
        if (this.localeField == null) {
            this.localeField = (EditText) this.base.findViewById(R.id.thelocale);
        }
        return this.localeField;
    }
}
