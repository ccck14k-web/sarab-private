package keyboard.alsarab.albaid.ime;

import android.content.Context;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;
import java.util.ArrayList;

public class AutoTextDictionary {
    private static final String DATABASE_NAME = "autotext.db";
    private static final int DATABASE_VERSION = 1;
    public static ArrayList<AutoTextEntry> mAutoTextEntry = new ArrayList<>();
    private Cursor constantsCursor;
    private DatabaseHelper db;
    private AlsarabIME mIme;

    public class AutoTextEntry {
        String mKey;
        String mValue;

        AutoTextEntry(String key, String value) {
            this.mKey = key;
            this.mValue = value;
        }
    }

    public AutoTextDictionary(Context context, AlsarabIME ime) {
        this.db = null;
        this.constantsCursor = null;
        this.db = new DatabaseHelper(context, DATABASE_NAME);
        this.constantsCursor = this.db.getReadableDatabase().rawQuery("SELECT _ID, key, value FROM autotext ORDER BY key", null);
        this.constantsCursor.registerDataSetObserver(new MyContentObserver(new Handler()));
        loadDBtoArrayList();
    }

    private void loadDBtoArrayList() {
        this.constantsCursor.moveToFirst();
        while (!this.constantsCursor.isAfterLast()) {
            int keyCol = this.constantsCursor.getColumnIndex(DatabaseHelper.KEY);
            int valueCol = this.constantsCursor.getColumnIndex("value");
            AutoTextEntry atext_ent = new AutoTextEntry(this.constantsCursor.getString(keyCol), this.constantsCursor.getString(valueCol));
            mAutoTextEntry.add(atext_ent);
            this.constantsCursor.moveToNext();
        }
    }

    class MyContentObserver extends DataSetObserver {
        public MyContentObserver(Handler handler) {
        }

        @Override
        public void onChanged() {
            super.onChanged();
        }
    }

    public void close() {
        this.db.close();
        mAutoTextEntry.clear();
    }

    private void reloadList() {
        if (AutoTextEditor.DataBaseChanged) {
            mAutoTextEntry.clear();
            this.constantsCursor.requery();
            loadDBtoArrayList();
            AutoTextEditor.DataBaseChanged = false;
        }
    }

    public boolean isValidWord(CharSequence key) {
        reloadList();
        int size = mAutoTextEntry.size();
        for (int i = 0; i < size; i++) {
            if (mAutoTextEntry.get(i).mKey.toLowerCase().equals(key)) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<CharSequence> getWords(CharSequence composer) {
        reloadList();
        int size = mAutoTextEntry.size();
        ArrayList<CharSequence> words = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            if (mAutoTextEntry.get(i).mKey.toLowerCase().equals(composer)) {
                words.add(mAutoTextEntry.get(i).mValue);
            }
        }
        return words;
    }
}
