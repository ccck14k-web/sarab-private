package keyboard.alsarab.albaid.ime;

import android.inputmethodservice.Keyboard;

class MiniKeyboardKeyDetector extends KeyDetector {
    private static final int MAX_NEARBY_KEYS = 1;
    private final int mSlideAllowanceSquare;
    private final int mSlideAllowanceSquareTop;

    public MiniKeyboardKeyDetector(float slideAllowance) {
        this.mSlideAllowanceSquare = (int) (slideAllowance * slideAllowance);
        this.mSlideAllowanceSquareTop = this.mSlideAllowanceSquare * 2;
    }

    @Override
    protected int getMaxNearbyKeys() {
        return 1;
    }

    @Override
    public int getKeyIndexAndNearbyCodes(int x, int y, int[] allKeys) {
        Keyboard.Key[] keys = getKeys();
        int touchX = getTouchX(x);
        int touchY = getTouchY(y);
        int closestKeyIndex = -1;
        int closestKeyDist = y < 0 ? this.mSlideAllowanceSquareTop : this.mSlideAllowanceSquare;
        int keyCount = keys.length;
        for (int i = 0; i < keyCount; i++) {
            Keyboard.Key key = keys[i];
            int dist = key.squaredDistanceFrom(touchX, touchY);
            if (dist < closestKeyDist) {
                closestKeyIndex = i;
                closestKeyDist = dist;
            }
        }
        if (allKeys != null && closestKeyIndex != -1) {
            allKeys[0] = keys[closestKeyIndex].codes[0];
        }
        return closestKeyIndex;
    }
}
