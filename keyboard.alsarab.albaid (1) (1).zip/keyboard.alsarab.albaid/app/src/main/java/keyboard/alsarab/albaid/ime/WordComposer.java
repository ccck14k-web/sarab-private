package keyboard.alsarab.albaid.ime;

import java.util.ArrayList;

public class WordComposer {
    private boolean mAutoCapitalized;
    private int mCapsCount;
    private ArrayList<int[]> mCodes;
    private boolean mIsFirstCharCapitalized;
    private String mPreferredWord;
    private StringBuilder mTypedWord;
    private int[] mXCoordinates;
    private int[] mYCoordinates;

    public WordComposer() {
        this.mCodes = new ArrayList<>(48);
        this.mTypedWord = new StringBuilder(48);
        this.mXCoordinates = new int[48];
        this.mYCoordinates = new int[48];
    }

    public WordComposer(WordComposer copy) {
        this.mCodes = new ArrayList<>(copy.mCodes);
        this.mPreferredWord = copy.mPreferredWord;
        this.mTypedWord = new StringBuilder(copy.mTypedWord);
        this.mCapsCount = copy.mCapsCount;
        this.mAutoCapitalized = copy.mAutoCapitalized;
        this.mIsFirstCharCapitalized = copy.mIsFirstCharCapitalized;
        this.mXCoordinates = new int[48];
        this.mYCoordinates = new int[48];
    }

    public void reset() {
        this.mCodes.clear();
        this.mIsFirstCharCapitalized = false;
        this.mPreferredWord = null;
        this.mTypedWord.setLength(0);
        this.mCapsCount = 0;
    }

    public int size() {
        return this.mCodes.size();
    }

    public int[] getCodesAt(int index) {
        return this.mCodes.get(index);
    }

    public void add(int primaryCode, int[] codes, int x, int y) {
        int newIndex = size();
        this.mTypedWord.append((char) primaryCode);
        correctPrimaryJuxtapos(primaryCode, codes);
        this.mCodes.add(codes);
        if (newIndex < 48) {
            this.mXCoordinates[newIndex] = x;
            this.mYCoordinates[newIndex] = y;
        }
    }

    public void init(WordComposer source) {
        this.mCodes = new ArrayList<>(source.mCodes);
        this.mTypedWord = new StringBuilder(source.mTypedWord);
        this.mXCoordinates = source.mXCoordinates;
        this.mYCoordinates = source.mYCoordinates;
        this.mCapsCount = source.mCapsCount;
        this.mIsFirstCharCapitalized = source.mIsFirstCharCapitalized;
        this.mAutoCapitalized = source.mAutoCapitalized;
    }

    private void correctPrimaryJuxtapos(int primaryCode, int[] codes) {
        if (codes != null && codes.length >= 2 && codes[0] > 0 && codes[1] > 0 && codes[0] != primaryCode && codes[1] == primaryCode) {
            codes[1] = codes[0];
            codes[0] = primaryCode;
        }
    }

    public void deleteLast() {
        int codesSize = this.mCodes.size();
        if (codesSize > 0) {
            this.mCodes.remove(codesSize - 1);
            int lastPos = this.mTypedWord.length() - 1;
            char last = this.mTypedWord.charAt(lastPos);
            this.mTypedWord.deleteCharAt(lastPos);
            if (Character.isUpperCase(last)) {
                this.mCapsCount--;
            }
        }
    }

    public void deleteLast(int count) {
        int codesLength = this.mCodes.size();
        int typedWordLength = this.mTypedWord.length();
        for (int i = 0; i < count; i++) {
            if (codesLength > 0 || typedWordLength > 0) {
                if (codesLength > 0) {
                    this.mCodes.remove(codesLength - 1);
                }
                if (typedWordLength > 0) {
                    this.mTypedWord.deleteCharAt(typedWordLength - 1);
                }
                codesLength--;
                typedWordLength--;
            } else {
                return;
            }
        }
    }

    public CharSequence getTypedWord() {
        int wordSize = this.mCodes.size();
        if (wordSize == 0) {
            return null;
        }
        return this.mTypedWord;
    }

    public void setFirstCharCapitalized(boolean capitalized) {
        this.mIsFirstCharCapitalized = capitalized;
    }

    public boolean isFirstCharCapitalized() {
        return this.mIsFirstCharCapitalized;
    }

    public boolean isAllUpperCase() {
        return this.mCapsCount > 0 && this.mCapsCount == size();
    }

    public void setPreferredWord(String preferred) {
        this.mPreferredWord = preferred;
    }

    public CharSequence getPreferredWord() {
        return this.mPreferredWord != null ? this.mPreferredWord : getTypedWord();
    }

    public boolean isMostlyCaps() {
        return this.mCapsCount > 1;
    }

    public void setAutoCapitalized(boolean auto) {
        this.mAutoCapitalized = auto;
    }

    public boolean isAutoCapitalized() {
        return this.mAutoCapitalized;
    }

    public int[] getXCoordinates() {
        return this.mXCoordinates;
    }

    public int[] getYCoordinates() {
        return this.mYCoordinates;
    }
}
