package keyboard.alsarab.albaid.common.userhappiness;

import android.content.Context;

/** Kept only for API compatibility with the voice code; no data is collected or sent. */
public class UserHappinessSignals {
    private static boolean mHasVoiceLoggingInfo = false;

    public static void setHasVoiceLoggingInfo(boolean hasVoiceLogging) {
        mHasVoiceLoggingInfo = hasVoiceLogging;
    }

    public static void userAcceptedImeText(Context context) {
        setHasVoiceLoggingInfo(false);
    }
}
