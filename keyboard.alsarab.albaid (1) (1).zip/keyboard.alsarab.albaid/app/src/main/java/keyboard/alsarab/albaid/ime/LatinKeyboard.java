package keyboard.alsarab.albaid.ime;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.text.TextPaint;
import android.view.ViewConfiguration;
import keyboard.alsarab.albaid.common.speech.LoggingEvents;
import keyboard.alsarab.albaid.R;
import java.util.List;
import java.util.Locale;

public class LatinKeyboard extends Keyboard {
    private static final boolean DEBUG_PREFERRED_LETTER = false;
    private static final float MINIMUM_SCALE_OF_LANGUAGE_NAME = 0.8f;
    private static final int OPACITY_FULLY_OPAQUE = 255;
    private static final float OVERLAP_PERCENTAGE_HIGH_PROB = 0.85f;
    private static final float OVERLAP_PERCENTAGE_LOW_PROB = 0.7f;
    private static final int SHIFT_LOCKED = 2;
    private static final int SHIFT_OFF = 0;
    private static final int SHIFT_ON = 1;
    private static final float SPACEBAR_DRAG_THRESHOLD = 0.5f;
    private static final float SPACEBAR_LANGUAGE_BASELINE = 0.6f;
    private static final float SPACEBAR_POPUP_MIN_RATIO = 0.4f;
    private static final int SPACE_LED_LENGTH_PERCENT = 80;
    private static final String TAG = "LatinKeyboard";
    public static int mArrowsHight;
    public static int mBottomPadding;
    public static int mHintColor;
    public static int mKeyHight;
    public static int mRowGap;
    public static Drawable mSpaceAutoCompletionIndicator;
    public static int mTextSize;
    public static boolean mode_arrows = false;
    static int sMode;
    private static int sSpacebarVerticalCorrection;
    private final int NUMBER_HINT_COUNT;
    private Keyboard.Key m123Key;
    private CharSequence m123Label;
    private Drawable m123MicIcon;
    private Drawable m123MicPreviewIcon;
    private final Drawable mButtonArrowLeftIcon;
    private final Drawable mButtonArrowRightIcon;
    private final Context mContext;
    private boolean mCurrentlyInSpace;
    private Keyboard.Key mEnterKey;
    private Keyboard.Key mF1Key;
    private boolean mHasVoiceButton;
    private final Drawable mHintIcon;
    private final boolean mIsAlphaKeyboard;
    private boolean mIsBlackSym;
    private LanguageSwitcher mLanguageSwitcher;
    private int mLastY;
    private int mLastx;
    private Locale mLocale;
    private Drawable mMicIcon;
    private Drawable mMicPreviewIcon;
    private int mMode;
    private Drawable[] mNumberHintIcons;
    private Keyboard.Key[] mNumberHintKeys;
    private Drawable mOldShiftIcon;
    private int mPrefDistance;
    private int mPrefLetter;
    private int[] mPrefLetterFrequencies;
    private int mPrefLetterX;
    private int mPrefLetterY;
    private ProximityInfo mProximityInfo;
    private final Resources mRes;
    private int mRowHight;
    private Keyboard.Key mShiftKey;
    private Drawable mShiftLockIcon;
    private Drawable mShiftLockPreviewIcon;
    private int mShiftState;
    private SlidingLocaleDrawable mSlidingLocaleIcon;
    private int mSpaceDragLastDiffX;
    private int mSpaceDragLastDiffY;
    private int mSpaceDragStartX;
    private int mSpaceDragStartY;
    private Drawable mSpaceIcon;
    private Keyboard.Key mSpaceKey;
    private final int[] mSpaceKeyIndexArray;
    private Drawable mSpacePreviewIcon;
    private Keyboard.Key mT9key;
    public final TouchPositionCorrection mTouchPositionCorrection;
    private final int mVerticalGap;
    private boolean mVoiceEnabled;

    public interface HardKeyboardAction {
        int getKeyCode();

        boolean isAltActive();

        boolean isShiftActive();

        void setNewKeyCode(int i);
    }

    public interface HardKeyboardTranslator {
        void translatePhysicalCharacter(HardKeyboardAction hardKeyboardAction, AlsarabIME dictionaryEditor);
    }

    private void updateSpaceBarForLocale(boolean z, boolean z2) {
    }

    public LatinKeyboard(Context context, int xmlLayoutResId) {
        this(context, xmlLayoutResId, 0);
    }

    static Context a(Context context, int mode) {
        sMode = mode;
        return context;
    }

    public LatinKeyboard(Context context, int xmlLayoutResId, int mode) {
        super(a(context, mode), xmlLayoutResId, mode);
        this.NUMBER_HINT_COUNT = 10;
        this.mNumberHintIcons = new Drawable[10];
        this.mShiftState = 0;
        this.mTouchPositionCorrection = new TouchPositionCorrection();
        Resources res = context.getResources();
        this.mContext = context;
        this.mMode = mode;
        this.mRes = res;
        setKeyHeight(this.mRowHight);
        this.mShiftLockIcon = res.getDrawable(R.drawable.sym_keyboard_shift_locked);
        this.mShiftLockPreviewIcon = res.getDrawable(R.drawable.sym_keyboard_feedback_shift_locked);
        setDefaultBounds(this.mShiftLockPreviewIcon);
        this.mSpaceIcon = res.getDrawable(R.drawable.sym_keyboard_space);
        mSpaceAutoCompletionIndicator = res.getDrawable(R.drawable.sym_keyboard_space_led);
        this.mSpacePreviewIcon = res.getDrawable(R.drawable.sym_keyboard_feedback_space);
        this.mMicIcon = res.getDrawable(R.drawable.sym_keyboard_mic);
        this.mMicPreviewIcon = res.getDrawable(R.drawable.sym_keyboard_feedback_mic);
        setDefaultBounds(this.mMicPreviewIcon);
        this.mButtonArrowLeftIcon = res.getDrawable(R.drawable.sym_keyboard_language_arrows_left);
        this.mButtonArrowRightIcon = res.getDrawable(R.drawable.sym_keyboard_language_arrows_right);
        this.m123MicIcon = res.getDrawable(R.drawable.sym_keyboard_123_mic);
        this.m123MicPreviewIcon = res.getDrawable(R.drawable.sym_keyboard_feedback_123_mic);
        this.mHintIcon = res.getDrawable(R.drawable.hint_popup);
        setDefaultBounds(this.m123MicPreviewIcon);
        sSpacebarVerticalCorrection = res.getDimensionPixelOffset(R.dimen.spacebar_vertical_correction);
        this.mIsAlphaKeyboard = xmlLayoutResId == R.xml.kbd_qwerty || xmlLayoutResId == R.xml.kbd_qwertz || xmlLayoutResId == R.xml.kbd_colemak || xmlLayoutResId == R.xml.kbd_qwerty_swiss || xmlLayoutResId == R.xml.kbd_qwerty_german_full || xmlLayoutResId == R.xml.kbd_qwerty2 || xmlLayoutResId == R.xml.kbd_azerty || xmlLayoutResId == R.xml.kbd_dvorak || xmlLayoutResId == R.xml.kbd_qwerty_alt || xmlLayoutResId == R.xml.kbd_t9 || xmlLayoutResId == R.xml.kbd_compact || xmlLayoutResId == R.xml.kbd_compact_qwerty2 || xmlLayoutResId == R.xml.kbd_compact_qwertz || xmlLayoutResId == R.xml.kbd_compact_azerty || xmlLayoutResId == R.xml.kbd_compact_dvorak || xmlLayoutResId == R.xml.kbd_splitted_qwerty || xmlLayoutResId == R.xml.kbd_splitted_qwerty || xmlLayoutResId == R.xml.kbd_splitted_qwerty2 || xmlLayoutResId == R.xml.kbd_splitted_azerty || xmlLayoutResId == R.xml.kbd_splitted_dvorak || xmlLayoutResId == R.xml.kbd_qwerty_cz_full || xmlLayoutResId == R.xml.kbd_qwertz_cz_full || xmlLayoutResId == R.xml.kbd_splitted_qwerty_cz_full || xmlLayoutResId == R.xml.kbd_splitted_qwertz_cz_full || xmlLayoutResId == R.xml.kbd_splitted_qwerty_german_full || xmlLayoutResId == R.xml.kbd_splitted_qwerty_swiss;
        this.mSpaceKeyIndexArray = new int[]{indexOf(32)};
        initializeNumberHintResources(context);
        this.mVerticalGap = super.getVerticalGap();
        String[] strArr = {"0.0038756", "-0.0005677", "0.1577026", "-0.0236678", "0.0381731", "0.1529972", "-0.0086827", "0.0880847", "0.1522819"};
        this.mProximityInfo = new ProximityInfo(32, 16, getMinWidth(), getHeight(), getKeyWidth(), getKeyHeight(), getKeys(), this.mTouchPositionCorrection);
    }

    public ProximityInfo getProximityInfo() {
        return this.mProximityInfo;
    }

    private void initializeNumberHintResources(Context context) {
        context.getResources();
    }

    public static class TouchPositionCorrection {
        private static final int TOUCH_POSITION_CORRECTION_RECORD_SIZE = 3;
        public boolean mEnabled = true;
        public float[] mRadii;
        public float[] mXs;
        public float[] mYs;

        public void load(String[] data) {
            int dataLength = data.length;
            if (dataLength % 3 != 0) {
                if (AlsarabIME.DEBUG) {
                    throw new RuntimeException("the size of touch position correction data is invalid");
                }
                return;
            }
            int length = dataLength / 3;
            this.mXs = new float[length];
            this.mYs = new float[length];
            this.mRadii = new float[length];
            for (int i = 0; i < dataLength; i++) {
                try {
                    int type = i % 3;
                    int index = i / 3;
                    float value = Float.parseFloat(data[i]);
                    if (type == 0) {
                        this.mXs[index] = value;
                    } else if (type == 1) {
                        this.mYs[index] = value;
                    } else {
                        this.mRadii[index] = value;
                    }
                } catch (NumberFormatException e) {
                    if (AlsarabIME.DEBUG) {
                        throw new RuntimeException("the number format for touch position correction data is invalid");
                    }
                    this.mXs = null;
                    this.mYs = null;
                    this.mRadii = null;
                    return;
                }
            }
        }

        public void setEnabled(boolean enabled) {
            this.mEnabled = enabled;
        }

        public boolean isValid() {
            return this.mEnabled && this.mXs != null && this.mYs != null && this.mRadii != null && this.mXs.length > 0 && this.mYs.length > 0 && this.mRadii.length > 0;
        }
    }

    @Override
    protected Keyboard.Key createKeyFromXml(Resources res, Keyboard.Row parent, int x, int y, XmlResourceParser parser) {
        Keyboard.Key key = new LatinKey(res, parent, x, y, parser);
        switch (key.codes[0]) {
            case -103:
                this.mF1Key = key;
                break;
            case -10:
                this.mT9key = key;
                this.mT9key.on = AlsarabIME.isT9Mode();
                break;
            case -2:
                this.m123Key = key;
                this.m123Label = key.label;
                break;
            case 10:
                this.mEnterKey = key;
                break;
            case Suggest.APPROX_MAX_WORD_LENGTH /* 32 */:
                this.mSpaceKey = key;
                break;
        }
        if (this.mNumberHintKeys == null) {
            this.mNumberHintKeys = new Keyboard.Key[10];
        }
        int hintNumber = -1;
        if (LatinKeyboardBaseView.isNumberAtLeftmostPopupChar(key)) {
            hintNumber = key.popupCharacters.charAt(0) - '0';
        } else if (LatinKeyboardBaseView.isNumberAtRightmostPopupChar(key)) {
            hintNumber = key.popupCharacters.charAt(key.popupCharacters.length() - 1) - '0';
        }
        if (hintNumber >= 0 && hintNumber <= 10) {
            this.mNumberHintKeys[hintNumber] = key;
        }
        return key;
    }

    public void setPopupKeyChars(Keyboard.Key aKey) {
    }

    @Override
    protected Keyboard.Row createRowFromXml(Resources res, XmlResourceParser parser) {
        Keyboard.Row row = new Keyboard.Row(res, this, parser);
        row.defaultHeight = (row.defaultHeight * mKeyHight) / 100;
        this.mRowHight = row.defaultHeight;
        if (mode_arrows && row.mode == R.id.mode_arrows) {
            row.mode = sMode;
            row.defaultHeight = (row.defaultHeight * mArrowsHight) / 100;
        } else if (mode_arrows && row.rowEdgeFlags == 8) {
            row.rowEdgeFlags = 0;
        }
        if (row.rowEdgeFlags == 8) {
            row.verticalGap = (row.verticalGap * mBottomPadding) / 100;
        } else {
            row.verticalGap = (row.verticalGap * mRowGap) / 100;
        }
        return row;
    }

    public void setImeOptions(Resources res, int mode, int options) {
        this.mMode = mode;
        if (this.mEnterKey != null) {
            this.mEnterKey.popupCharacters = null;
            this.mEnterKey.popupResId = 0;
            this.mEnterKey.text = null;
            int i = options & 1073742079;
            switch (options & 1073742079) {
                case 2:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_go_key);
                    this.mEnterKey.popupResId = R.xml.popup_smileys;
                    break;
                case 3:
                    this.mEnterKey.iconPreview = res.getDrawable(R.drawable.sym_keyboard_feedback_search);
                    this.mEnterKey.icon = res.getDrawable(R.drawable.sym_keyboard_search);
                    this.mEnterKey.label = null;
                    this.mEnterKey.popupResId = R.xml.popup_smileys;
                    break;
                case 4:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_send_key);
                    this.mEnterKey.popupResId = R.xml.popup_smileys;
                    break;
                case 5:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_next_key);
                    this.mEnterKey.popupResId = R.xml.popup_smileys;
                    break;
                case 6:
                    this.mEnterKey.iconPreview = null;
                    this.mEnterKey.icon = null;
                    this.mEnterKey.label = res.getText(R.string.label_done_key);
                    this.mEnterKey.popupResId = R.xml.popup_smileys;
                    break;
                default:
                    this.mEnterKey.iconPreview = res.getDrawable(R.drawable.sym_keyboard_feedback_return);
                    this.mEnterKey.icon = res.getDrawable(R.drawable.sym_keyboard_return);
                    this.mEnterKey.icon = new BitmapDrawable(this.mRes, drawSynthesizedSettingsHintImage(this.mEnterKey.width, this.mEnterKey.height, this.mEnterKey.icon, this.mHintIcon));
                    this.mEnterKey.label = null;
                    this.mEnterKey.text = "enter";
                    this.mEnterKey.label = LoggingEvents.EXTRA_CALLING_APP_NAME;
                    this.mEnterKey.popupResId = R.xml.popup_smileys;
                    break;
            }
            if (this.mEnterKey.iconPreview != null) {
                setDefaultBounds(this.mEnterKey.iconPreview);
            }
        }
    }

    public void enableShiftLock() {
        int index = getShiftKeyIndex();
        if (index >= 0) {
            this.mShiftKey = getKeys().get(index);
            if (this.mShiftKey instanceof LatinKey) {
                ((LatinKey) this.mShiftKey).enableShiftLock();
            }
            this.mOldShiftIcon = this.mShiftKey.icon;
        }
    }

    public void setShiftLocked(boolean shiftLocked) {
        if (this.mShiftKey != null) {
            if (shiftLocked) {
                this.mShiftKey.on = true;
                this.mShiftKey.icon = this.mShiftLockIcon;
                this.mShiftState = 2;
                return;
            }
            this.mShiftKey.on = false;
            this.mShiftKey.icon = this.mShiftLockIcon;
            this.mShiftState = 1;
        }
    }

    void setColorIcons(int color) {
        List<Keyboard.Key> keys = getKeys();
        for (int i = 0; i < keys.size(); i++) {
            Drawable icon = keys.get(i).icon;
            if (icon != null) {
                icon.setColorFilter(color, PorterDuff.Mode.MULTIPLY);
            }
        }
    }

    void ClearColorIcons() {
        List<Keyboard.Key> keys = getKeys();
        for (int i = 0; i < keys.size(); i++) {
            Drawable icon = keys.get(i).icon;
            if (icon != null) {
                icon.clearColorFilter();
            }
        }
    }

    public boolean isShiftLocked() {
        return this.mShiftState == 2;
    }

    @Override
    public boolean setShifted(boolean shiftState) {
        boolean shiftChanged = false;
        if (this.mShiftKey != null) {
            if (!shiftState) {
                shiftChanged = this.mShiftState != 0;
                this.mShiftState = 0;
                this.mShiftKey.on = false;
                this.mShiftKey.icon = this.mOldShiftIcon;
            } else if (this.mShiftState == 0) {
                shiftChanged = this.mShiftState == 0;
                this.mShiftState = 1;
                this.mShiftKey.icon = this.mShiftLockIcon;
            }
            return shiftChanged;
        }
        return super.setShifted(shiftState);
    }

    @Override
    public boolean isShifted() {
        if (this.mShiftKey != null) {
            return this.mShiftState != 0;
        }
        return super.isShifted();
    }

    public boolean isAlphaKeyboard() {
        return this.mIsAlphaKeyboard;
    }

    public void setColorOfSymbolIcons(boolean isAutoCompletion, boolean isBlack) {
        this.mIsBlackSym = isBlack;
        if (isBlack) {
            this.mShiftLockIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_shift_locked);
            this.mSpaceIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_space);
            this.mMicIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_mic);
            this.m123MicIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_123_mic);
            setColorIcons(Calibration.mFontSymbolColors);
        } else {
            this.mShiftLockIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_shift_locked);
            this.mSpaceIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_space);
            this.mMicIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_mic);
            this.m123MicIcon = this.mRes.getDrawable(R.drawable.sym_keyboard_123_mic);
            ClearColorIcons();
        }
        updateDynamicKeys();
        if (this.mSpaceKey != null) {
            updateSpaceBarForLocale(isAutoCompletion, isBlack);
        }
        updateNumberHintKeys();
    }

    public void setDefaultBounds(Drawable drawable) {
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
    }

    public void setVoiceMode(boolean hasVoiceButton, boolean hasVoice) {
        this.mHasVoiceButton = hasVoiceButton;
        this.mVoiceEnabled = hasVoice;
        updateDynamicKeys();
    }

    private void updateDynamicKeys() {
        update123Key();
        updateF1Key();
    }

    private void update123Key() {
        if (this.m123Key != null && this.mIsAlphaKeyboard) {
            if (this.mVoiceEnabled && !this.mHasVoiceButton) {
                this.m123Key.icon = this.m123MicIcon;
                this.m123Key.iconPreview = this.m123MicPreviewIcon;
                this.m123Key.label = null;
                return;
            }
            this.m123Key.icon = null;
            this.m123Key.iconPreview = null;
            this.m123Key.label = this.m123Label;
        }
    }

    private void updateF1Key() {
        if (this.mF1Key != null) {
            String comma = ",";
            if (this.mLocale != null && this.mLocale.getLanguage().equalsIgnoreCase("ar")) {
                comma = "،";
            }
            if (this.mIsAlphaKeyboard) {
                if (this.mMode == 4) {
                    setNonMicF1Key(this.mF1Key, "/", R.xml.popup_slash);
                    return;
                }
                if (this.mMode == 5) {
                    setNonMicF1Key(this.mF1Key, "@", R.xml.popup_at);
                    return;
                } else if (this.mVoiceEnabled && this.mHasVoiceButton) {
                    setMicF1Key(this.mF1Key);
                    return;
                } else {
                    setNonMicF1Key(this.mF1Key, comma, R.xml.popup_comma);
                    return;
                }
            }
            if (this.mVoiceEnabled && this.mHasVoiceButton) {
                setMicF1Key(this.mF1Key);
            } else {
                setNonMicF1Key(this.mF1Key, comma, R.xml.popup_comma);
            }
        }
    }

    private void setMicF1Key(Keyboard.Key key) {
        Drawable micWithSettingsHintDrawable = new BitmapDrawable(this.mRes, drawSynthesizedSettingsHintImage(key.width, key.height, this.mMicIcon, this.mHintIcon));
        key.label = null;
        key.codes = new int[]{-102};
        key.popupResId = R.xml.popup_mic;
        key.icon = micWithSettingsHintDrawable;
        key.icon.setColorFilter(Calibration.mFontSymbolColors, PorterDuff.Mode.MULTIPLY);
        key.iconPreview = this.mMicPreviewIcon;
    }

    private void setNonMicF1Key(Keyboard.Key key, String label, int popupResId) {
        key.label = label;
        key.codes = new int[]{label.charAt(0)};
        key.popupResId = popupResId;
        key.icon = this.mHintIcon;
        key.icon.setColorFilter(Calibration.mFontSymbolColors, PorterDuff.Mode.MULTIPLY);
        key.iconPreview = null;
    }

    public boolean isF1Key(Keyboard.Key key) {
        return key == this.mF1Key;
    }

    public static boolean hasPuncOrSmileysPopup(Keyboard.Key key) {
        return key.popupResId == R.xml.popup_punctuation || key.popupResId == R.xml.popup_punctuation_ar || key.popupResId == R.xml.popup_smileys;
    }

    public Keyboard.Key onAutoCompletionStateChanged(boolean isAutoCompletion) {
        updateSpaceBarForLocale(isAutoCompletion, this.mIsBlackSym);
        return this.mSpaceKey;
    }

    private void updateNumberHintKeys() {
        for (int i = 0; i < this.mNumberHintKeys.length; i++) {
            if (this.mNumberHintKeys[i] != null) {
                this.mNumberHintKeys[i].icon = this.mNumberHintIcons[i];
            }
        }
    }

    public int getKeyboardMode() {
        return this.mMode;
    }

    public boolean isLanguageSwitchEnabled() {
        return this.mLocale != null;
    }

    private static int getTextWidth(Paint paint, String text, float textSize, Rect bounds) {
        paint.setTextSize(textSize);
        paint.getTextBounds(text, 0, text.length(), bounds);
        return bounds.width();
    }

    private Bitmap drawSynthesizedSettingsHintImage(int width, int height, Drawable mainIcon, Drawable hintIcon) {
        if (mainIcon == null || hintIcon == null) {
            return null;
        }
        Rect hintIconPadding = new Rect(0, 0, 0, 0);
        hintIcon.getPadding(hintIconPadding);
        Bitmap buffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(buffer);
        canvas.drawColor(this.mRes.getColor(R.color.latinkeyboard_transparent), PorterDuff.Mode.CLEAR);
        int drawableX = (((hintIconPadding.left + width) - hintIconPadding.right) - mainIcon.getIntrinsicWidth()) / 2;
        int drawableY = (((hintIconPadding.top + height) - hintIconPadding.bottom) - mainIcon.getIntrinsicHeight()) / 2;
        setDefaultBounds(mainIcon);
        canvas.translate(drawableX, drawableY);
        mainIcon.draw(canvas);
        canvas.translate(-drawableX, -drawableY);
        hintIcon.setBounds(0, 0, width, height);
        hintIcon.draw(canvas);
        return buffer;
    }

    private static String layoutSpaceBar(Paint paint, Locale locale, Drawable lArrow, Drawable rArrow, int width, int height, float origTextSize, boolean allowVariableTextSize) {
        boolean useShortName;
        float arrowWidth = lArrow.getIntrinsicWidth();
        float arrowHeight = lArrow.getIntrinsicHeight();
        float maxTextWidth = width - (arrowWidth + arrowWidth);
        Rect bounds = new Rect();
        String language = LanguageSwitcher.toTitleCase(locale.getDisplayLanguage(locale));
        if (language.equals("עברית") && AlsarabIME.mRTLEnabled) {
            language = "תירבע";
        }
        int textWidth = getTextWidth(paint, language, origTextSize, bounds);
        float textSize = origTextSize * Math.min(maxTextWidth / textWidth, 1.0f);
        if (allowVariableTextSize) {
            textWidth = getTextWidth(paint, language, textSize, bounds);
            useShortName = textSize / origTextSize < MINIMUM_SCALE_OF_LANGUAGE_NAME || ((float) textWidth) > maxTextWidth;
        } else {
            useShortName = ((float) textWidth) > maxTextWidth;
            textSize = origTextSize;
        }
        if (useShortName) {
            language = LanguageSwitcher.toTitleCase(locale.getLanguage());
            textWidth = getTextWidth(paint, language, origTextSize, bounds);
            textSize = origTextSize * Math.min(maxTextWidth / textWidth, 1.0f);
        }
        paint.setTextSize(textSize);
        float baseline = height * SPACEBAR_LANGUAGE_BASELINE;
        int top = (int) (baseline - arrowHeight);
        float remains = (width - textWidth) / 2;
        lArrow.setBounds((int) (remains - arrowWidth), top, (int) remains, (int) baseline);
        rArrow.setBounds((int) (textWidth + remains), top, (int) (textWidth + remains + arrowWidth), (int) baseline);
        return language;
    }

    private Bitmap drawSpaceBar(int opacity, boolean isAutoCompletion, boolean isBlack) {
        int i;
        int width = this.mSpaceKey.width;
        int height = this.mSpaceIcon.getIntrinsicHeight();
        Bitmap buffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(buffer);
        canvas.drawColor(this.mRes.getColor(R.color.latinkeyboard_transparent), PorterDuff.Mode.CLEAR);
        if (this.mLocale != null) {
            Paint paint = new Paint();
            paint.setAlpha(opacity);
            paint.setAntiAlias(true);
            paint.setTextAlign(Paint.Align.CENTER);
            String language = layoutSpaceBar(paint, this.mLanguageSwitcher.getInputLocale(), this.mButtonArrowLeftIcon, this.mButtonArrowRightIcon, width, height, getTextSizeFromTheme(android.R.style.TextAppearance_Small, 14), true);
            Resources resources = this.mRes;
            if (isBlack) {
                i = R.color.latinkeyboard_bar_language_shadow_black;
            } else {
                i = R.color.latinkeyboard_bar_language_shadow_white;
            }
            int shadowColor = resources.getColor(i);
            float baseline = height * SPACEBAR_LANGUAGE_BASELINE;
            float descent = paint.descent();
            paint.setColor(shadowColor);
            canvas.drawText(language, width / 2, (baseline - descent) - 1.0f, paint);
            if (isBlack) {
                paint.setColor(Calibration.mFontSymbolColors);
                this.mButtonArrowLeftIcon.setColorFilter(Calibration.mFontSymbolColors, PorterDuff.Mode.MULTIPLY);
                this.mButtonArrowRightIcon.setColorFilter(Calibration.mFontSymbolColors, PorterDuff.Mode.MULTIPLY);
                this.mSpaceIcon.setColorFilter(Calibration.mFontSymbolColors, PorterDuff.Mode.MULTIPLY);
            } else {
                paint.setColor(this.mRes.getColor(R.color.latinkeyboard_bar_language_text));
            }
            if ((!AlsarabIME.mUseCustomSuggestionColors) & AlsarabIME.mUseExternalSkin) {
                paint.setColor((-2130706433) & AlsarabIME.skinData.text_color2);
                paint.setShadowLayer(2.0f, 0.0f, 0.0f, (-2130706433) & AlsarabIME.skinData.shadow_color2);
                this.mButtonArrowLeftIcon.setColorFilter(AlsarabIME.skinData.text_color2, PorterDuff.Mode.MULTIPLY);
                this.mButtonArrowRightIcon.setColorFilter(AlsarabIME.skinData.text_color2, PorterDuff.Mode.MULTIPLY);
            }
            canvas.drawText(language, width / 2, baseline - descent, paint);
            if (this.mLanguageSwitcher.getLocaleCount() > 1) {
                this.mButtonArrowLeftIcon.draw(canvas);
                this.mButtonArrowRightIcon.draw(canvas);
            }
        }
        if (isAutoCompletion) {
            int iconWidth = (width * SPACE_LED_LENGTH_PERCENT) / 100;
            int iconHeight = mSpaceAutoCompletionIndicator.getIntrinsicHeight();
            int x = (width - iconWidth) / 2;
            int y = height - iconHeight;
            mSpaceAutoCompletionIndicator.setColorFilter(CandidateView.getColor(), PorterDuff.Mode.SRC_ATOP);
            mSpaceAutoCompletionIndicator.setBounds(x, y, x + iconWidth, y + iconHeight);
            mSpaceAutoCompletionIndicator.draw(canvas);
        } else {
            int iconWidth2 = this.mSpaceIcon.getIntrinsicWidth();
            int iconHeight2 = this.mSpaceIcon.getIntrinsicHeight();
            int x2 = (width - iconWidth2) / 2;
            int y2 = height - iconHeight2;
            this.mSpaceIcon.setBounds(x2, y2, x2 + iconWidth2, y2 + iconHeight2);
            this.mSpaceIcon.draw(canvas);
        }
        return buffer;
    }

    private void updateLocaleDragX(int diff) {
        if (this.mSlidingLocaleIcon == null) {
            int width = Math.max(this.mSpaceKey.width, (int) (getMinWidth() * SPACEBAR_POPUP_MIN_RATIO));
            int height = this.mSpacePreviewIcon.getIntrinsicHeight();
            this.mSlidingLocaleIcon = new SlidingLocaleDrawable(this.mSpacePreviewIcon, width, height);
            this.mSlidingLocaleIcon.setBounds(0, 0, width, height);
            this.mSpaceKey.iconPreview = this.mSlidingLocaleIcon;
        }
        this.mSlidingLocaleIcon.setDiffX(diff);
        if (Math.abs(diff) == Integer.MAX_VALUE) {
            this.mSpaceKey.iconPreview = this.mSpacePreviewIcon;
        } else {
            this.mSpaceKey.iconPreview = this.mSlidingLocaleIcon;
        }
        this.mSpaceKey.iconPreview.invalidateSelf();
    }

    private void updateLocaleDragY(int diff) {
        if (this.mSlidingLocaleIcon == null) {
            int width = Math.max(this.mSpaceKey.height, (int) (getHeight() * SPACEBAR_POPUP_MIN_RATIO));
            int height = this.mSpacePreviewIcon.getIntrinsicHeight();
            this.mSlidingLocaleIcon = new SlidingLocaleDrawable(this.mSpacePreviewIcon, width, height);
            this.mSlidingLocaleIcon.setBounds(0, 0, width, height);
            this.mSpaceKey.iconPreview = this.mSlidingLocaleIcon;
        }
        this.mSlidingLocaleIcon.setDiffY(diff);
        if (Math.abs(diff) == Integer.MAX_VALUE) {
            this.mSpaceKey.iconPreview = this.mSpacePreviewIcon;
        } else {
            this.mSpaceKey.iconPreview = this.mSlidingLocaleIcon;
        }
        this.mSpaceKey.iconPreview.invalidateSelf();
    }

    public int getLanguageChangeDirection() {
        if (this.mSpaceKey == null || this.mLanguageSwitcher.getLocaleCount() < 2 || Math.abs(this.mSpaceDragLastDiffX) < this.mSpaceKey.width * SPACEBAR_DRAG_THRESHOLD) {
            return 0;
        }
        return this.mSpaceDragLastDiffX > 0 ? 1 : -1;
    }

    public int getArraoyChangeDirection() {
        float hight;
        if (!mode_arrows) {
            hight = this.mSpaceKey.height;
        } else {
            hight = this.mSpaceKey.height * 0.2f;
        }
        if (this.mSpaceKey == null || Math.abs(this.mSpaceDragLastDiffY) < hight) {
            return 0;
        }
        return this.mSpaceDragLastDiffY > 0 ? 1 : -1;
    }

    public void setLanguageSwitcher(LanguageSwitcher switcher, boolean isAutoCompletion, boolean isBlackSym) {
        Locale locale;
        this.mLanguageSwitcher = switcher;
        if (this.mLanguageSwitcher.getLocaleCount() > 0) {
            locale = this.mLanguageSwitcher.getInputLocale();
        } else {
            locale = null;
        }
        if (locale != null && this.mLanguageSwitcher.getLocaleCount() == 1 && this.mLanguageSwitcher.getSystemLocale().getLanguage().equalsIgnoreCase(locale.getLanguage())) {
            locale = null;
        }
        this.mLocale = locale;
        setColorOfSymbolIcons(isAutoCompletion, isBlackSym);
    }

    boolean isCurrentlyInSpace() {
        return this.mCurrentlyInSpace;
    }

    public void setPreferredLetters(int[] frequencies) {
        this.mPrefLetterFrequencies = frequencies;
        this.mPrefLetter = 0;
    }

    public void keyReleased() {
        this.mCurrentlyInSpace = false;
        this.mSpaceDragLastDiffX = 0;
        this.mSpaceDragLastDiffY = 0;
        this.mPrefLetter = 0;
        this.mPrefLetterX = 0;
        this.mPrefLetterY = 0;
        this.mPrefDistance = Integer.MAX_VALUE;
        if (this.mSpaceKey != null) {
            updateLocaleDragX(Integer.MAX_VALUE);
            updateLocaleDragY(Integer.MAX_VALUE);
        }
    }

    boolean isInside(LatinKey key, int x, int y) {
        int dist;
        int dist2;
        boolean morethanonelocal = this.mLanguageSwitcher.getLocaleCount() > 1;
        int code = key.codes[0];
        if (code == -1 || code == -5) {
            y -= key.height / 10;
            if (code == -1) {
                x += key.width / 6;
            }
            if (code == -5) {
                x -= key.width / 6;
            }
        } else if (code == 32) {
            y += sSpacebarVerticalCorrection;
            if (this.mCurrentlyInSpace) {
                int diffx = x - this.mSpaceDragStartX;
                int diffy = y - this.mSpaceDragStartY;
                if (Math.abs(diffx) > Math.abs(diffy)) {
                    if (morethanonelocal) {
                        if (Math.abs(diffx - this.mSpaceDragLastDiffX) > 0) {
                            updateLocaleDragX(diffx);
                        }
                        this.mSpaceDragLastDiffX = diffx;
                        return true;
                    }
                } else {
                    if (Math.abs(diffy - this.mSpaceDragLastDiffY) > 0) {
                        updateLocaleDragY(diffy);
                    }
                    this.mSpaceDragLastDiffY = diffy;
                    return true;
                }
            } else {
                boolean insideSpace = key.isInsideSuper(x, y);
                if (insideSpace) {
                    this.mCurrentlyInSpace = true;
                    this.mSpaceDragStartX = x;
                    this.mSpaceDragStartY = y;
                    updateLocaleDragY(0);
                    updateLocaleDragX(0);
                    return insideSpace;
                }
            }
        } else if (this.mPrefLetterFrequencies != null) {
            if (this.mPrefLetterX != x || this.mPrefLetterY != y) {
                this.mPrefLetter = 0;
                this.mPrefDistance = Integer.MAX_VALUE;
            }
            int[] pref = this.mPrefLetterFrequencies;
            if (this.mPrefLetter > 0) {
                return this.mPrefLetter == code;
            }
            boolean inside = key.isInsideSuper(x, y);
            int[] nearby = getNearestKeys(x, y);
            List<Keyboard.Key> nearbyKeys = getKeys();
            if (inside && inPrefList(code, pref)) {
                this.mPrefLetter = code;
                this.mPrefLetterX = x;
                this.mPrefLetterY = y;
                int i = 0;
                while (true) {
                    if (i >= nearby.length) {
                        break;
                    }
                    Keyboard.Key k = nearbyKeys.get(nearby[i]);
                    if (k == key || !inPrefList(k.codes[0], pref) || (dist2 = distanceFrom(k, x, y)) >= ((int) (k.width * OVERLAP_PERCENTAGE_LOW_PROB)) || pref[k.codes[0]] <= pref[this.mPrefLetter] * 3) {
                        i++;
                    } else {
                        this.mPrefLetter = k.codes[0];
                        this.mPrefDistance = dist2;
                        break;
                    }
                }
                return this.mPrefLetter == code;
            }
            for (int i2 : nearby) {
                Keyboard.Key k2 = nearbyKeys.get(i2);
                if (inPrefList(k2.codes[0], pref) && (dist = distanceFrom(k2, x, y)) < ((int) (k2.width * OVERLAP_PERCENTAGE_HIGH_PROB)) && dist < this.mPrefDistance) {
                    this.mPrefLetter = k2.codes[0];
                    this.mPrefLetterX = x;
                    this.mPrefLetterY = y;
                    this.mPrefDistance = dist;
                }
            }
            return this.mPrefLetter == 0 ? inside : this.mPrefLetter == code;
        }
        if (this.mCurrentlyInSpace) {
            return false;
        }
        return key.isInsideSuper(x, y);
    }

    private boolean inPrefList(int code, int[] pref) {
        return code < pref.length && code >= 0 && pref[code] > 0;
    }

    private int distanceFrom(Keyboard.Key k, int x, int y) {
        if (y <= k.y || y >= k.y + k.height) {
            return Integer.MAX_VALUE;
        }
        return Math.abs((k.x + (k.width / 2)) - x);
    }

    @Override
    public int[] getNearestKeys(int x, int y) {
        if (this.mCurrentlyInSpace) {
            return this.mSpaceKeyIndexArray;
        }
        return this.mProximityInfo.getNearestKeys(Math.max(0, Math.min(x, getMinWidth() - 1)), Math.max(0, Math.min(y, getHeight() - 1)));
    }

    private int indexOf(int code) {
        List<Keyboard.Key> keys = getKeys();
        int count = keys.size();
        for (int i = 0; i < count; i++) {
            if (keys.get(i).codes[0] == code) {
                return i;
            }
        }
        return -1;
    }

    public int getTextSizeFromTheme(int style, int defValue) {
        TypedArray array = this.mContext.getTheme().obtainStyledAttributes(style, new int[]{android.R.attr.textSize});
        try {
            int textSize = array.getDimensionPixelSize(array.getResourceId(0, 0), defValue);
            return textSize;
        } catch (ArrayIndexOutOfBoundsException e) {
            return defValue;
        }
    }

    public boolean isT9on() {
        if (this.mT9key == null) {
            return false;
        }
        boolean t9 = this.mT9key.on;
        return t9;
    }

    public class LatinKey extends Keyboard.Key {
        private final int[] KEY_STATE_FUNCTIONAL_NORMAL;
        private final int[] KEY_STATE_FUNCTIONAL_PRESSED;
        private boolean mShiftLockEnabled;

        public LatinKey(Resources res, Keyboard.Row parent, int x, int y, XmlResourceParser parser) {
            super(res, parent, x, y, parser);
            this.KEY_STATE_FUNCTIONAL_NORMAL = new int[]{android.R.attr.state_single};
            this.KEY_STATE_FUNCTIONAL_PRESSED = new int[]{android.R.attr.state_single, android.R.attr.state_pressed};
            if (this.popupCharacters != null && this.popupCharacters.length() == 0) {
                this.popupResId = 0;
            }
        }

        public void enableShiftLock() {
            this.mShiftLockEnabled = true;
        }

        private boolean isFunctionalKey() {
            return !this.sticky && this.modifier;
        }

        @Override
        public void onReleased(boolean inside) {
            if (!this.mShiftLockEnabled) {
                super.onReleased(inside);
            } else {
                this.pressed = !this.pressed;
            }
        }

        @Override
        public boolean isInside(int x, int y) {
            boolean result = LatinKeyboard.this.isInside(this, x, y);
            return result;
        }

        boolean isInsideSuper(int x, int y) {
            return super.isInside(x, y);
        }

        @Override
        public int[] getCurrentDrawableState() {
            if (isFunctionalKey()) {
                if (this.pressed) {
                    return this.KEY_STATE_FUNCTIONAL_PRESSED;
                }
                return this.KEY_STATE_FUNCTIONAL_NORMAL;
            }
            return super.getCurrentDrawableState();
        }

        @Override
        public int squaredDistanceFrom(int x, int y) {
            int edgeX;
            int edgeY;
            int left = this.x + 1;
            int right = left + this.width;
            int top = this.y;
            int bottom = top + this.height;
            if (x < left) {
                edgeX = left;
            } else {
                edgeX = x > right ? right : x;
            }
            if (y < top) {
                edgeY = top;
            } else {
                edgeY = y > bottom ? bottom : y;
            }
            int dx = x - edgeX;
            int dy = y - edgeY;
            return (dx * dx) + (dy * dy);
        }
    }

    public class SlidingLocaleDrawable extends Drawable {
        private final Drawable mBackground;
        private String mCurrentLanguage;
        private int mDiffX;
        private int mDiffY;
        private final int mHeight;
        private boolean mHitThresholdX;
        private boolean mHitThresholdY;
        private final Drawable mLeftDrawable;
        private final int mMiddleX;
        private String mNextLanguage;
        private String mPrevLanguage;
        private final Drawable mRightDrawable;
        private final TextPaint mTextPaint;
        private final int mThresholdX;
        private final int mThresholdY;
        private final int mWidth;

        public SlidingLocaleDrawable(Drawable background, int width, int height) {
            this.mBackground = background;
            LatinKeyboard.this.setDefaultBounds(this.mBackground);
            this.mWidth = width;
            this.mHeight = height;
            this.mTextPaint = new TextPaint();
            this.mTextPaint.setTextSize(LatinKeyboard.this.getTextSizeFromTheme(android.R.style.TextAppearance_Medium, 18));
            this.mTextPaint.setColor(LatinKeyboard.this.mRes.getColor(R.color.latinkeyboard_transparent));
            this.mTextPaint.setTextAlign(Paint.Align.CENTER);
            this.mTextPaint.setAlpha(LatinKeyboard.OPACITY_FULLY_OPAQUE);
            this.mTextPaint.setAntiAlias(true);
            this.mMiddleX = (this.mWidth - this.mBackground.getIntrinsicWidth()) / 2;
            this.mLeftDrawable = LatinKeyboard.this.mRes.getDrawable(R.drawable.sym_keyboard_feedback_language_arrows_left);
            this.mRightDrawable = LatinKeyboard.this.mRes.getDrawable(R.drawable.sym_keyboard_feedback_language_arrows_right);
            this.mThresholdX = ViewConfiguration.get(LatinKeyboard.this.mContext).getScaledTouchSlop();
            this.mThresholdY = ViewConfiguration.get(LatinKeyboard.this.mContext).getScaledTouchSlop();
        }

        public void setDiffX(int diff) {
            if (diff == Integer.MAX_VALUE) {
                this.mHitThresholdX = false;
                this.mCurrentLanguage = null;
                return;
            }
            this.mDiffX = diff;
            if (this.mDiffX > this.mWidth) {
                this.mDiffX = this.mWidth;
            }
            if (this.mDiffX < (-this.mWidth)) {
                this.mDiffX = -this.mWidth;
            }
            if (Math.abs(this.mDiffX) > this.mThresholdX) {
                this.mHitThresholdX = true;
            }
            invalidateSelf();
        }

        public void setDiffY(int diff) {
            if (diff == Integer.MAX_VALUE) {
                this.mHitThresholdY = false;
                this.mCurrentLanguage = null;
                return;
            }
            this.mDiffY = diff;
            if (this.mDiffY > this.mHeight) {
                this.mDiffY = this.mHeight;
            }
            if (this.mDiffY < (-this.mHeight)) {
                this.mDiffY = -this.mHeight;
            }
            if (Math.abs(this.mDiffY) > this.mThresholdY) {
                this.mHitThresholdY = true;
            }
            invalidateSelf();
        }

        private String getLanguageName(Locale locale) {
            String Lang = LanguageSwitcher.toTitleCase(locale.getDisplayLanguage(locale));
            if (Lang.equals("עברית") && AlsarabIME.mRTLEnabled) {
                return "תירבע";
            }
            return Lang;
        }

        @Override
        public void draw(Canvas canvas) {
            canvas.save();
            if (this.mHitThresholdX) {
                Paint paint = this.mTextPaint;
                int width = this.mWidth;
                int height = this.mHeight;
                int diff = this.mDiffX;
                Drawable lArrow = this.mLeftDrawable;
                Drawable rArrow = this.mRightDrawable;
                canvas.clipRect(0, 0, width, height);
                if (this.mCurrentLanguage == null) {
                    LanguageSwitcher languageSwitcher = LatinKeyboard.this.mLanguageSwitcher;
                    this.mCurrentLanguage = getLanguageName(languageSwitcher.getInputLocale());
                    this.mNextLanguage = getLanguageName(languageSwitcher.getNextInputLocale());
                    this.mPrevLanguage = getLanguageName(languageSwitcher.getPrevInputLocale());
                }
                float baseline = (this.mHeight * LatinKeyboard.SPACEBAR_LANGUAGE_BASELINE) - paint.descent();
                paint.setColor(LatinKeyboard.this.mRes.getColor(R.color.latinkeyboard_feedback_language_text));
                canvas.drawText(this.mCurrentLanguage, (width / 2) + diff, baseline, paint);
                canvas.drawText(this.mNextLanguage, diff - (width / 2), baseline, paint);
                canvas.drawText(this.mPrevLanguage, diff + width + (width / 2), baseline, paint);
                LatinKeyboard.this.setDefaultBounds(lArrow);
                rArrow.setBounds(width - rArrow.getIntrinsicWidth(), 0, width, rArrow.getIntrinsicHeight());
                lArrow.draw(canvas);
                rArrow.draw(canvas);
            }
            if (this.mHitThresholdY) {
                Paint paint2 = this.mTextPaint;
                int width2 = this.mWidth;
                int height2 = this.mHeight;
                int diff2 = this.mDiffY;
                canvas.clipRect(0, 0, width2, height2);
                Float baseline2 = Float.valueOf(width2 * LatinKeyboard.SPACEBAR_DRAG_THRESHOLD);
                paint2.setColor(LatinKeyboard.this.mRes.getColor(R.color.latinkeyboard_feedback_language_text));
                if (AlsarabIME.mEnableCursorsMode == 1) {
                    if (LatinKeyboard.mode_arrows) {
                        canvas.drawText("←↑↓→", baseline2.floatValue(), diff2, paint2);
                    } else {
                        canvas.drawText("←↑↓→", baseline2.floatValue(), Math.max(height2 + diff2, height2 / 2), paint2);
                    }
                }
            }
            if (this.mBackground != null) {
                canvas.translate(this.mMiddleX, 0.0f);
                this.mBackground.draw(canvas);
            }
            canvas.restore();
        }

        @Override
        public int getOpacity() {
            return -3;
        }

        @Override
        public void setAlpha(int alpha) {
        }

        @Override
        public void setColorFilter(ColorFilter cf) {
        }

        @Override
        public int getIntrinsicWidth() {
            return this.mWidth;
        }

        @Override
        public int getIntrinsicHeight() {
            return this.mHeight;
        }
    }
}
