package keyboard.alsarab.albaid.ime;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import keyboard.alsarab.albaid.common.speech.LoggingEvents;
import keyboard.alsarab.albaid.ime.Dictionary;

public class UserDictionary extends ExpandableDictionary {
    private static final int INDEX_FREQUENCY = 2;
    private static final int INDEX_WORD = 1;
    private static final String[] PROJECTION = {"_id", "word", "frequency"};
    private String mLocale;
    private ContentObserver mObserver;

    public UserDictionary(Context context, String locale) {
        super(context, 2);
        this.mLocale = locale;
        ContentResolver cres = context.getContentResolver();
        Uri uri = android.provider.UserDictionary.Words.CONTENT_URI;
        ContentObserver contentObserver = new ContentObserver(null) {
            @Override
            public void onChange(boolean self) {
                UserDictionary.this.setRequiresReload(true);
            }
        };
        this.mObserver = contentObserver;
        try {
            cres.registerContentObserver(uri, true, contentObserver);
        } catch (RuntimeException e) {
            android.util.Log.w("UserDictionary", "Cannot observe user dictionary: " + e);
        }
        loadDictionary();
    }

    @Override
    public synchronized void close() {
        if (this.mObserver != null) {
            getContext().getContentResolver().unregisterContentObserver(this.mObserver);
            this.mObserver = null;
        }
        super.close();
    }

    @Override
    public void loadDictionaryAsync() {
        try {
            Cursor cursor = getContext().getContentResolver().query(android.provider.UserDictionary.Words.CONTENT_URI, PROJECTION, "(locale IS NULL) or (locale=?) or (locale like '" + this.mLocale + "%')", new String[]{this.mLocale}, null);
            if (cursor != null) {
                addWords(cursor);
            }
        } catch (RuntimeException e) {
            android.util.Log.w("UserDictionary", "User dictionary is not available: " + e);
        }
    }

    @Override
    public synchronized void addWord(String word, int frequency) {
        if (getRequiresReload()) {
            loadDictionaryAsync();
        }
        if (word.length() < getMaxWordLength()) {
            super.addWord(word, frequency);
            final ContentValues values = new ContentValues(5);
            values.put("word", word);
            values.put("frequency", Integer.valueOf(frequency));
            values.put(LoggingEvents.VoiceIme.EXTRA_START_LOCALE, this.mLocale);
            values.put("appid", (Integer) 0);
            final ContentResolver contentResolver = getContext().getContentResolver();
            new Thread("addWord") {
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    try {
                        contentResolver.insert(android.provider.UserDictionary.Words.CONTENT_URI, values);
                    } catch (RuntimeException e) {
                        android.util.Log.w("UserDictionary", "Cannot save word: " + e);
                    }
                }
            }.start();
            setRequiresReload(false);
        }
    }

    @Override // keyboard.alsarab.albaid.ime.ExpandableDictionary, keyboard.alsarab.albaid.ime.Dictionary
    public synchronized void getWords(WordComposer codes, Dictionary.WordCallback callback, ProximityInfo proximityInfo) {
        super.getWords(codes, callback, proximityInfo);
    }

    @Override // keyboard.alsarab.albaid.ime.ExpandableDictionary, keyboard.alsarab.albaid.ime.Dictionary
    public synchronized boolean isValidWord(CharSequence word) {
        return super.isValidWord(word);
    }

    private void addWords(Cursor cursor) {
        clearDictionary();
        int maxWordLength = getMaxWordLength();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                String word = cursor.getString(1);
                int frequency = cursor.getInt(2);
                if (word.length() < maxWordLength && word.length() > 0) {
                    super.addWord(word, frequency);
                }
                cursor.moveToNext();
            }
        }
        cursor.close();
    }
}
