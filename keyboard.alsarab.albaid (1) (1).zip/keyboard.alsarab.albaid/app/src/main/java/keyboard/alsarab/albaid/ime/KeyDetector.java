package keyboard.alsarab.albaid.ime;

import android.inputmethodservice.Keyboard;
import java.util.Arrays;
import java.util.List;

abstract class KeyDetector {
    public static final int NOT_A_CODE = -1;
    protected int mCorrectionX;
    protected int mCorrectionY;
    protected Keyboard mKeyboard;
    private Keyboard.Key[] mKeys;
    protected boolean mProximityCorrectOn;
    protected int mProximityThresholdSquare;

    public abstract int getKeyIndexAndNearbyCodes(int i, int i2, int[] iArr);

    protected abstract int getMaxNearbyKeys();

    public Keyboard.Key[] setKeyboard(Keyboard keyboard, float correctionX, float correctionY) {
        if (keyboard == null) {
            throw new NullPointerException();
        }
        this.mCorrectionX = (int) correctionX;
        this.mCorrectionY = (int) correctionY;
        this.mKeyboard = keyboard;
        List<Keyboard.Key> keys = this.mKeyboard.getKeys();
        Keyboard.Key[] array = (Keyboard.Key[]) keys.toArray(new Keyboard.Key[keys.size()]);
        this.mKeys = array;
        return array;
    }

    public int getTouchX(int x) {
        return this.mCorrectionX + x;
    }

    public int getTouchY(int y) {
        return this.mCorrectionY + y;
    }

    public Keyboard.Key[] getKeys() {
        if (this.mKeys == null) {
            throw new IllegalStateException("keyboard isn't set");
        }
        return this.mKeys;
    }

    public void setProximityCorrectionEnabled(boolean enabled) {
        this.mProximityCorrectOn = enabled;
    }

    public boolean isProximityCorrectionEnabled() {
        return this.mProximityCorrectOn;
    }

    public void setProximityThreshold(int threshold) {
        this.mProximityThresholdSquare = threshold * threshold;
    }

    public int[] newCodeArray() {
        int[] codes = new int[getMaxNearbyKeys()];
        Arrays.fill(codes, -1);
        return codes;
    }
}
