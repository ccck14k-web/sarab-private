package keyboard.alsarab.albaid.colorpicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import keyboard.alsarab.albaid.R;

public class AmbilWarnaKotak extends View {
    Shader dalam;
    float hue;
    Shader luar;
    Paint paint;
    float satudp;
    float[] tmp00;
    float ukuranUiDp;
    float ukuranUiPx;

    public AmbilWarnaKotak(Context context) {
        this(context, null);
    }

    public AmbilWarnaKotak(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AmbilWarnaKotak(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.ukuranUiDp = 240.0f;
        this.tmp00 = new float[3];
        this.satudp = context.getResources().getDimension(R.dimen.ambilwarna_satudp);
        this.ukuranUiPx = this.ukuranUiDp * this.satudp;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.paint == null) {
            this.paint = new Paint();
            this.luar = new LinearGradient(0.0f, 0.0f, 0.0f, this.ukuranUiPx, -1, -16777216, Shader.TileMode.CLAMP);
        }
        float[] fArr = this.tmp00;
        this.tmp00[2] = 1.0f;
        fArr[1] = 1.0f;
        this.tmp00[0] = this.hue;
        int rgb = Color.HSVToColor(this.tmp00);
        this.dalam = new LinearGradient(0.0f, 0.0f, this.ukuranUiPx, 0.0f, -1, rgb, Shader.TileMode.CLAMP);
        ComposeShader shader = new ComposeShader(this.luar, this.dalam, PorterDuff.Mode.MULTIPLY);
        this.paint.setShader(shader);
        canvas.drawRect(0.0f, 0.0f, this.ukuranUiPx, this.ukuranUiPx, this.paint);
    }

    public void setHue(float hue) {
        this.hue = hue;
        invalidate();
    }
}
