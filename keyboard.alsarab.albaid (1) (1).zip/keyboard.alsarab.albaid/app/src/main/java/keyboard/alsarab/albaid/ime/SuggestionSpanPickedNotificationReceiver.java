package keyboard.alsarab.albaid.ime;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class SuggestionSpanPickedNotificationReceiver extends BroadcastReceiver {
    private static final boolean DBG = AlsarabIME.DEBUG;
    private static final String TAG = SuggestionSpanPickedNotificationReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        if (SuggestionSpanUtils.ACTION_SUGGESTION_PICKED.equals(intent.getAction()) && DBG) {
            String before = intent.getStringExtra(SuggestionSpanUtils.SUGGESTION_SPAN_PICKED_BEFORE);
            String after = intent.getStringExtra(SuggestionSpanUtils.SUGGESTION_SPAN_PICKED_AFTER);
            Log.d(TAG, "Received notification picked: " + before + "," + after);
        }
    }
}
