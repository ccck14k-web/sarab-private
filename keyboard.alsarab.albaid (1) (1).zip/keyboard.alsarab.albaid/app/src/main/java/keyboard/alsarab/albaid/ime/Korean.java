package keyboard.alsarab.albaid.ime;

import keyboard.alsarab.albaid.common.speech.LoggingEvents;

public class Korean {
    static final int H_STATE_0 = 0;
    static final int H_STATE_1 = 1;
    static final int H_STATE_2 = 2;
    static final int H_STATE_3 = 3;
    static final int H_STATE_4 = 4;
    static final int H_STATE_5 = 5;
    static final int H_STATE_6 = 6;
    private static char HCURSOR_NONE = 0;
    private static char HCURSOR_NEW = 1;
    private static char HCURSOR_ADD = 2;
    private static char HCURSOR_UPDATE = 3;
    private static char HCURSOR_APPEND = 4;
    private static char HCURSOR_UPDATE_LAST = 5;
    private static char HCURSOR_DELETE_LAST = 6;
    private static char HCURSOR_DELETE = 7;
    private static int mHCursorState = HCURSOR_NONE;
    private static char[] h_char = new char[1];
    private static int[] mHangulKeyStack = new int[6];
    private static int[] mHangulJamoStack = new int[3];
    static final char[] h_chosung_idx = {0, 1, '\t', 2, '\f', 18, 3, 4, 5, 0, 6, 7, '\t', 16, 17, 18, 6, 7, '\b', '\t', '\t', '\n', 11, '\f', '\r', 14, 15, 16, 17, 18};
    static final char[] h_jongsung_idx = {0, 1, 2, 3, 4, 5, 6, 7, 0, '\b', '\t', '\n', 11, '\f', '\r', 14, 15, 16, 17, 0, 18, 19, 20, 21, 22, 0, 23, 24, 25, 26, 27};
    static final int[] e2h_map = {16, 47, 25, 22, 6, 8, 29, 38, 32, 34, 30, 50, 48, 43, 31, 35, 17, 0, 3, 20, 36, 28, 23, 27, 42, 26, 16, 47, 25, 22, 7, 8, 29, 38, 32, 34, 30, 50, 48, 43, 33, 37, 18, 1, 3, 21, 36, 28, 24, 27, 42, 26};
    private int previousCurPos = -2;
    private int previousHangulCurPos = -1;
    private int mHangulShiftState = 0;
    private int mHangulState = 0;

    public int isHangulKey(int stack_pos, int new_key) {
        if (stack_pos != 2) {
            int i = e2h_map[(new_key - 97) + 26];
            switch (mHangulKeyStack[stack_pos]) {
                case 0:
                    if (new_key == 20) {
                        return 2;
                    }
                    break;
                case 3:
                    if (new_key == 23) {
                        return 4;
                    }
                    if (new_key == 29) {
                        return 5;
                    }
                    break;
                case 8:
                    if (new_key == 0) {
                        return 9;
                    }
                    if (new_key == 16) {
                        return 10;
                    }
                    if (new_key == 17) {
                        return 11;
                    }
                    if (new_key == 20) {
                        return 12;
                    }
                    if (new_key == 27) {
                        return 13;
                    }
                    if (new_key == 28) {
                        return 14;
                    }
                    if (new_key == 29) {
                        return 15;
                    }
                    break;
                case LoggingEvents.VoiceIme.TEXT_MODIFIED /* 17 */:
                    if (new_key == 20) {
                        return 19;
                    }
                    break;
            }
        } else {
            switch (mHangulKeyStack[stack_pos]) {
                case 38:
                    if (new_key == 30) {
                        return 39;
                    }
                    if (new_key == 31) {
                        return 40;
                    }
                    if (new_key == 50) {
                        return 41;
                    }
                    break;
                case 43:
                    if (new_key == 34) {
                        return 44;
                    }
                    if (new_key == 35) {
                        return 45;
                    }
                    if (new_key == 50) {
                        return 46;
                    }
                    break;
                case BinaryDictionary.MAX_WORD_LENGTH /* 48 */:
                    if (new_key == 50) {
                        return 49;
                    }
                    break;
            }
        }
        return 0;
    }
}
