package keyboard.alsarab.albaid.voiceime;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import keyboard.alsarab.albaid.voiceime.IntentApiTrigger;
import keyboard.alsarab.albaid.voiceime.ServiceHelper;

public class ServiceBridge {
    private static final String TAG = "ServiceBridge";
    private final IntentApiTrigger.Callback mCallback;

    public ServiceBridge() {
        this(null);
    }

    public ServiceBridge(IntentApiTrigger.Callback callback) {
        this.mCallback = callback;
    }

    public void startVoiceRecognition(final Context context, String languageCode) {
        final ConnectionRequest conReq = new ConnectionRequest(this, languageCode, null);
        conReq.setServiceCallback(new ServiceHelper.Callback() {
            @Override
            public void onResult(String recognitionResult) {
                ServiceBridge.this.mCallback.onRecognitionResult(recognitionResult);
                context.unbindService(conReq);
            }
        });
        context.bindService(new Intent(context, (Class<?>) ServiceHelper.class), conReq, 1);
    }

    public void notifyResult(Context context, String recognitionResult) {
        ServiceConnection conn = new ConnectionResponse(this, context, recognitionResult, null);
        context.bindService(new Intent(context, (Class<?>) ServiceHelper.class), conn, 1);
    }

    private class ConnectionRequest implements ServiceConnection {
        private final String mLanguageCode;
        private ServiceHelper.Callback mServiceCallback;

        private ConnectionRequest(String languageCode) {
            this.mLanguageCode = languageCode;
        }

        ConnectionRequest(ServiceBridge serviceBridge, String str, ConnectionRequest connectionRequest) {
            this(str);
        }

        public void setServiceCallback(ServiceHelper.Callback callback) {
            this.mServiceCallback = callback;
        }

        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            ServiceHelper serviceHelper = ((ServiceHelper.ServiceHelperBinder) service).getService();
            serviceHelper.startRecognition(this.mLanguageCode, this.mServiceCallback);
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
        }
    }

    private class ConnectionResponse implements ServiceConnection {
        private final Context mContext;
        private final String mRecognitionResult;

        private ConnectionResponse(Context context, String recognitionResult) {
            this.mRecognitionResult = recognitionResult;
            this.mContext = context;
        }

        ConnectionResponse(ServiceBridge serviceBridge, Context context, String str, ConnectionResponse connectionResponse) {
            this(context, str);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            ServiceHelper serviceHelper = ((ServiceHelper.ServiceHelperBinder) service).getService();
            serviceHelper.notifyResult(this.mRecognitionResult);
            this.mContext.unbindService(this);
        }
    }
}
