package keyboard.alsarab.albaid.voiceime;

interface Trigger {
    void onStartInputView();

    void startVoiceRecognition(String str);
}
