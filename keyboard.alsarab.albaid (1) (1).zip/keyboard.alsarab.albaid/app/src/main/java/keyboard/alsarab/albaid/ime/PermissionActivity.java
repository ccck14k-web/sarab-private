package keyboard.alsarab.albaid.ime;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

/** Invisible activity used by the keyboard to ask for a runtime permission when a feature needs it. */
public class PermissionActivity extends Activity {
    private static final String EXTRA_PERMISSION = "permission";
    private static final int REQUEST_CODE = 91;

    public static void request(Context context, String permission) {
        Intent intent = new Intent(context, PermissionActivity.class);
        intent.putExtra(EXTRA_PERMISSION, permission);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
        } catch (Exception e) {
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String permission = getIntent().getStringExtra(EXTRA_PERMISSION);
        if (permission == null || Build.VERSION.SDK_INT < 23) {
            finish();
            return;
        }
        if (savedInstanceState == null) {
            requestPermissions(new String[]{permission}, REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        finish();
    }
}
